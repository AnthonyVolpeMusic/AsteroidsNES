# V32 — Drunk Mode

Select cycles Arcade, Bouncy, Drunk. Start plays the selected mode.
Each regular asteroid chooses 1–12 steps and a turn direction, advances one
of 48 headings every five gameplay updates, then chooses a new run. Existing
size-specific velocity tables are reused. New fragments reset their turning
state. Other entities retain Arcade behavior in Drunk Mode.

The bottom counter remains at row 28 with HUD-white digits, updated every
15 gameplay updates. Bouncy retains its raised lower boundary.
No adaptive 30 FPS switch or Evil Mode is included yet.

Build: `python3 prototype/build_v32.py` (requires py65).
Test: `python3 prototype/test_v32.py`.
The build generates historical intermediate ROMs as part of its builder chain.

Deferred performance thresholds: Arcade >=20 objects, Bouncy >=14 objects.
Drunk and Evil thresholds still need playtesting.
