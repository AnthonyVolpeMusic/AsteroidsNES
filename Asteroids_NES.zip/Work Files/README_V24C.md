# V24c audio overhead reduction

Build: python3 prototype/build_v24c.py
Test: python3 prototype/test_v24c.py

Removes the duplicate audio object scan. Existing wave_tick publishes regular
asteroid/Murderoid presence in newly reserved zero-page byte $80. UFOs still
block wave advance but do not keep music playing alone. Central audio service
runs after gameplay, so death and clear silence it in the same update.
New waves reset pulse countdown. Respawn resumes music when rocks remain.
Tempo calculations execute only on note updates; intervals/notes unchanged.
Asteroid caps, speeds, collision rules, and update frequencies are unchanged.

py65 checks: all medium-progress boundaries, medium destruction paths, audio
gates, next-wave reset and respawn passed. V23 rank/replay/menu regression passed.
Ordinary audio service: 34 CPU cycles excluding caller JSR. Representative
level-five opening: 18159 cycles with audio versus 18131 bypassing service;
includes synthetic NMI instructions, excludes hardware DMA stalls and real
PPU/APU timing. This is not a full emulator timing or late-wave stress proof.
User should compare busy level-five gameplay against V24b; slowdown resolution
is not yet confirmed. The earlier claim that CPU overload was proven was too
strong: the user's report is consistent with it, but no failing save state was
available to reproduce that exact moment.
