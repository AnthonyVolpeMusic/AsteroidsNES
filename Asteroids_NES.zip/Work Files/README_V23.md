# V23 final score and rank screen

Build with `python prototype/build_v23.py` (Python, Pillow, py65).
Run `prototype/asteroids_nes_v23_rank_screen.nes`.
Test with `python prototype/test_v23.py`.

After the five-second moving GAME OVER display, replace the playfield with
centered white text using the supplied character set. Rows: FINAL SCORE at 5,
six score digits at 7, YOUR RANK at 10, rank at 12, replay prompt at 18, menu
prompt at 22–23. Background attributes use the existing white-text palette.
Sprites are hidden and the gameplay HUD no longer refreshes on this screen.

Rank lower bounds (inclusive):
0 GARBAGE SCOW CAPTAIN; 2500 GALACTIC COOK; 5000 ROOKIE; 10000 ENSIGN;
15000 PILOT; 20000 ACE; 30000 LIEUTENANT; 40000 WARRIOR; 60000 CAPTAIN;
80000 COMMANDER; 100000 SPACE LORD. Compare the full 24-bit binary score.

Start begins a new game: zero score, three lives, four large asteroids,
SUPER five, centered stationary ship, reset pickups/upgrades and enemy state.
Select returns to the original title/menu. Held Start at the screen transition
requires release before replay. If both menu buttons are newly pressed, Start
takes priority. Five-second final-death processing no longer starts new waves.

Screen loads run with rendering and NMI disabled, then restart at vblank.
Results use CPU state 3 in the existing death-state field. No new RAM records
or graphics tiles are required. Previous version files are preserved.

Tests execute assembled code, capture PPU address/data writes, and check every
rank boundary, all requested text, score digits, absence of HUD writes and
visible sprites, the actual 300-update transition, held-button protection,
complete replay reset, return to title and starting again. PPU tile output was
checked programmatically; emulator visual playtesting remains the next step.
