# V34 — adaptive 60/30 FPS

Build: `python3 prototype/build_v34.py` (Python with `py65`).
Test: `python3 prototype/test_v34.py`.
Full-wave score tests:
`python3 prototype/test_full_wave.py 34 20 4`
`python3 prototype/test_full_wave.py 34 20 12`

## Behavior

| Mode | Enter 30 FPS at load | Return to 60 FPS at load |
| --- | ---: | ---: |
| Arcade | 22 or greater | 19 or less |
| Bouncy, Drunk, Evil | 15 or greater | 12 or less |

The weighted bottom counter remains white, centered at row 28. UFO bodies
count four, Murderoids five, other active items one. It refreshes every 15
simulation ticks; the scheduler uses the most recent sampled load. The display
is capped at 99. The title and results screen use the normal one-refresh path.

At 30 FPS, each batch runs TWO unmodified-size gameplay steps and rebuilds OAM
once. Every step still reads controls, moves all entities, checks collisions,
advances gameplay/audio timers, and processes score/splitting. The NES continues
to refresh at its normal rate; NMI presents a new buffer every second refresh.
It never publishes unfinished OAM. Audio command order and simulation durations
are preserved, although two substeps are computed within the same presentation
interval rather than each being individually synchronized to vblank.

Shield palette phase follows simulation ticks rather than draw count. The
four-frame palette changes therefore retain their timing. Sprite priority
rotation follows displayed frames. Bouncy retains its raised bottom boundary.

CPU savings also include clearing only OAM Y bytes, skipping inactive regular
asteroid movement during gameplay, table-based collision widths, and a fast
Bouncy interior path. Near walls, the existing rebound solver is used.

## Validation and limits

Tested all mode thresholds and hysteresis; two-substep motion, lifetimes,
pickup/shield timers and audio event sequence; collision before fragment grace;
partial-buffer protection; 240 Bouncy cases compared against V33; original
mode/counter and brake/flip regressions; full-wave scoring.

In a repeatable 20-small-asteroid scene with four player projectiles, a UFO,
and two enemy projectiles, the complete paired work measured about 48,819
(Arcade), 55,805 (Bouncy), 50,389 (Drunk), and 50,469 (Evil) CPU cycles.
Real periodic NMI tests including DMA stalls produced 30 simulation steps and
15 presentations over 30 hardware refreshes in each mode. The two-refresh
budget is approximately 59,560 cycles before interrupt overhead.

These measurements are specific scenes, not a worst-case bound. Larger or
especially expensive combinations can still exceed the CPU budget; V34 is
ready for high-wave emulator playtesting. No simulation work is discarded to
conceal an overrun. Both the load sampling delay and transition gap are intentional.

ZP allocations added: $A0 refresh serial, $A1 interval (1/2), $A2 presentation
countdown, $A3 remaining simulation steps. The builder retains historical
intermediate ROM generation; running it also builds V33 for comparison tests.
