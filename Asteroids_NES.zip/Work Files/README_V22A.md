# V22a explosion correction

Build: `python prototype/build_v22a.py` (Pillow and py65).
Run: `prototype/asteroids_nes_v22a_explosion_fix.nes`.
Test: `python prototype/test_v22a.py`.

V22's empty player-projectile slots hid three death fragments after they were
rendered. Render the fragments after the bullet pass to preserve all four OAM
entries. The drawing sequence is corrected to frames 1 through 5, and final
death now calls the same explosion update as ordinary death.

Fragments move at one pixel/update instead of three. Choose one random heading
in each 90-degree sector so all four paths are distinct. Five drawings remain
visible for five updates each, totaling 25 updates. All four start at the ship.

The regression executes actual main-loop updates for both ordinary and final
death. It verifies all four final OAM Y positions (visibility), tile sequence,
distinct velocities, movement, disappearance, 120-update respawn/free shield,
and the 300-update Game Over hold. The prior V22 test checked only tile numbers
and did not catch sprite entries whose Y positions were overwritten to hide them.
OpenEMU/RetroArch playtesting is still needed to confirm appearance.
