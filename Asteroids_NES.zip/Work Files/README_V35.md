# V35 — starfield, progressive lives, Murderoid retreat

Branches from playtested V34. V34 files remain unchanged.

- Extra lives at cumulative scores 10,000 / 30,000 / 60,000 / 100,000 /
  150,000 / 210,000 and so on. Equality awards the life. Threshold checks can
  catch up across multiple crossed thresholds without repeating decimal score
  addition. Boot and replay reset the progression. ZP $A4–$A6 holds the next
  threshold increment; $3A–$3C retains the cumulative threshold.
- Ten new background tiles $90–$99, each one pixel, scattered at 90 fixed
  pseudorandom locations across gameplay rows 3–26. White / dark blue / dark
  purple; background palette 0's formerly unused colors 2/3 are $01/$04.
  Text remains white, title unchanged, HUD and counter rows remain clear.
  Starfield survives replay, uses no sprite slots, and does no per-frame work.
- Any player death activates Murderoid departure, not just Murderoid kills.
  Existing rightward departure direction is retained; fractional movement is
  now 75% of each size's normal speed: large 0.375, medium 0.703125, small
  1.125 pixels/simulation tick. Active speeds and pursuit are unchanged.
  Departure bypasses bounce rules. Respawn waits for Murderoids and UFO to
  leave, preserves the two-second minimum and three-second free shield.
- Adaptive presentation and audio unchanged.

Build (Python dependencies: py65, Pillow):

    python3 prototype/build_v35.py

Verification:

    python3 prototype/test_v35.py
    python3 prototype/test_full_wave.py 35 20 4
    python3 prototype/test_full_wave.py 35 20 12

All pass. Full-wave scoring: 2,100 / 6,300. V35 tests cover progressive
thresholds, all four death sources in all four modes, exit velocities, respawn,
star tile contents, boot/replay, real periodic NMI presentation, 30/60 switching,
busy scene budgets, collision grace, Bouncy movement, Evil/Drunk behavior,
counter and control/audio regressions. Busy paired-step cycle counts:
Arcade 48,791; Bouncy 55,791; Drunk 50,353; Evil 50,433.

`preview_v35.py` decodes the actual background CHR/nametable to a temporary
background-only PNG for inspection; it is not an emulator screenshot.
