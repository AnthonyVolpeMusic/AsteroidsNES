# V24b triangle pulse state gate

Build: `python prototype/build_v24b.py`.
ROM: `prototype/asteroids_nes_v24b_pulse_gated.nes`.
Test: `python prototype/test_v24b.py`.

The triangle C2/C#2 pulse is disabled when Player One is dead (including the
five-second Game Over run) and when every regular asteroid and Murderoid has
been eliminated during the four-second wave-clear delay. It begins again as
soon as Player One respawns or `set_game_rocks` creates the next wave.

The mute clears only the triangle enable bit in `$4015`, preserving future
pulse/noise sound effects.
