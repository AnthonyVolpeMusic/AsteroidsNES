# V25a audio channel repair

Build: python3 prototype/build_v25a.py
Test: python3 prototype/test_v25a.py

Reserves $86 as the software APU channel enable mask. No audio service reads
$4015 as an enable mask: its read value is length-counter status. All three
channels enable before writing their length-load register. Starting, ending,
and muting one sound now preserve the others. Pulse high-timer writes occur
only on shot start rather than resetting phase throughout the slide.
Audio state is cleared on results entry and replay as well as cold reset.
Pulse sweep is explicitly initialized. Requested pitches, noise periods,
envelopes and newest-explosion-wins behavior remain in place.

The regression bus models enable bits, status reads and ignored length loads
while disabled. It reproduces the V25 bug, then verifies all six start orders,
separate envelope endings, retriggers, triangle mute/restart, zero-length but
enabled channels, asteroid pages, Murderoids, UFO hits and player death.
It is not a full APU synthesizer; listening in OpenEMU remains the final check.
V23 results/rank/replay/menu regression also passed against the new ROM.
