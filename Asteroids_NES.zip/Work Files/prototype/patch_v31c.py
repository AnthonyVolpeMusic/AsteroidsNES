"""V31c additions after V31's Arcade/Bouncy patch.

ZP $9D: 15-frame refresh divider; $9E: active-object count; $9F: PPU dirty.
The counter excludes the player and HUD, and includes active moving gameplay
objects plus each of the four visible player-death debris sprites.
"""

# Only the shared Bouncy Y high bound changes: $E8 -> $DE for an 8px object.
patch31('''SBC #$10
STA $92
LDA #$10
STA $91
LDA #$02''','''SBC #$1A
STA $92
LDA #$10
STA $91
LDA #$02''')

# Run after gameplay logic, before the renderer.  The title is intentionally
# excluded, so the startup art stays clean.
patch31('''main_render21:
JSR thrust_audio27''','''main_render21:
JSR debug_objects31a
JSR thrust_audio27''')

# Use row 28 (y=224), above the bottom eight scanlines commonly cropped.
# Explicitly select background palette 0, the same white palette as the HUD.
patch31('''CPX #$20
BNE load_hud_loop
RTS''','''CPX #$20
BNE load_hud_loop
LDA #$23
STA $2006
LDA #$FB
STA $2006
LDA #$00
STA $2007
STA $2007
RTS''')

# The NMI performs the two-tile PPU update only after a fresh 15-frame count.
patch31('''nmi_mode_done31:
''','''nmi_mode_done31:
LDA $9F
BEQ nmi_debug_done31a
LDA #$23
STA $2006
LDA #$8F
STA $2006
LDA $9E
LDX #$00
nmi_debug_tens31a:
CMP #$0A
BCC nmi_debug_digits31a
SEC
SBC #$0A
INX
JMP nmi_debug_tens31a
nmi_debug_digits31a:
STA $9B
TXA
CLC
ADC #$7B
STA $2007
LDA $9B
CLC
ADC #$7B
STA $2007
LDA #$00
STA $9F
nmi_debug_done31a:
''')

counter='''debug_objects31a:
LDA $06
BNE debug_objects_game31b
LDA #$00
STA $9F
STA $9D
RTS
debug_objects_game31b:
LDA $0677
CMP #$03
BNE debug_objects_play31b
LDA #$00
STA $9F
RTS
debug_objects_play31b:
INC $9D
LDA $9D
CMP #$0F
BCS debug_objects_count31b
RTS
debug_objects_count31b:
LDA #$00
STA $9D
STA $9E
LDX #$00
debug_rock_loop31a:
LDA $0308,X
BEQ debug_rock_bank2_31b
INC $9E
debug_rock_bank2_31b:
LDA $0408,X
BEQ debug_rock_bank3_31b
INC $9E
debug_rock_bank3_31b:
LDA $0508,X
BEQ debug_rock_next31a
INC $9E
debug_rock_next31a:
TXA
CLC
ADC #$10
TAX
BNE debug_rock_loop31a
LDX #$00
debug_murder_loop31a:
LDA $0688,X
BEQ debug_murder_next31a
INC $9E
debug_murder_next31a:
TXA
CLC
ADC #$10
TAX
CPX #$60
BNE debug_murder_loop31a
LDX #$00
debug_shot_loop31a:
LDA $0600,X
BEQ debug_shot_next31a
INC $9E
debug_shot_next31a:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE debug_shot_loop31a
LDX #$00
debug_pickup_loop31a:
LDA $0708,X
BEQ debug_pickup_next31a
INC $9E
debug_pickup_next31a:
TXA
CLC
ADC #$10
TAX
BNE debug_pickup_loop31a
LDA $0640
ORA $0647
BEQ debug_no_ufo31a
INC $9E
debug_no_ufo31a:
LDA $0650
BEQ debug_no_ufo_shot31a
INC $9E
debug_no_ufo_shot31a:
LDA $0660
BEQ debug_no_ufo_shot2_31a
INC $9E
debug_no_ufo_shot2_31a:
LDA $067D
BEQ debug_no_debris31a
LDA $9E
CLC
ADC #$04
STA $9E
debug_no_debris31a:
LDA #$01
STA $9F
debug_objects_done31a:
RTS
'''
code+='\n'+counter
lines=[s.strip() for s in code.splitlines() if s.strip()]
