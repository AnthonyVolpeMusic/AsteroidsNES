"""V19a: farthest-wall Murderoid spawning."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v19.py').read_text(),str(P/'build_v19.py'),'exec'))
start=source.index('LDA $11\nCLC\nADC #$80\nSTA $62',source.index('murder_spawn_check:'))
end=source.index('LDA #$00\nSTA $65',start)
source=source[:start]+'''JSR random
AND #$01
BEQ murder_spawn_horizontal_wall
; Select farthest left/right wall using the center of the 8x8 ship.
LDA $11
CMP #$7C
BCC murder_spawn_right
LDA #$00
JMP murder_spawn_x_wall
murder_spawn_right:
LDA #$F0
murder_spawn_x_wall:
STA $62
murder_spawn_random_y:
JSR random
CMP #$E1
BCS murder_spawn_random_y
STA $63
JMP murder_spawn_position_ready
murder_spawn_horizontal_wall:
LDA $13
CMP #$74
BCC murder_spawn_bottom
LDA #$00
JMP murder_spawn_y_wall
murder_spawn_bottom:
LDA #$E0
murder_spawn_y_wall:
STA $63
murder_spawn_random_x:
JSR random
CMP #$F1
BCS murder_spawn_random_x
STA $62
murder_spawn_position_ready:
'''+source[end:]
# Keep conditional branches local as the spawn routine grows.
source=source.replace('LDA $06\nBEQ murder_spawn_return\nLDA $0673\nBNE murder_spawn_return\nLDA $3F\nCMP #$07\nBCC murder_spawn_return',
'''LDA $06
BEQ murder_spawn_ineligible
LDA $0673
BNE murder_spawn_ineligible
LDA $3F
CMP #$07
BCS murder_spawn_eligible
murder_spawn_ineligible:
RTS
murder_spawn_eligible:''')
source=source.replace('CPY #$04\nBCS murder_spawn_return','CPY #$04\nBCC murder_spawn_count_ready\nRTS\nmurder_spawn_count_ready:')
source='\n'.join(line for line in source.splitlines() if not line.lstrip().startswith(';'))+'\n'
source=source.replace('asteroids_nes_v19_murderoids.nes','asteroids_nes_v19a_edge_murderoids.nes').replace('symbols_v19.json','symbols_v19a.json').replace('prototype_v19.asm','prototype_v19a.asm')
exec(compile(source,str(P/'build_v15.py'),'exec'))
