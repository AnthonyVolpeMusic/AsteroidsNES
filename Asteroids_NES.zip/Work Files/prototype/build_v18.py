"""V18 pickup system; compose over the preserved V17a sources."""
from pathlib import Path
import math
P=Path(__file__).parent
base=(P/'build_v17a.py').read_text()
exec(base[:base.rindex('exec(compile(source,')])
change('JSR blank_title\nJSR ufo_init','JSR blank_title\nJSR pickups_init\nJSR ufo_init')
change('JSR asteroids\nJSR collisions','JSR asteroids\nJSR pickups_tick\nJSR collisions')
change('JSR ufo_collisions\nJSR wave_tick','JSR ufo_collisions\nJSR pickups_collect\nJSR wave_tick')
change('next_wave:\n','next_wave:\nLDA #$00\nSTA $0670\nSTA $0671\n')
# Runs before splitting/reusing the parent record; does not alter collision
# scratch or parent pointer, and restores the asteroid index X.
change('STA $46\nLDA $26','STA $46\nJSR pickup_drop\nLDA $26')
change('wave_tick:\n',(P/'pickups_v18.asm').read_text()+'\nwave_tick:\n')
# Both ordinary shots and rainbow shots pass this sequence once per bullet.
source=source.replace('STA $060A,X','STA $060A,X\nJSR pickup_boost_shot')
# Add 16 independent pickup records to the same rotating display traversal.
change("data['render_record_low']=[(n*16)&255 for n in range(48)]", "data['render_record_low']=[(n*16)&255 for n in range(64)]")
change("data['render_record_high']=[3+n//16 for n in range(48)]", "data['render_record_high']=[3+n//16 for n in range(48)]+[7]*16")
rs=source.index('render_asteroids:\n');re=source.index('render_title:\n',rs)
render=source[rs:re].replace('#$30','#$40')
render=render.replace('render_pool_active:\n','''render_pool_active:
LDA $44
CMP #$07
BNE render_regular_rock
JSR render_pickup
JMP render_pool_next
render_regular_rock:
LDA ($43),Y
''')
source=source[:rs]+render+source[re:]
# New movement and display tables. Index 1..5 = 250,500,750,1000,speed.
newtables={
 'pickup_order':[1,2,1,3,1,2,1,4,5],
 'pickup_tiles':[0,0x26,0x28,0x2a,0x2c,0x2e],
 'pickup_palettes':[0,1,1,0,0,1],
 'pickup_score_chunks':[0,1,2,3,4,0],
}
for axis,fn in [('x',math.sin),('y',lambda a:-math.cos(a))]:
 vals=[round(192*.2*fn(h*math.tau/48))&65535 for h in range(48)]
 newtables['pickup_'+axis+'lo']=[v&255 for v in vals]
 newtables['pickup_'+axis+'hi']=[v>>8 for v in vals]
 vals=[round(768*.25*fn(h*math.tau/48))&65535 for h in range(48)]
 newtables['boost_'+axis+'lo']=[v&255 for v in vals]
 newtables['boost_'+axis+'hi']=[v>>8 for v in vals]
change("data['rainbow_offsets']=",'data.update('+repr(newtables)+")\ndata['rainbow_offsets']=")
assets='''
pickup_frames=[
 ['11000000','01100000','11022200','11122000','00002200','00022111','00000101','00000111'],
 ['22000000','02200000','22011100','22211000','00001100','00011222','00000202','00000222'],
 ['33300000','33000000','03311100','33010100','00011100','00000333','00000303','00000333'],
 ['11100000','11000000','01133300','11030300','00033300','00000111','00000101','00000111'],
 ['11100000','00100000','00122200','00122000','00002200','00022111','00000101','00000111'],
 ['22200000','00200000','00211100','00211000','00001100','00011222','00000202','00000222'],
 ['03000000','33001000','03010100','33301300','00003030','00000310','00000101','00000010'],
 ['01000000','11003000','01030300','11103100','00001010','00000130','00000303','00000030'],
 ['00000110','00001111','00301111','00300110','10330000','10033300','11000000','01110000'],
 ['00000330','00003333','00103333','00100330','30110000','30011100','33000000','03330000']]
for i,rows in enumerate(pickup_frames):
 assert len(rows)==8 and all(len(row)==8 for row in rows)
 tile(0x126+i,[[int(c) for c in row] for row in rows])
'''
change("output=P/'asteroids_nes_v17a_two_ufo_shots.nes'",assets+"\noutput=P/'asteroids_nes_v18_pickups.nes'")
source=source.replace('prototype_v17a.asm','prototype_v18.asm').replace('symbols_v17a.json','symbols_v18.json')
exec(compile(source,str(P/'build_v15.py'),'exec'))
