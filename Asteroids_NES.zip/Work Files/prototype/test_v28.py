"""Focused assembled-ROM respawn and palette regressions."""
from pathlib import Path
P=Path(__file__).parent
previous=(P/'test_v27.py').read_text().replace('v27','v28').replace('ship_sfx','respawn_shield')
exec(compile(previous,str(P/'test_v27.py'),'exec'))
# Earlier tests' fresh helper now loads V28.
for kind in (1,2):
    fresh26();m[0x677]=1;m[0x678]=120;m[0x640]=kind
    for _ in range(150):call('death_tick21')
    assert m[0x677]==1 and m[0x678]==0
    m[0x640]=0
    call('death_tick21');assert m[0x677]==0 and m[8]==180
fresh26();m[0x677]=1;m[0x678]=120
for _ in range(119):call('death_tick21')
assert m[0x677]==1
call('death_tick21');assert m[0x677]==0
fresh26();m[0x677]=1;m[0x679]=1;m[0x688]=3
call('death_tick21');assert m[0x677]==1
m[0x688]=0;call('death_tick21');assert m[0x677]==0
fresh26();m[0x677]=2;call('death_tick21');assert m[0x677]==2
# Existing dead-loop ordering: UFO continues moving and exits, then respawn.
fresh26();m[0x677]=1;m[0x640]=1;m[0x641]=243;m[0x642]=80;m[0x643]=0
m[0x645]=2;m[0x646]=60
for _ in range(10):
    call('ufo_tick');call('death_tick21')
    if m[0x677]==0:break
assert m[0x640]==0 and m[0x677]==0
print('PASS both UFO sizes gate respawn; exit releases gate; two-second and Murderoid waits; no final-life respawn')
fresh26()
assert m[S['palette']+28:S['palette']+32]==[15,0x24,0x37,0x2a]
for duration in (60,180):
    m[8]=duration;m[0x8d]=0
    values=[]
    for _ in range(duration):
        call('render');values.append(m[0x202]&3)
        call('shield_tick')
    assert values==[0 if (i//4)%2==0 else 3 for i in range(duration)]
    call('render');assert m[0x202]&3==0 and m[0x8d]==0
print('PASS palette 3 bytes; exact four-render alternation over manual/respawn shields; default on expiration')
