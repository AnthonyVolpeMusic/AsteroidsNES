"""Assert final OAM visibility, not just tile IDs, through real main frames."""
from pathlib import Path
import math
P=Path(__file__).parent
base=(P/'test_v22.py').read_text().split('# AABB boundaries')[0]
base=base.replace('symbols_v22.json','symbols_v22a.json').replace('asteroids_nes_v22_gameover.nes','asteroids_nes_v22a_explosion_fix.nes')
exec(compile(base,str(P/'test_v22.py'),'exec'))
for lives in (1,3):
    reset();m[0x3d]=lives;rock(0x300,3);runframe()
    assert m[0x67d]==25
    velocity=[]
    for i in range(4):
        a=0x6e0+i*8
        pair=[]
        for offset in (4,6):
            n=m[a+offset]|m[a+offset+1]<<8
            pair.append(n-65536 if n>=32768 else n)
        assert abs(math.hypot(*pair)/256-1)<.004
        velocity.append(tuple(pair))
    assert len(set(velocity))==4
    positions=[]
    for age in range(25):
        assert m[0x67d]==25-age,(lives,age)
        assert [m[0x201+4*i] for i in range(4)]==[0x1b+age//5]*4
        # Empty projectile slots used to overwrite these Y coordinates with F8.
        assert all(m[0x200+4*i]<240 for i in range(4)),(lives,age,m[0x200:0x210])
        positions.append([(m[0x203+4*i],m[0x200+4*i]) for i in range(4)])
        runframe()
    assert all(positions[0][i]!=positions[-1][i] for i in range(4))
    assert m[0x67d]==0 and all(m[0x200+4*i]==248 for i in range(4))
    if lives==1:
        for _ in range(275):runframe()
        assert m[0x677]==3 and m[0x3d]==0
    else:
        for _ in range(95):runframe()
        assert m[0x677]==0 and m[8]==180 and m[7]==5
print('PASS both death paths: four visible OAM sprites, distinct 1px/update velocities,')
print('     all five drawings in order for five updates each, cleanup and lifecycle')
