"""Focused APU bus regression: executes ROM; not a full audio synthesizer."""
import json
from itertools import permutations
from pathlib import Path
from py65.devices.mpu6502 import MPU
P=Path(__file__).parent
class Bus(list):
    def __init__(self):
        super().__init__([0]*65536)
        self.enabled=0; self.length=[0]*4; self.ignored=[]; self.reads=0
    def __getitem__(self,k):
        if k==0x4015:
            self.reads+=1
            return sum(1<<i for i,n in enumerate(self.length) if n)
        if k==0x2002:return 0x80
        return super().__getitem__(k)
    def __setitem__(self,k,v):
        if isinstance(k,int):
            if k==0x4015:
                self.enabled=v&15
                for i in range(4):
                    if not v&(1<<i):self.length[i]=0
            if k in (0x4003,0x4007,0x400b,0x400f):
                i=(k-0x4003)//4
                if self.enabled&(1<<i):self.length[i]=10 # all tested loads use index 0
                else:self.ignored.append(k)
        super().__setitem__(k,v)
def load(version,filename):
    global m,c,S
    S=json.loads((P/f'symbols_{version}.json').read_text())
    m=Bus();m[0x8000:]=(P/filename).read_bytes()[16:32784];c=MPU(memory=m)
    m[6]=1;m[0x80]=1;m[0x81]=48;m[0x7f]=8
def call(label,a=0):
    c.a=a;c.pc=S[label];c.sp=255;c.stPushWord(0x7ffe)
    for _ in range(100000):
        c.step()
        if c.pc==0x7fff:return
    raise AssertionError(label+' timeout')
def fresh():load('v25a','asteroids_nes_v25a_audio_fix.nes')
load('v25','asteroids_nes_v25_core_sfx.nes')
call('sfx_noise_start25',14);assert not m.length[3] and 0x400f in m.ignored
call('sfx_shot_start25');assert not m.enabled&8
print('REPRODUCED V25 missing noise and cross-channel disable with hardware-style status')
events=['sfx_shot_start25','sfx_noise_start25','asteroid_pulse24']
for order in permutations(events):
    fresh()
    for event in order:call(event,14)
    assert m.enabled==13 and all(m.length[i] for i in (0,2,3))
    assert not m.ignored and m.reads==0
    for _ in range(11):call('sfx_tick25')
    assert m.enabled==12 and m.length[3] and m.length[2] and m[0x4000]&15==0
    for _ in range(19):call('sfx_tick25')
    assert m.enabled==4 and m.length[2] and m[0x400c]&15==0
print('PASS all six start orders; simultaneous channel lengths; independent envelope endings')
fresh();call('sfx_noise_start25',14);call('sfx_shot_start25');call('asteroid_pulse24')
for _ in range(4):call('sfx_tick25')
call('sfx_shot_start25');assert m[0x82]==11 and m[0x4000]&15==15 and m.length[3]
call('sfx_noise_start25',12);assert m[0x84]==30 and m[0x85]==12 and m.length[0]
call('asteroid_pulse_off24');assert m.enabled==9 and m.length[0] and m.length[3]
call('asteroid_pulse24');assert m.enabled==13 and m.length[2]
# Enabled but zero-length pulse2 must survive other channels' writes.
m[0x86]|=2;m[0x4015]=m[0x86];m.length[1]=0
call('sfx_noise_start25',15);assert m.enabled==15 and m.reads==0
call('audio_reset25a');assert m.enabled==0 and not any(m[0x82:0x87])
print('PASS retriggers, triangle mute/restart, status-versus-enable separation, audio reset')
# Verify real destruction entry points rather than just the SFX selectors.
for kind,period in ((1,14),(2,13),(3,12)):
    for page in (0x300,0x400,0x500):
        fresh();m[page+8]=kind;m[page+1]=60;m[page+3]=70
        m[0x600:0x610]=[47,0,64,0,74,0,0,0,0,0,12,0,0,0,0,0]
        call('collisions');assert m[0x85]==period and m.length[3]
    fresh();m[0x688]=kind;m[0x681]=60;m[0x683]=70;c.x=0
    call('murder_destroy');assert m[0x85]==period and m.length[3]
    fresh();m[0x308]=kind;m[0x301]=60;m[0x303]=70;m[0x640:0x644]=[1,60,70,0]
    call('enemy_rocks21');assert m[0x85]==period and m.length[3]
fresh();m[0x3d]=3;call('player_kill21');call('pulse_gate24c')
assert m[0x85]==15 and m.length[3] and not m.enabled&4
print('PASS asteroid pages, Murderoids, UFO collisions and death retain audible noise channel')
