"""V33 Evil Mode and weighted-counter validation."""
from pathlib import Path
P=Path(__file__).parent
base=(P/'test_v31c.py').read_text().replace('symbols_v31c.json','symbols_v33.json').replace('asteroids_nes_v31c_bouncy_debug.nes','asteroids_nes_v33_evil.nes').replace('m[0x9E]==15','m[0x9E]==22').replace('check_count(81)','check_count(99)')
exec(compile(base,str(P/'test_v31c.py'),'exec'))

def nmi_once():
    c.pc=0x7FFF;c.sp=255;c.nmi()
    for _ in range(10000):
        c.step()
        if c.pc==0x7FFF:return
    raise AssertionError('NMI timeout')
def clear_all():
    for page in (0x300,0x400,0x500,0x700):
        for offset in range(0,256,16):m[page+offset+8]=0
    for offset in range(0,96,16):m[0x688+offset]=0
    for offset in range(0,64,16):m[0x600+offset]=0
    for addr in (0x640,0x647,0x650,0x660,0x67D,0x9D,0x9E,0x9F):m[addr]=0

# Title reaches all four options and starts Evil Mode.
fresh()
for expected in (1,2,3,0,1,2,3):
    frame(0x20);assert m[0x8E]==expected
    m.ppu_writes=[];frame()
    title=dict(m.ppu_writes)
    text=('ARCADE MODE','BOUNCY MODE','DRUNK MODE','EVIL MODE')[expected].ljust(12)
    want=[0 if ch==' ' else 0x61+ord(ch)-65 for ch in text]
    assert [title[0x21EA+i] for i in range(12)]==want
frame(0x10);assert m[6]==1 and m[0x8E]==3

# Evil medium/small turn one heading step toward the same target every four ticks
# and reload normal speed from their respective existing tables; large stays straight.
for page in (0x300,0x400,0x500):
    tag=f'{page:04x}'
    for kind,prefix in ((2,'m'),(3,'s')):
        base=page+0x20
        m[0x11]=128;m[0x13]=120
        m[base:base+16]=[0,0,0,120,0,0,0,0,kind,24,0,0,0,0,0,0]
        c.x=0x20;call(f'evil_tick{tag}')
        first=m[base+9];assert first in (23,25),first
        assert m[base+11]==4
        for off,component in ((4,'xlo'),(5,'xhi'),(6,'ylo'),(7,'yhi')):
            assert m[base+off]==m[S[prefix+component]+first]
        for _ in range(3):call(f'evil_tick{tag}')
        assert m[base+9]==first and m[base+11]==1
        call(f'evil_tick{tag}')
        assert m[base+11]==4 and m[base+9] != first
    base=page+0x40;m[base:base+16]=[0,0,0,120,13,1,9,1,1,12,0,0,0,0,0,0]
    c.x=0x40;before=m[base:base+16];call(f'evil_tick{tag}');assert m[base:base+16]==before

# In Evil, regular rocks still wrap instead of bouncing.
clear_all();m[6]=1;m[0x8E]=3
m[0x300:0x310]=[0,255,0,100,0,1,0,0,1,12,0,0,0,0,0,0]
call('asteroids');assert m[0x301]==0 and m[0x305]==1

# The visible two-digit debug value is the weighted performance score.
clear_all();m[0x300+8]=1;m[0x708]=1
for offset in range(0,64,16):m[0x600+offset]=1
for offset in range(0,96,16):m[0x688+offset]=1
m[0x640]=1;m[0x647]=1;m[0x67D]=5;m[0x9D]=14
call('debug_objects31a');assert m[0x9E]==45,m[0x9E]
m[0]=1;m.ppu_writes=[];nmi_once()
digits=[(a,v) for a,v in m.ppu_writes if 0x238F<=a<=0x2390]
assert digits==[(0x238F,0x7F),(0x2390,0x80)],digits
# Saturate, rather than displaying a broken three-digit value.
for page in (0x300,0x400,0x500):
    for off in range(0,256,16):m[page+off+8]=3
for off in range(0,96,16):m[0x688+off]=1
for off in range(0,256,16):m[0x708+off]=1
m[0x9D]=14;call('debug_objects31a');assert m[0x9E]==99
print('PASS V33: four-mode title; Evil medium/small four-frame homing and normal speed; large/wrap exclusion; weighted 4-UFO/5-Murderoid counter')
