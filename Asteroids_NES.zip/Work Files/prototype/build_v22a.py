"""Repair V22 burst visibility, order, speed and final-life updates."""
from pathlib import Path
import math
P=Path(__file__).parent
exec(compile((P/'build_v22.py').read_text(),str(P/'build_v22.py'),'exec'))
def change22a(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)
change22('main_gameover22:\nJSR asteroids','main_gameover22:\nJSR death_explosion_tick22\nJSR asteroids')
# Render reserved fragments after the bullet pass has hidden empty bullet slots.
change22a('LDA $067D\nBEQ render_no_death_burst22\nJSR render_death_burst22\nrender_no_death_burst22:\n','')
change22a('JSR render_ufo\nJSR render_asteroids\nRTS','''LDA $067D
BEQ render_burst_done22a
JSR render_death_burst22
render_burst_done22a:
JSR render_ufo
JSR render_asteroids
RTS''')
change22a('[0x1F]*5+[0x1E]*5+[0x1D]*5+[0x1C]*5+[0x1B]*5','[0x1B]*5+[0x1C]*5+[0x1D]*5+[0x1E]*5+[0x1F]*5')
# One random heading per quadrant guarantees four distinct outward paths.
change22a('JSR random\nAND #$2F\nTAY\nLDA bxlo,Y','''death_heading_retry22a:
JSR random
AND #$0F
CMP #$0C
BCS death_heading_retry22a
STA $7B
TXA
LSR A
LSR A
LSR A
TAY
LDA death_quadrants22a,Y
CLC
ADC $7B
TAY
LDA death_xlo22a,Y''')
for old,new in [('bxhi','death_xhi22a'),('bylo','death_ylo22a'),('byhi','death_yhi22a')]:
    # Restrict velocity substitutions to the fragment initializer.
    a=source.index('death_burst_start22:');b=source.index('death_explosion_tick22:',a)
    source=source[:a]+source[a:b].replace('LDA '+old+',Y','LDA '+new+',Y')+source[b:]
tables={'death_quadrants22a':[0,12,24,36]}
for axis,fn in [('x',math.sin),('y',lambda a:-math.cos(a))]:
    v=[round(256*fn(h*math.tau/48))&65535 for h in range(48)]
    tables['death_'+axis+'lo22a']=[n&255 for n in v]
    tables['death_'+axis+'hi22a']=[n>>8 for n in v]
change22a('asm=Assembler(MPU());','data.update('+repr(tables)+')\nasm=Assembler(MPU());')
for old,new in [('asteroids_nes_v22_gameover.nes','asteroids_nes_v22a_explosion_fix.nes'),('prototype_v22.asm','prototype_v22a.asm'),('symbols_v22.json','symbols_v22a.json')]:
    change22a(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
