"""V28: UFO respawn gate and two-palette shield."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v27.py').read_text(),str(P/'build_v27.py'),'exec'))
def change28(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)
change28('death_check_depart21:\n','death_check_depart21:\nLDA $0640\nBNE death_return21\n')
change28('0x0f,0x30,0x12,0x2a, 0x0f,0x30,0x16,0x2a]',
         '0x0f,0x30,0x12,0x2a, 0x0f,0x24,0x37,0x2a]')
# $8D counts rendered shield frames, independent of timer decrement order.
# This gives both manual and respawn shields exactly four frames per palette.
for duration in ('3C','B4'):
    change28('LDA #$'+duration+'\nSTA $08',
             'LDA #$'+duration+'\nSTA $08\nLDA #$00\nSTA $8D')
change28('LDA $08\nBEQ ship_normal_palette\nLSR A\nLSR A\nAND #$03',
         'LDA $08\nBEQ ship_normal_palette\nLDA $8D\nINC $8D\nLSR A\nLSR A\nAND #$01\nBEQ ship_palette_done\nLDA #$03')
change28('ship_normal_palette:\nLDA #$00','ship_normal_palette:\nLDA #$00\nSTA $8D')
for old,new in [('asteroids_nes_v27_ship_sfx.nes','asteroids_nes_v28_respawn_shield.nes'),('symbols_v27.json','symbols_v28.json'),('prototype_v27.asm','prototype_v28.asm')]:change28(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
