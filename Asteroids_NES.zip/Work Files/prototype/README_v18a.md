# V18a — small-asteroid pickup drops

Only destruction of a small asteroid advances pickup parity. Every second small asteroid drops the next item. Large/medium asteroids and UFOs do not advance the counter. All other V18 behavior is retained; see README_v18.md for the original features and memory map. This rule supersedes its all-size drop rule.

Build: `python prototype/build_v18a.py`

Tests:
```
python prototype/test_v18a.py
python prototype/test_full_wave.py 18a 100 4
python prototype/test_full_wave.py 18a 100 12
```

The pickup regression interleaves large and medium kills between small kills, checks that those kills award points without advancing pickup parity/order, then verifies every second small kill produces the expected item. The existing pickup timing, collection, speed, rendering and wave regressions run against the new ROM.

Start the new ROM fresh rather than loading an older ROM's save state.
