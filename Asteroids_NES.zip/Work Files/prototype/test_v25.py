"""Execute V25 SFX envelopes and destruction-path selection."""
from pathlib import Path
P=Path(__file__).parent
base=(P/'test_v24d.py').read_text().replace('symbols_v24d.json','symbols_v25.json').replace('asteroids_nes_v24d_cached_tempo.nes','asteroids_nes_v25_core_sfx.nes')
exec(compile(base,str(P/'test_v24d.py'),'exec'))

def reset_sfx():
    m[0x82:0x86]=[0,0,0,0]
    m[0x4015]=0

reset_sfx();call('sfx_shot_start25')
assert (m[0x82],m[0x83],m[0x4000],m[0x4002])==(11,1,0xBF,0x8E)
timers=[];volumes=[]
for _ in range(11):
    call('sfx_tick25');timers.append(m[0x4002]);volumes.append(m[0x4000]&15)
assert timers==[0x90,0x93,0x95,0x98,0x9A,0x9D,0x9F,0xA2,0xA4,0xA7,0xA9]
assert volumes==[14,13,12,10,9,8,6,5,4,2,0] and not m[0x4015]&1
print('PASS normal/rainbow shot is a 12-frame G5→E5 pulse fade and retriggers')

for kind,period in ((1,14),(2,13),(3,12)):
    reset_sfx();m[0x82]=4;c.a=kind;call('sfx_asteroid_start25')
    assert m[0x85]==period and m[0x84]==30 and (m[0x400c]&15)==15 and m[0x4015]&8
    for _ in range(30):call('sfx_tick25')
    assert m[0x84]==0 and not m[0x4015]&8
print('PASS all asteroid sizes use 30-frame #14/#13/#12 noise fades')

# Each actual player collision path chooses its destroyed record's size.
for kind,period in ((1,14),(2,13),(3,12)):
    clear();reset_sfx();m[0x308]=kind;m[0x301]=60;m[0x303]=70
    m[0x600:0x610]=[47,0,64,0,74,0,0,0,0,0,12,0,0,0,0,0]
    call('collisions');assert m[0x85]==period,(kind,m[0x85])
for kind,period in ((1,14),(2,13),(3,12)):
    reset_sfx();m[0x680:0x690]=[0,40,0,60,0,0,0,0,kind,0,0,0,0,0,0,0]
    c.x=0;call('murder_destroy');assert m[0x85]==period,(kind,m[0x85])
reset_sfx();m[0x3d]=3;m[0x677]=0;call('player_kill21');assert m[0x85]==15 and m[0x84]==30
print('PASS regular/Murderoid sizes and Player One death select their requested noise sounds')
