"""Drunk mode: record +B timer, +C steps remaining, +D turn direction.
No new RAM allocation; these bytes are unused within regular asteroid records.
Mode 0=Arcade, 1=Bouncy, 2=Drunk. Existing counter stays unchanged.
"""
import re
patch31('LDA $8E\nEOR #$01\nSTA $8E','''LDA $8E
CLC
ADC #$01
CMP #$03
BCC mode_ready32
LDA #$00
mode_ready32:
STA $8E''')
data['mode_text31']=sum((glyphs31(s.ljust(12)) for s in ('ARCADE MODE','BOUNCY MODE','DRUNK MODE')),[])
patch31('''LDX #$00
LDA $8E
BEQ nmi_mode_loop31
LDX #$0C
nmi_mode_loop31:
LDA mode_text31,X
STA $2007
INX
CPX #$0C
BEQ nmi_mode_end31
CPX #$18
BNE nmi_mode_loop31''','''LDA $8E
ASL A
ASL A
STA $9B
ASL A
CLC
ADC $9B
TAX
LDY #$0C
nmi_mode_loop31:
LDA mode_text31,X
STA $2007
INX
DEY
BNE nmi_mode_loop31''')
# All Bouncy wrappers must test mode==1, not merely nonzero.
code,n=re.subn(r'LDA \$8E\nBEQ (\w+_arcade31)',r'LDA $8E\nCMP #$01\nBNE \1',code)
assert n==10,n
# Reused parent/child slots start a fresh independent turning run.
patch31('write_fragment:\n','''write_fragment:
LDA #$00
LDY #$0B
STA ($43),Y
INY
STA ($43),Y
INY
STA ($43),Y
''')
for page in (0x300,0x400,0x500):
    tag=f'{page:04x}'
    patch31(f'rock{tag}_arcade31:\n',f'''rock{tag}_arcade31:
LDA $8E
CMP #$02
BNE drunk_skip{tag}
LDA $06
BEQ drunk_skip{tag}
JSR drunk_tick{tag}
drunk_skip{tag}:
''')
    def addr(off):return f'${page+off:04X},X'
    routine=f'''drunk_tick{tag}:
LDA {addr(8)}
BNE drunk_active{tag}
RTS
drunk_active{tag}:
LDA {addr(12)}
BNE drunk_timer{tag}
drunk_choose{tag}:
JSR random
AND #$0F
CMP #$0C
BCS drunk_choose{tag}
CLC
ADC #$01
STA {addr(12)}
JSR random
AND #$01
STA {addr(13)}
LDA #$05
STA {addr(11)}
drunk_timer{tag}:
DEC {addr(11)}
BEQ drunk_turn{tag}
RTS
drunk_turn{tag}:
LDA #$05
STA {addr(11)}
DEC {addr(12)}
LDA {addr(13)}
BEQ drunk_ccw{tag}
LDA {addr(9)}
CLC
ADC #$01
CMP #$30
BCC drunk_heading{tag}
LDA #$00
BEQ drunk_heading{tag}
drunk_ccw{tag}:
LDA {addr(9)}
BNE drunk_dec{tag}
LDA #$30
drunk_dec{tag}:
SEC
SBC #$01
drunk_heading{tag}:
STA {addr(9)}
TAY
LDA {addr(8)}
CMP #$01
BEQ drunk_large{tag}
CMP #$02
BEQ drunk_medium{tag}
'''
    for kind,prefix in (('small','s'),('medium','m'),('large','l')):
        routine+=f'drunk_{kind}{tag}:\n'
        for off,component in ((4,'xlo'),(5,'xhi'),(6,'ylo'),(7,'yhi')):
            routine+=f'LDA {prefix}{component},Y\nSTA {addr(off)}\n'
        routine+='RTS\n'
    code+='\n'+routine
lines=[s.strip() for s in code.splitlines() if s.strip()]
