"""V36 controls and adaptive scheduler regression checks."""
import json
from pathlib import Path
from py65.devices.mpu6502 import MPU
P=Path(__file__).parent
S=json.loads((P/'symbols_v36.json').read_text())
ROM=(P/'asteroids_nes_v36_controls_cleanup.nes').read_bytes()[16:32784]
class Memory(list):
    def __init__(self):super().__init__([0]*65536);self.writes=[]
    def __getitem__(self,k):return 0x80 if k==0x2002 else super().__getitem__(k)
    def __setitem__(self,k,v):
        if k==0x2007:self.writes.append(v)
        super().__setitem__(k,v)
def fresh():
    m=Memory();m[0x8000:]=ROM;c=MPU(memory=m);return m,c
def call(m,c,name):
    c.pc=S[name];c.sp=255;c.stPushWord(0x7ffe)
    for _ in range(200000):
        c.step()
        if c.pc==0x7fff:return
    raise AssertionError(name+' timeout')
def controls(m,c,pad):
    m[6]=1;m[0x677]=0;m[2]=0;m[1]=pad;call(m,c,'game_controls')
for pad in (0x44,0x48):
    m,c=fresh();m[7]=5;m[0x14:0x18]=[37,1,203,255]
    controls(m,c,pad)
    assert m[7]==4 and m[0x14:0x18]==[0,0,0,0],hex(pad)
print('PASS B+Down and B+Up both brake, consume one SUPER, zero both velocities')
m,c=fresh();m[3]=7;m[7]=5;m[1]=0x04;m[2]=0;call(m,c,'game_controls')
assert m[3]==31 and m[7]==5
m[1]=0x44;m[2]=0;call(m,c,'game_controls')
assert m[3]==31 and m[7]==4
print('PASS Down alone flips 180 degrees, then B+Down brakes without undoing flip')
m,c=fresh();m[7]=5;controls(m,c,0x48)
assert m[7]==4 and not any(m[0x600:0x640])
print('PASS retired B+Up rainbow cannot create projectiles')

# The weighted tally still drives adaptive timing with the confirmed 22/15
# thresholds, while its old PPU dirty flag is never set.
for mode in range(4):
    m,c=fresh();m[6]=1;m[0x8E]=mode;entry=22 if mode==0 else 15
    m[0x9E]=entry;call(m,c,'frame_begin34');assert m[0xA1:0xA4]==[2,2,2]
    m[0x9E]=0;call(m,c,'frame_begin34');assert m[0xA1]==1
    m[0x9F]=0;m[0x9D]=14;call(m,c,'debug_objects31a');assert m[0x9F]==0
print('PASS adaptive scheduler retains weighted thresholds; counter is not rendered')

# Score math, Murderdroid retreat, stars and full V35 behavioral regression.
suite=(P/'test_v35.py').read_text().replace('symbols_v35.json','symbols_v36.json').replace('asteroids_nes_v35_starfield.nes','asteroids_nes_v36_controls_cleanup.nes')
suite=suite.replace("suite=(P/'test_v34.py').read_text()", "suite='' # V34 includes removed counter-display assertions")
suite=suite.replace("exec(compile(suite,str(P/'test_v34.py'),'exec'),{'__file__':str(P/'test_v34.py')})", "")
exec(compile(suite,str(P/'test_v35.py'),'exec'),{'__file__':str(P/'test_v35.py')})
