"""Patch expanded assembly before relocation; original movement retained.
ZP $8E mode (0 arcade,1 bouncy), $8F-$99 bounce scratch,
$9A title dirty, $9B saved X, $9C optional record-relative heading offset.
"""
code='\n'.join(lines)
def patch31(old,new):
    global code
    assert code.count(old)==1,(old,code.count(old))
    code=code.replace(old,new,1)
def glyphs31(s):return [0 if c==' ' else 0x61+ord(c)-65 for c in s]
patch31('LDA $00\nBEQ nmi_done\nLDA #$00\nSTA $2003',
        'LDA $00\nBNE nmi_active31\nJMP nmi_done\nnmi_active31:\nLDA #$00\nSTA $2003')
title=sum([list(data['title_nt'+str(i)]) for i in range(4)],[])
needle=glyphs31('ARCADE')
matches=[i for i in range(960-6) if title[i:i+6]==needle]
assert len(matches)==1,matches
row=matches[0]//32
title[row*32:(row+1)*32]=[0]*32
title[row*32+10:row*32+22]=glyphs31('ARCADE MODE ')
# Slice assignment uses 11+1 characters, both menu entries fixed width 12.
for i in range(4):data['title_nt'+str(i)]=title[i*256:(i+1)*256]
data['mode_text31']=glyphs31('ARCADE MODE '+'BOUNCY MODE ')
address=0x2000+row*32+10
patch31('LDA $06\nBNE game_controls\nLDA $02',
'''LDA $06
BNE game_controls
LDA $02
EOR #$FF
AND $01
AND #$20
BEQ title_start_check31
LDA $8E
EOR #$01
STA $8E
LDA #$01
STA $9A
title_start_check31:
LDA $02''')
patch31('nmi_hud_done:\n',f'''nmi_hud_done:
LDA $06
BNE nmi_mode_done31
LDA $9A
BEQ nmi_mode_done31
LDA #${address>>8:02X}
STA $2006
LDA #${address&255:02X}
STA $2006
LDX #$00
LDA $8E
BEQ nmi_mode_loop31
LDX #$0C
nmi_mode_loop31:
LDA mode_text31,X
STA $2007
INX
CPX #$0C
BEQ nmi_mode_end31
CPX #$18
BNE nmi_mode_loop31
nmi_mode_end31:
LDA #$00
STA $9A
nmi_mode_done31:
''')

wrappers=[]
def movement31(start,end,name,base,indexed,width=8,kind=None,heading=None,active=None):
    """Branch before original addition, return to original continuation."""
    a=code.index(start)+len(start);b=code.index(end,a)
    original=code[a:b]
    suffix=',X' if indexed else ''
    # Gameplay check also keeps all title rocks on their original wrap paths.
    prefix=f'''LDA $8E
BEQ {name}_arcade31
LDA $06
BEQ {name}_arcade31
JSR {name}_bounce31
JMP {name}_moved31
{name}_arcade31:
'''
    patch31(start+original+end,start+prefix+original+f'{name}_moved31:\n'+end)
    w=f'''{name}_bounce31:
STX $9B
'''
    if active is not None:
        w+=f'LDA ${active:04X}{suffix}\nBNE {name}_active31\nRTS\n{name}_active31:\n'
    if indexed:
        w+=f'TXA\nCLC\nADC #${base&255:02X}\nSTA $8F\nLDA #${base>>8:02X}\nADC #$00\nSTA $90\n'
    else:w+=f'LDA #${base&255:02X}\nSTA $8F\nLDA #${base>>8:02X}\nSTA $90\n'
    if kind is not None:
        # Medium artwork is centered inside a 16x16 metasprite canvas.
        w+=f'LDA ${kind:04X}{suffix}\nCMP #$03\nBEQ {name}_small31\nCMP #$02\nBEQ {name}_medium31\nLDA #$10\nBNE {name}_size31\n{name}_medium31:\nLDA #$0C\nBNE {name}_size31\n{name}_small31:\nLDA #$08\n{name}_size31:\n'
    else:w+=f'LDA #${width:02X}\n'
    w+='STA $92\n'
    w+=f'LDA #${heading if heading is not None else 255:02X}\nSTA $9C\nJSR bounce_step31\nLDX $9B\nRTS\n'
    wrappers.append(w)

movement31('physics:\n','RTS\nbullets:', 'ship',0x10,False)
movement31('bullet_flying:\nDEC $0600,X\n','bullet_next:', 'shot',0x601,True,width=4,heading=9)
for page in (0x300,0x400,0x500):
    movement31(f'asteroid_grace_done{page:04x}:\n','TXA\nCLC\nADC #$10\nTAX\nBNE asteroid_loop'+f'{page:04x}',
               f'rock{page:04x}',page,True,kind=page+8,heading=9,active=page+8)
movement31('pickup_animation_done:\n','pickup_tick_next:', 'pickup',0x700,True)
movement31('murder_move:\n','murder_tick_next:', 'murder',0x680,True,kind=0x688,heading=9)
for label,base in [('ufo_shot_live',0x651),('ufo_shot_live2',0x661)]:
    movement31(label+':\nDEC $'+f'{base-1:04X}'+'\n','RTS',label,base,False,width=4,heading=8)
movement31('death_explosion_move22:\n','TXA\nCLC\nADC #$08','debris',0x6e0,True)

# Record schema: xfrac,xint,yfrac,yint,vxfrac,vxint,vyfrac,vyint.
# Signed carry detection catches wrapping before any 8-bit coordinate is lost.
# Clamp to contact and negate only the component directed into the wall.
core='''bounce_step31:
LDA #$00
STA $98
STA $93
STA $91
LDA #$01
STA $99
LDA #$00
SEC
SBC $92
STA $92
JSR bounce_axis31
LDA $92
SEC
SBC #$10
STA $92
LDA #$10
STA $91
LDA #$02
STA $93
STA $99
JSR bounce_axis31
LDY $9C
CPY #$FF
BEQ bounce_done31
LDA $98
BEQ bounce_done31
AND #$01
BEQ bounce_heading_y31
LDA #$30
SEC
SBC ($8F),Y
CMP #$30
BCC bounce_heading_x_save31
LDA #$00
bounce_heading_x_save31:
STA ($8F),Y
bounce_heading_y31:
LDA $98
AND #$02
BEQ bounce_done31
LDA #$18
SEC
SBC ($8F),Y
BCS bounce_heading_y_save31
CLC
ADC #$30
bounce_heading_y_save31:
STA ($8F),Y
bounce_done31:
RTS
bounce_axis31:
LDA $93
CLC
ADC #$04
TAY
LDA ($8F),Y
STA $96
INY
LDA ($8F),Y
STA $97
LDY $93
LDA ($8F),Y
CLC
ADC $96
STA $94
INY
LDA ($8F),Y
ADC $97
STA $95
LDA $97
BMI bounce_negative31
BCS bounce_high31
JMP bounce_bounds31
bounce_negative31:
BCC bounce_low31
bounce_bounds31:
LDA $95
CMP $91
BCC bounce_low31
CMP $92
BCC bounce_store31
BNE bounce_high31
LDA $94
BEQ bounce_store31
bounce_high31:
LDA $92
STA $95
LDA #$00
STA $94
LDA $97
BMI bounce_store31
JMP bounce_reverse31
bounce_low31:
LDA $91
STA $95
LDA #$00
STA $94
LDA $97
BPL bounce_store31
bounce_reverse31:
LDA #$00
SEC
SBC $96
STA $96
LDA #$00
SBC $97
STA $97
LDA $93
CLC
ADC #$04
TAY
LDA $96
STA ($8F),Y
INY
LDA $97
STA ($8F),Y
LDA $98
ORA $99
STA $98
bounce_store31:
LDY $93
LDA $94
STA ($8F),Y
INY
LDA $95
STA ($8F),Y
RTS
'''
code+='\n'+'\n'.join(wrappers)+core
lines=[s.strip() for s in code.splitlines() if s.strip()]
