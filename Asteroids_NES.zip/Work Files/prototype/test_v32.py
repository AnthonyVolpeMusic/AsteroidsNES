"""Run inherited movement/counter regressions against V32, then Drunk tests."""
from pathlib import Path
P=Path(__file__).parent
suite=(P/'test_v31c.py').read_text().replace('symbols_v31c.json','symbols_v32.json').replace('asteroids_nes_v31c_bouncy_debug.nes','asteroids_nes_v32_drunk.nes').replace('for mode in (0,1):','for mode in (0,1,2):')
exec(compile(suite,str(P/'test_v31c.py'),'exec'))

fresh()
for expected in (1,2,0,1,2):
    frame(0x20);assert m[0x8E]==expected
    m.ppu_writes=[];frame()
    title=dict(m.ppu_writes)
    text=('ARCADE MODE','BOUNCY MODE','DRUNK MODE')[expected].ljust(12)
    want=[0 if ch==' ' else 0x61+ord(ch)-65 for ch in text]
    assert [title[0x21EA+i] for i in range(12)]==want
frame(0x10);assert m[6]==1 and m[0x8E]==2
for page in (0x300,0x400,0x500):
    for kind,prefix in ((1,'l'),(2,'m'),(3,'s')):
        for direction in (0,1):
            for heading in range(48):
                base=page+0x20;c.x=0x20
                m[base+8]=kind;m[base+9]=heading
                m[base+11]=5;m[base+12]=2;m[base+13]=direction
                routine=f'drunk_tick{page:04x}'
                for _ in range(4):call(routine)
                assert m[base+9]==heading
                call(routine)
                target=(heading+(1 if direction else -1))%48
                assert m[base+9]==target and c.x==0x20
                assert m[base+11]==5 and m[base+12]==1
                for off,component in ((4,'xlo'),(5,'xhi'),(6,'ylo'),(7,'yhi')):
                    assert m[base+off]==m[S[prefix+component]+target]
    # Fresh run selection range, cadence, and inactive-slot immunity.
    c.x=0;m[page+8]=1;m[page+9]=0
    for seed in range(1,256):
        m[0x2F]=seed;m[page+12]=0
        call(f'drunk_tick{page:04x}')
        assert 1<=m[page+12]<=12 and m[page+13] in (0,1) and m[page+11]==4
    m[page+8]=0;before=m[page:page+16]
    call(f'drunk_tick{page:04x}');assert m[page:page+16]==before

# New fragments, including reused parent slots, reset their own turning state.
m[0x43]=0x10;m[0x44]=4;m[0x2D]=2;m[0x2E]=0;m[0x47]=80;m[0x48]=80
m[0x41B]=3;m[0x41C]=9;m[0x41D]=1
call('write_fragment');assert m[0x41B:0x41E]==[0,0,0]

# Drunk ship and regular asteroid still wrap, rather than reflect.
clear_objects();m[6]=1;m[0x8E]=2
m[0x10:0x18]=[0,255,0,100,0,1,0,0]
call('physics');assert m[0x11]==0 and m[0x15]==1
m[0x300:0x310]=[0,255,0,100,0,1,0,0,3,12,0,5,2,1,0,0]
call('asteroids');assert m[0x301]==0 and m[0x305]==1
print('PASS Drunk: menu cycling/text; all headings/sizes/banks/directions; five-frame cadence; speed tables; fresh fragment state; wrap behavior')

# Integrated NMI/main-loop run with shooting, steering and thrust.
fresh();frame(0x20);frame();frame(0x20);frame();frame(0x10)
for tick in range(360):
    frame((0x80 if tick%12<6 else 0)|0x08|0x01)
    assert m[0x8E]==2
    for base in range(0x300,0x600,16):
        if m[base+8]:
            assert m[base+9]<48
            assert m[base+12]<=12
assert any(a==0x238F for a,v in m.ppu_writes)
print('PASS 360 integrated gameplay frames with bottom counter writes')
