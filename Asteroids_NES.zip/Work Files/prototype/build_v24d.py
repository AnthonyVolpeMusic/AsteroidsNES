"""V24d: cache medium-progress interval in reserved zero-page $81."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v24c.py').read_text(),str(P/'build_v24c.py'),'exec'))
def change24d(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)

# Move the existing threshold computation out of the note player, keeping
# identical comparisons and tempo values. Only the shared medium kill path
# calls it. It touches A and the existing ephemeral $7B/$7D, not X/Y/pointers.
a=source.index('pulse_due24c:\n')
b=source.index('pulse_fire24:\n',a)
calculation=source[a:b].replace('pulse_due24c:\n','pulse_recalculate24d:\n',1)
calculation=calculation.replace('BEQ asteroid_pulse_off24','BEQ pulse_default24d')
calculation=calculation.replace('LDA #$30\nJMP pulse_interval24','pulse_default24d:\nLDA #$30\nJMP pulse_interval24')
calculation+='STA $81\nRTS\n'
source=source[:a]+'pulse_due24c:\nLDA $81\n'+source[b:]
change24d('shield_tick:\n',calculation+'shield_tick:\n')
change24d('spawn_smalls_generic:\nINC $7E','spawn_smalls_generic:\nINC $7E\nJSR pulse_recalculate24d')
change24d('STA $7E\nSTA $7C\nLDA $3F','STA $7E\nSTA $7C\nLDA #$30\nSTA $81\nLDA $3F')
for old,new in [('asteroids_nes_v24c_audio_optimized.nes','asteroids_nes_v24d_cached_tempo.nes'),('symbols_v24c.json','symbols_v24d.json'),('prototype_v24c.asm','prototype_v24d.asm')]:change24d(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
