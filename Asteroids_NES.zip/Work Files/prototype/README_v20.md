# V20 — magnet and visible pickup attraction

Based on the confirmed V19b build. Player One remains invincible for this playtest.

## Gameplay

Murderoids first become eligible on level 3. The first-family trigger remains three or fewer regular asteroids; farthest-wall spawning and the ten-second replacement timer remain unchanged.

The exact 24-item pickup order is:

`250, 500, 250, 750, 250, 500, 250, 1000, Shot Speed, Extra SUPER, 500, Magnet, 750, 500, 1000, 2000, 500, 750, Extra SUPER, 1000, 2000, 1000, 3000, 5000`

Pickup capture starts at 24x24, centered on the ship. Each magnet increases it to 32x32, then 40x40, then 48x48. Magnet levels persist between waves and reset on a new game or the prepared future player-death hook. Reaching level three converts existing uncollected magnets to 1000-point pickups; future magnet drops also use the 1000-point artwork and award. A defensive capped-magnet collection path awards 1000 as well.

All pickups, including those captured by the starting 24x24 area, now remain visible and fly into the ship. Entering the capture area latches attraction. Items track the ship every update, including across wrap boundaries, and remain attracted if the ship moves outside the original area. Actual sprite contact awards the effect exactly once. Attracted items freeze their expiry timer and cease expiry blinking while retaining their two-frame animation. Freely drifting pickups retain the five-second steady/two-second blinking lifetime.

Ship velocity is capped independently at two pixels per update on each axis; its fastest diagonal magnitude is sqrt(8). Attracted pickup speed is 981/256 (about 3.832 pixels/update), just over one pixel/update faster than that diagonal maximum. The existing 48-heading aiming table sets direction.

Sixteen pickup records remain available. Captured items cannot be replaced by a new drop. When all slots hold attracted items, that drop is skipped and its sequence entry is retained for the next eligible drop. Otherwise an unused slot or the oldest drifting item is used, as before.

The magnet uses the supplied 8x8 artwork with red $16 alternating with purple $24 every ten updates; the white $30 poles remain white. Black is transparent.

## Implementation and validation

New state: $0676 magnet level (0..3); pickup-record offset $0D attraction flag; $69 saved pickup index; $6A/$6B capture limits; $6C/$6D decimal-score scratch. Sprite tiles $41/$42 store magnet frames. The 70-record OAM rotation and protected ship/projectile slots remain.

Simultaneous high-value arrivals exposed the cost of the previous per-point display-score increment loop. V20 adds each score chunk directly to the decimal digits, preserving binary totals, six-digit display wrapping and extra-life thresholds. The simultaneous 12,500-point test finishes its movement/collection work within 20,000 CPU cycles.

Build and tests (Python 3, Pillow, py65):

```sh
python prototype/build_v20.py
python prototype/test_v20.py
python prototype/test_full_wave.py 20 100 4
python prototype/test_full_wave.py 20 100 12
```

Tests cover actual-hit drop order; every capture-size boundary and wrap; delayed awards and visible flight; pursuit of maximum-speed diagonal motion; frozen expiry; magnet cap and replacement artwork; wave persistence/death reset; full-pool attraction protection; simultaneous awards; decimal carries and extra lives; encoded magnet artwork; drifting animation/lifetime; level-three hunter trigger; hunter lineage and 3,100-point accounting; overlap and grace behavior; OAM rotation; and the ten-second respawn timer. Regular-wave tests verify 2,100 and 6,300 points across 100 seeds each.

These tests execute assembled 6502 code rather than a cycle-accurate PPU emulator. Start V20 fresh instead of loading an older save state, and check the suction feel, magnet upgrades, and level-three Murderoid appearance in OpenEmu.
