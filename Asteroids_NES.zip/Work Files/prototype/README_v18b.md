# V18b — finalized pickup system

The 24-item small-asteroid pickup order is:

`250, 500, 250, 750, 250, 500, 250, 1000, Shot Speed, Extra SUPER, 250, 500, 750, 500, 1000, 2000, 500, 750, Extra SUPER, 1000, 2000, 1000, 3000, 5000`

Every second small asteroid drops the next item. Large asteroids, medium asteroids, and UFOs do not change the pickup counter. The counter resets at every new wave and has an explicit Player One death reset hook; the current game keeps Player One invincible, so that hook awaits the future death dispatcher.

Extra SUPER adds one point to the five-point SUPER meter, capped at five. It uses sprite palette 2: white `$30`, blue `$12`, green `$2A`. The 2000, 3000, and 5000 point items share that palette. All pickups retain V18a’s two-frame 10-refresh animation, lifetime, blinking, drift, pickup collection box, and OAM rotation.

Build with `python prototype/build_v18b.py`. Run `python prototype/test_v18b.py`, `python prototype/test_full_wave_v18b.py 100 4`, and `python prototype/test_full_wave_v18b.py 100 12`.
