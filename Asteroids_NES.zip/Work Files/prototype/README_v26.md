# V26 event sound effects

Branches from confirmed V25b. Build with Python 3, Pillow and py65:
`python3 prototype/build_v26.py`. Test: `python3 prototype/test_v26.py`.

Pulse 2 uses 50% duty and volume 15, with these sequences:

| Event | Sequence | Frames |
|---|---|---:|
| Large UFO arrival | C4 to E5 in 6, back in 6; four cycles | 48 |
| Small UFO arrival | A4 to C6 in 6, back in 6; four cycles | 48 |
| Large Murderoid arrival | G4 for 5, D5 for 5; six cycles | 60 |
| Pickup collected | D#4 to D#5 | 12 |
| UFO shot | A3 for 4, A2 for 4; three cycles | 24 |
| Extra life | G6 for 5, silence for 5; five cycles | 50 |

Glides use evenly spaced semitone steps sampled once per game update, including
both endpoints, with NTSC timer values calculated during the build. No runtime
pitch calculations. Timer high bytes are written only on change or retrigger.

Priority: extra life > Murderoid arrival > UFO arrival > pickup > UFO shot.
Higher priority interrupts; equal priority restarts; lower requests are dropped.
No queued/resumed effects. Pulse 1, triangle and noise keep independent state.

Large UFO death selects noise #13; small selects #12. Both fade for 30 updates.
Noise retains the latest-event-wins policy. When a UFO and asteroid destroy each
other on the same update, the asteroid's subsequent noise event wins.

New reserved zero-page RAM: $87 current effect, $88 table index, $89 duration,
$8A previous high timer, $8B request scratch. Startup and results/replay clear
the state. Event requests preserve A/X/Y and flags. Six sequences occupy 242
entries in three byte tables plus offset/length/priority metadata.

Validation: assembled-ROM CPU tests pass for all sequence lengths, fixed notes,
glide endpoints, repetitions, extra-life silent intervals, all 36 priority
combinations, four enabled audio channels, UFO death collision/fades, both UFO
shot slots and arrival sizes, Murderoid spawn, collection, extra-life and reset
hooks. V25b inter-wave and V25a audio regressions also pass on the new ROM.
Pulse 2 ticking measured 41–64 CPU cycles in the large-UFO sequence test,
excluding caller JSR; this is not a full-game performance benchmark.

The harness models APU enable and length-load semantics, not synthesized audio.
OpenEMU listening/playtesting is still required, especially overlapping events.
Timing follows existing game updates and will stretch if gameplay slows down.

Historical builders are included because the build chain uses them. V25 ROM is
included solely for the known-bug regression test; play the V26 ROM.
