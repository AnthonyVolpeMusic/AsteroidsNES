"""V22 player death burst and five-second live GAME OVER display."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v21.py').read_text(),str(P/'build_v21.py'),'exec'))
def change22(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)

# State 2 is the active five-second Game Over period; state 3 is its hold.
change22('''LDA $0677
CMP #$02
BEQ main_render21
JSR controls''','''LDA $0677
CMP #$02
BEQ main_gameover22
CMP #$03
BEQ main_render21
JSR controls''')
change22('''main_title21:
JSR asteroids
main_render21:''','''main_gameover22:
JSR asteroids
JSR murder_depart_or_tick21
JSR pickups_tick
JSR ufo_tick
JSR enemy_rocks21
JSR murder_spawn_check
JSR wave_tick
JSR gameover_tick22
JMP main_render21
main_title21:
JSR asteroids
main_render21:''')
change22('''main_dead21:
JSR asteroids
JSR murder_depart_or_tick21''','''main_dead21:
JSR asteroids
JSR death_explosion_tick22
JSR murder_depart_or_tick21''')
# Show the center text only while the five-second countdown is active/held.
change22('''nmi_hud_done:
LDA #$00
STA $2005''','''nmi_hud_done:
LDA $067C
BEQ nmi_gameover_done22
LDA #$21
STA $2006
LDA #$EB
STA $2006
LDX #$00
nmi_gameover_text22:
LDA gameover_text22,X
STA $2007
INX
CPX #$09
BNE nmi_gameover_text22
nmi_gameover_done22:
LDA #$00
STA $2005''')
# Reserve OAM 0..3 for the four death fragments whenever one is active.
change22('''render_game:
LDA $0677
BEQ render_alive21
JMP render_player_bullets21''','''render_game:
LDA $067D
BEQ render_no_death_burst22
JSR render_death_burst22
render_no_death_burst22:
LDA $0677
BEQ render_alive21
JMP render_player_bullets21''')
code='\n'.join(l for l in (P/'death_burst_v22.asm').read_text().splitlines() if not l.lstrip().startswith(';'))
change22('shield_tick:\n',code+'\nshield_tick:\n')
change22("data.update({'hazard_width21':[0,16,12,8]})", "data.update({'hazard_width21':[0,16,12,8], 'death_explosion_tile22':[0x1F]*5+[0x1E]*5+[0x1D]*5+[0x1C]*5+[0x1B]*5, 'gameover_text22':[0x67,0x61,0x6D,0x65,0,0x6F,0x76,0x65,0x72]})")
for old,new in [('asteroids_nes_v21_mortal.nes','asteroids_nes_v22_gameover.nes'),('prototype_v21.asm','prototype_v22.asm'),('symbols_v21.json','symbols_v22.json')]:
    change22(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
