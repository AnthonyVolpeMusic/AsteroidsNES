"""Decode the actual ROM's background CHR/nametable for visual QA.
This is a background-only render, not an emulator gameplay screenshot.
"""
import json
from pathlib import Path
from PIL import Image
P=Path(__file__).parent
rom=(P/'asteroids_nes_v35_starfield.nes').read_bytes()
s=json.loads((P/'symbols_v35.json').read_text())
def table(name,n):
    start=16+s[name]-0x8000
    return rom[start:start+n]
nt=bytearray().join(table('stars35_'+str(n),256) for n in range(4))
nt[32:64]=table('hud_line',32)
colors=[(0,0,0),(236,238,236),(0,30,116),(68,0,100)]
im=Image.new('RGB',(256,240))
for y in range(240):
    for x in range(256):
        t=nt[(y//8)*32+x//8]
        offset=32784+t*16+y%8
        color=((rom[offset]>>(7-x%8))&1)|(((rom[offset+8]>>(7-x%8))&1)<<1)
        im.putpixel((x,y),colors[color])
im.resize((768,720),Image.Resampling.NEAREST).save('/tmp/asteroids_v35_background.png')
