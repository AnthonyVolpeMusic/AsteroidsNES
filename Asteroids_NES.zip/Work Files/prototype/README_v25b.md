# V25b — inter-wave audio candidate

Based on V25a. The triangle mute routine now disables its channel only on the
transition from enabled to disabled. While already muted, it does not touch any
APU register. Pulse and noise retain their independent timers and enable bits.
No gameplay changes or new RAM allocations. No new per-frame object scans.

The user-reported inter-wave silence did not reproduce in the CPU harness on
V25a. This build is a targeted mitigation, not a proven root-cause repair.
Please test firing during the four-second wave-clear wait in OpenEMU, including
the final asteroid's explosion tail. Bass should stop and return next wave;
shot and explosion effects should remain audible during the wait.

Build: `python3 build_v25b.py` (Python 3 plus py65).
Test: `python3 test_v25b.py`.

Tests execute the assembled ROM, including the real NMI/main loop and final
asteroid collision, with modeled APU enable/length-load semantics. All six
channel-start orders, independent fades, retriggers, destruction routing,
death mute, results reset, last-hit noise, 20 shot starts during the 240-frame
countdown, and next-wave triangle restart pass. Already-muted music makes zero
APU writes across 240 calls. These tests do not synthesize sound or model a full
cycle-accurate NES APU. Listening verification remains outstanding.

Prior version builders are retained because the build pipeline depends on them.
