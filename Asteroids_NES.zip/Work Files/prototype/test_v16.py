"""Run V15 frame regressions against V16, then stress its assembled renderer."""
from pathlib import Path
P = Path(__file__).parent
regression = (P/'test_v15.py').read_text().replace('symbols_v15.json','symbols_v16.json').replace('asteroids_nes_v15_wave_transition.nes','asteroids_nes_v16_oam_rotation.nes')
exec(compile(regression, str(P/'test_v15.py'), 'exec'))

from collections import Counter
peak = 0
for scenario in ('large', 'medium', 'small', 'mixed', 'empty'):
    clear()
    m[6]=1
    m[3]=0
    m[8]=0
    m[0x11]=128
    m[0x13]=100
    m[0x42]=0
    for i,a in enumerate(records):
        m[a+1]=i*4
        m[a+3]=100
        m[a+8]={'large':1,'medium':2,'small':3,'mixed':1+i%3,'empty':0}[scenario]
    for i,b in enumerate(range(0x600,0x640,16)):
        m[b:b+16]=[47,0,160+i*8,0,100,0,0,0,0,0,12,0,0,0,0,0]
    # Canary values beyond all allocated projectile records.
    m[0x640:0x800]=[0xA5]*(0x800-0x640)
    stable=m[0x300:0x800]
    appearances=Counter()
    scanline_appearances=Counter()
    protected=None
    for frame_no in range(48):
        cycles=c.processorCycles
        call('render')
        peak=max(peak,c.processorCycles-cycles)
        assert m[0x300:0x800]==stable, 'renderer modified game records or canaries'
        if protected is None: protected=m[0x200:0x214]
        assert m[0x200:0x214]==protected, 'asteroids overwrote ship/projectiles'
        assert all(m[a]==0xF8 for a in range(0x214,0x228,4)), 'future UFO reserve overwritten'
        assert m[0x201]==1 and all(m[a+1]==0x11 for a in range(0x204,0x214,4))
        # Verify all rendered large/medium objects have all four quadrants.
        oam=0x228
        drawn=[]
        while oam<0x300 and m[oam]!=0xF8:
            tile=m[oam+1]
            size=1 if tile==0x12 else 4
            assert oam+size*4<=0x300
            assert tile in (0x12,0x13,0x17)
            if size==4:
                assert [m[oam+j*4+1] for j in range(4)]==list(range(tile,tile+4))
            record=m[oam+3]//4
            appearances[record]+=1
            drawn.append(record)
            oam+=size*4
        assert len(drawn)==len(set(drawn)), 'record drawn twice'
        if scenario in ('large','medium'): assert len(drawn)==13
        if scenario=='small': assert len(drawn)==48
        if scenario=='empty': assert len(drawn)==0
        # Approximate NES eight-sprite evaluation on a crowded horizontal line.
        visible=[a for a in range(0x200,0x300,4) if m[a]<=99<m[a]+8][:8]
        assert visible[:5]==list(range(0x200,0x214,4))
        for a in visible[5:]:
            if m[a+1] in (0x12,0x13,0x17): scanline_appearances[m[a+3]//4]+=1
    if scenario!='empty':
        assert set(appearances)==set(range(48)), 'OAM capacity starvation'
        assert set(scanline_appearances)==set(range(48)), 'scanline starvation'
    print('PASS render stress:',scenario,'all 48 rotation starts, protected entries, whole objects, canaries, scanline fairness')
print('Peak renderer cycles in stress scenes:',peak)
