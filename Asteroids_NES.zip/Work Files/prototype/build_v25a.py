"""V25a: software APU enable mask and enable-before-length-load ordering."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v25.py').read_text(),str(P/'build_v25.py'),'exec'))
def change25a(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)

# $86 is reserved here as the authoritative enable mask (pulse1/2/triangle/noise).
# $4015 reads length status, NOT the value last written. All six services must
# use the shadow even when another enabled channel has an expired length.
assert source.count('LDA $4015')==6
source=source.replace('LDA $4015','LDA $86')
assert source.count('STA $4015')==6
source=source.replace('STA $4015','STA $86\nSTA $4015')

for load,mask in [('$4003','#$01'),('$400F','#$08')]:
    change25a('LDA #$00\nSTA '+load+'\nLDA $86\nORA '+mask+'\nSTA $86\nSTA $4015',
              'LDA $86\nORA '+mask+'\nSTA $86\nSTA $4015\nLDA #$00\nSTA '+load)
change25a('LDA pulse_high24,X\nSTA $400B\nLDA $86\nAND #$0F\nORA #$04\nSTA $86\nSTA $4015',
          'LDA $86\nAND #$0F\nORA #$04\nSTA $86\nSTA $4015\nLDA pulse_high24,X\nSTA $400B')

# A constant high timer does not need rewriting on each pulse slide step:
# writing $4003 would reset the pulse phase on every frame.
change25a('LDA shot_timer25,X\nSTA $4002\nLDA #$00\nSTA $4003',
          'LDA shot_timer25,X\nSTA $4002')

# Replay previously cleared only ZP through $7F. Explicitly reset SFX and mask
# both on entering results and on replay; cold/menu reset clears all ZP already.
change25a('results_enter23:\n','results_enter23:\nJSR audio_reset25a\n')
change25a('results_replay23:\n','results_replay23:\nJSR audio_reset25a\n')
change25a('shield_tick:\n','''audio_reset25a:
LDA #$00
STA $82
STA $83
STA $84
STA $85
STA $86
STA $4015
STA $4001
RTS
shield_tick:
''')
# Initialize pulse sweep explicitly on cold start.
change25a('STX $4015\n','STX $4015\nSTX $4001\n')
for old,new in [('asteroids_nes_v25_core_sfx.nes','asteroids_nes_v25a_audio_fix.nes'),('symbols_v25.json','symbols_v25a.json'),('prototype_v25.asm','prototype_v25a.asm')]:change25a(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
