"""V27: quiet thrust under explosions, idle-only shield and flip cues."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v26.py').read_text(),str(P/'build_v26.py'),'exec'))
def change27(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)

# $8C records actual acceleration this update, not simply Up being held.
change27('JSR pulse2_tick26\n','JSR pulse2_tick26\nLDA #$00\nSTA $8C\n')
change27('AND #$08\nBEQ shoot\nLDX $03','AND #$08\nBEQ shoot\nLDA #$01\nSTA $8C\nLDX $03')
change27('main_render21:\n','main_render21:\nJSR thrust_audio27\n')
change27('STA $8B\nSTA $4015','STA $8B\nSTA $8C\nSTA $4015')
change27('LDA #$3C\nSTA $08\nJMP game_normal','LDA #$3C\nSTA $08\nLDA #$07\nJSR pulse2_start26\nJMP game_normal')
change27('LDA #$B4\nSTA $08','LDA #$B4\nSTA $08\nLDA #$07\nJSR pulse2_start26')
change27('flip_save:\nSTA $03','flip_save:\nSTA $03\nLDA #$08\nJSR pulse2_start26')
# Effects 7 and 8 cannot interrupt even one another. Existing effects have
# priorities 1..5; both new effects use 0 and can be interrupted by any of them.
change27('LDX $8B\nLDY $87','LDX $8B\nCPX #$07\nBCC pulse2_priority_check27\nLDA $87\nBNE pulse2_rejected26\npulse2_priority_check27:\nLDY $87')
# Keep the existing 242-entry bank unchanged. New effects use a separate
# 35-entry bank so the 8-bit table index never wraps into another sequence.
change27('LDX $88\nLDA pulse2_volume26,X','LDX $88\nLDA $87\nCMP #$07\nBCS pulse2_extra_output27\nLDA pulse2_volume26,X')
change27('LDA pulse2_high26,X\nCMP $8A','LDA pulse2_high26,X\nJMP pulse2_high_ready27\npulse2_extra_output27:\nLDA pulse2_extra_volume27,X\nORA #$B0\nSTA $4004\nLDA pulse2_extra_low27,X\nSTA $4006\nLDA pulse2_extra_high27,X\npulse2_high_ready27:\nCMP $8A')
routine='''thrust_audio27:
LDA $84
BNE thrust_audio_done27
LDA $06
BEQ thrust_audio_off27
LDA $0677
BNE thrust_audio_off27
LDA $8C
BEQ thrust_audio_off27
LDA #$33
STA $400C
LDA #$0B
STA $400E
LDA $86
AND #$08
BNE thrust_audio_done27
LDA $86
ORA #$08
STA $86
STA $4015
LDA #$00
STA $400F
thrust_audio_done27:
RTS
thrust_audio_off27:
LDA $86
AND #$08
BEQ thrust_audio_done27
LDA #$30
STA $400C
LDA $86
AND #$F7
STA $86
STA $4015
RTS
'''
change27('shield_tick:\n',routine+'shield_tick:\n')
extra=[timer(n) for n in range(65,70) for _ in range(5)]+glide(84,72,10)
add={'pulse2_extra_low27':[x&255 for x in extra],
     'pulse2_extra_high27':[x>>8 for x in extra],
     'pulse2_extra_volume27':[15 if i%5<3 else 0 for i in range(25)]+[15]*10}
newtables=dict(tables)
newtables['pulse2_priority26']=tables['pulse2_priority26']+[0,0]
newtables['pulse2_length26']=tables['pulse2_length26']+[25,10]
newtables['pulse2_offset26']=tables['pulse2_offset26']+[0,25]
newtables.update(add)
change27('data.update('+repr(tables)+')','data.update('+repr(newtables)+')')
for old,new in [('asteroids_nes_v26_event_sfx.nes','asteroids_nes_v27_ship_sfx.nes'),('symbols_v26.json','symbols_v27.json'),('prototype_v26.asm','prototype_v27.asm')]:change27(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
