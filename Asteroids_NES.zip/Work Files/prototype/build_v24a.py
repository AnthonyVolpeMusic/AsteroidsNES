"""V24a medium-destruction tempo progression."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v24.py').read_text(),str(P/'build_v24.py'),'exec'))
def change24a(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)
change24a('''set_game_count_ready:
ASL A
ASL A
ASL A
ASL A''','''set_game_count_ready:
LDA $3F
ASL A
STA $7F
LDA #$00
STA $7E
STA $7C
LDA $3F
ASL A
ASL A
ASL A
ASL A''')
change24a('spawn_smalls_generic:\nLDA #$03','spawn_smalls_generic:\nINC $7E\nLDA #$03')
code='\n'.join(l for l in (P/'triangle_progress_v24a.asm').read_text().splitlines() if not l.lstrip().startswith(';'))
a=source.index('asteroid_pulse24:\n');b=source.index('asteroid_pulse_off24:',a)
source=source[:a]+code+'\n'+source[b:]
for a,b in [('asteroids_nes_v24_triangle_pulse.nes','asteroids_nes_v24a_medium_progress.nes'),('symbols_v24.json','symbols_v24a.json'),('prototype_v24.asm','prototype_v24a.asm')]:change24a(a,b)
exec(compile(source,str(P/'build_v15.py'),'exec'))
