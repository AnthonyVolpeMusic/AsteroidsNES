"""V30: remove only the flip sound trigger; retain all gameplay and other SFX."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v29.py').read_text(),str(P/'build_v29.py'),'exec'))
def change30(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)
change30('flip_save:\nSTA $03\nLDA #$08\nJSR pulse2_start26','flip_save:\nSTA $03')
for old,new in [('asteroids_nes_v29_brake_sfx.nes','asteroids_nes_v30_silent_flip.nes'),('symbols_v29.json','symbols_v30.json'),('prototype_v29.asm','prototype_v30.asm')]:change30(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
