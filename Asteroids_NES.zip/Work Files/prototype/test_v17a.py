from pathlib import Path
P=Path(__file__).parent
regression=(P/'test_v15.py').read_text().replace('symbols_v15.json','symbols_v17a.json').replace('asteroids_nes_v15_wave_transition.nes','asteroids_nes_v17a_two_ufo_shots.nes')
exec(compile(regression,str(P/'test_v15.py'),'exec'))
def call(name):
    c.pc=S[name];c.sp=0xff;c.stPushWord(0x7ffe)
    for _ in range(100000):
        c.step()
        if c.pc==0x7fff:return
    raise AssertionError(name+' timeout')
def reset_ufo(kind=1):
    m[6]=1;m[0x640]=kind;m[0x641]=100;m[0x642]=100;m[0x643]=0
    m[0x644]=0;m[0x645]=60;m[0x646]=1;m[0x647]=0;m[0x650:0x670]=[0]*32
    m[0x11]=100;m[0x13]=40
def active(): return [a for a in (0x650,0x660) if m[a]]
reset_ufo(1)
call('ufo_tick')
assert m[0x641]==100
assert active()==[0x650] and m[0x650]==96
call('ufo_tick')
assert m[0x641]==101, ('big UFO horizontal speed changed',m[0x640:0x647])
for _ in range(60): call('ufo_tick')
assert active()==[0x650,0x660] and 1 <= m[0x660] <= 96, ('second slot did not fire at one second',m[0x650:0x670])
for _ in range(60): call('ufo_tick')
assert active()==[0x650,0x660], 'third attempt did not reuse only an expired slot'
for _ in range(60): call('ufo_tick')
assert len(active())==2, 'expired slot was not reused'
print('PASS two UFO shot slots: 60-frame cadence, no overwrite, reuse')
reset_ufo(2)
call('ufo_tick')
assert m[0x641]==100
call('ufo_tick')
assert m[0x641]==101, 'small UFO must match big UFO horizontal speed'
for _ in range(58):call('ufo_tick')
assert active()==[0x650]
assert m[0x659]==0, 'small UFO did not aim at ship'
print('PASS equal UFO speeds and aimed small-UFO first shot')
# All protected objects and the bounded asteroid pool coexist in a full scene.
for a in records:
    m[a+8]=2;m[a+1]=(a-0x300)//4;m[a+3]=100
reset_ufo(1)
call('ufo_fire');call('ufo_fire2')
snapshot=m[0x300:0x800]
for _ in range(48):
    call('render')
    assert m[0x300:0x800]==snapshot
    assert [m[0x215+i*4] for i in range(4)]==[0x20,0x21,0x22,0x23]
    assert m[0x225]==m[0x229]==0x25
    # First asteroid must begin after OAM entries 0..10.
    assert all(m[a]==0xF8 for a in range(0x22c,0x22c,4))
print('PASS two protected enemy shots and 53-slot asteroid OAM pool')
print('PASS V17a targeted regression suite')
