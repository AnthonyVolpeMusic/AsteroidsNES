"""Real NMI/main-loop wave transition with length-enable bus semantics.
No audio synthesis: emulator listening is still required.
"""
from pathlib import Path
P=Path(__file__).parent
# Run all prior hardware-style SFX regressions against the new binary.
prior=(P/'test_v25a.py').read_text().replace("load('v25a','asteroids_nes_v25a_audio_fix.nes')", "load('v25b','asteroids_nes_v25b_wave_audio.nes')")
exec(compile(prior,str(P/'test_v25a.py'),'exec'))

class FrameBus(Bus):
    def __init__(self):
        super().__init__()
        self.pad=self.index=0
        self.writes=[]
    def __getitem__(self,k):
        if k==0x4016:
            v=(self.pad>>(7-self.index))&1 if self.index<8 else 1
            self.index+=1
            return v
        return super().__getitem__(k)
    def __setitem__(self,k,v):
        if isinstance(k,int):
            if k==0x4016:self.index=0
            if 0x4000<=k<=0x4015:self.writes.append((k,v))
        super().__setitem__(k,v)

S=json.loads((P/'symbols_v25b.json').read_text())
m=FrameBus()
m[0x8000:]=(P/'asteroids_nes_v25b_wave_audio.nes').read_bytes()[16:32784]
c=MPU(memory=m,pc=S['reset'])
for _ in range(100000):
    c.step()
    if c.pc==S['main']:break
else:raise AssertionError('boot timeout')
def frame(pad=0):
    m.pad=pad
    m.writes=[]
    c.nmi()
    for _ in range(100000):
        c.step()
        if c.pc==S['main'] and m[0]==1:return
    raise AssertionError('frame timeout')
frame(0x10)
frame()
assert m.enabled&4
# Destroy the last small rock through the actual collision dispatcher.
m[0x300:0x600]=[0]*0x300
m[0x680:0x6e0]=[0]*0x60
m[0x640]=m[0x41]=0
m[0x5f8]=3
m[0x5f1]=m[0x5f3]=100
m[0x600:0x610]=[47,0,104,0,104,0,0,0,0,0,12,0,0,0,0,0]
frame()
assert m[0x40]==240 and not m[0x80]
assert m.enabled&8 and m.length[3] and not m.enabled&4
assert m[0x85]==12
# Fire while that last explosion fades; then keep firing through the full wait.
starts=0
for remaining in range(239,0,-1):
    frame(0x80)
    assert m[0x40]==remaining
    assert not m.enabled&4
    if (0x4003,0) in m.writes:
        starts+=1
        assert m.enabled&1 and m.length[0] and m[0x4000]&15==15
    if remaining>=211:
        assert m.enabled&8 and m.length[3]
    if m[0x82]:assert m.enabled&1 and m.length[0]
assert starts>8,starts
frame()
assert m[0x3f]==5 and m[0x40]==0 and m.enabled&4 and m.length[2]
assert not m.ignored and m.reads==0
print(f'PASS final-hit noise + {starts} shot starts throughout 240-frame wait + next-wave triangle restart')
# Once muted, music service must leave all APU registers untouched.
m[0x80]=0
call('pulse_gate24c')
for _ in range(240):
    m.writes=[]
    call('pulse_gate24c')
    assert not m.writes
print('PASS already-muted music performs zero APU writes')
