"""V21 mortality, evacuation, and enemy/regular-asteroid collisions."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v20.py').read_text(),str(P/'build_v20.py'),'exec'))
def change21(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)
start=source.index('JSR controls\nJSR shield_tick')
end=source.index('JSR render\n',start)
source=source[:start]+'''LDA $0677
CMP #$02
BEQ main_render21
JSR controls
LDA $06
BEQ main_title21
LDA $0677
BNE main_dead21
JSR shield_tick
JSR physics
JSR bullets
JSR asteroids
JSR murder_tick
JSR pickups_tick
JSR collisions
JSR murder_collisions
JSR ufo_tick
JSR ufo_collisions
JSR enemy_rocks21
JSR player_hits21
LDA $0677
BNE main_render21
JSR pickups_collect
JSR murder_spawn_check
JSR wave_tick
JMP main_render21
main_dead21:
JSR asteroids
JSR murder_depart_or_tick21
JSR ufo_tick
JSR enemy_rocks21
JSR death_tick21
JMP main_render21
main_title21:
JSR asteroids
main_render21:
'''+source[end:]
change21('game_controls:\n','game_controls:\nLDA $0677\nBEQ controls_alive21\nRTS\ncontrols_alive21:\n')
change21('pickup_player_death:\nJSR pickup_reset_counter\nSTA $0676\nRTS','pickup_player_death:\nRTS')
change21('render_game:\n','render_game:\nLDA $0677\nBEQ render_alive21\nJMP render_player_bullets21\nrender_alive21:\n')
change21('STA $0203\nLDX #$00\nLDY #$04','STA $0203\nrender_player_bullets21:\nLDX #$00\nLDY #$04')
# Departures go right without wrap. Clip the right-hand metasprite tiles
# instead of allowing their 8-bit X coordinates to appear on the left.
change21('render_murder_tile:\nLDY $4C','''render_murder_tile:
LDA $0679
BEQ render_depart_visible21
LDY #$01
LDA $4F
CMP ($43),Y
BCS render_depart_visible21
RTS
render_depart_visible21:
LDY $4C''')
code='\n'.join(l for l in (P/'mortality_v21.asm').read_text().splitlines() if not l.lstrip().startswith(';'))
# Scan the three fixed RAM pages directly. Keep target pointers only for hits;
# this avoids indirect-address and pointer-update costs for distant objects.
fast='scan_regular21:\nLDA $70\nSEC\nSBC #$0F\nSTA $78\n'
for page in (3,4,5):
    fast+=f'''LDX #$00
scan_page{page}_21:
LDA ${page:02X}08,X
BEQ scan_page{page}_next21
LDA ${page:02X}01,X
SEC
SBC $78
CMP #$1F
BCS scan_page{page}_next21
LDA ${page:02X}0A,X
BNE scan_page{page}_next21
LDY ${page:02X}08,X
LDA hazard_width21,Y
STA $75
LDA ${page:02X}01,X
STA $73
LDA ${page:02X}03,X
STA $74
JSR overlap21
BCC scan_page{page}_next21
STX $43
LDA #${page:02X}
STA $44
SEC
RTS
scan_page{page}_next21:
TXA
CLC
ADC #$10
TAX
BNE scan_page{page}_21
'''
fast+='CLC\nRTS\n'
a=code.index('scan_regular21:\n');b=code.index('scan_murder21:\n',a)
code=code[:a]+fast+code[b:]
change21('shield_tick:\n',code+'\nshield_tick:\n')
change21('asm=Assembler(MPU());',"data.update({'hazard_width21':[0,16,12,8]})\nasm=Assembler(MPU());")
for old,new in [('asteroids_nes_v20_magnet.nes','asteroids_nes_v21_mortal.nes'),('prototype_v20.asm','prototype_v21.asm'),('symbols_v20.json','symbols_v21.json')]:
    change21(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
