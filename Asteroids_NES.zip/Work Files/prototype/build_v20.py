"""V20 magnet capture/attraction and level-three Murderoids."""
from pathlib import Path
import math
P=Path(__file__).parent
exec(compile((P/'build_v19b.py').read_text(),str(P/'build_v19b.py'),'exec'))
def change20(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)
assert source.count('LDA $3F\nCMP #$07')==2
source=source.replace('LDA $3F\nCMP #$07','LDA $3F\nCMP #$06')
change20('pickups_init:\nLDA #$00\nSTA $0672','pickups_init:\nLDA #$00\nSTA $0676\nSTA $0672')
change20('pickup_player_death:\nJSR pickup_reset_counter\nRTS','pickup_player_death:\nJSR pickup_reset_counter\nSTA $0676\nRTS')
change20('STA $070C,X\nLDA #$0A','STA $070C,X\nSTA $070D,X\nLDA #$0A')
change20('STA $5A\nSTA $5B\npickup_find_slot:', 'STA $5A\nSTA $5B\nSTA $57\npickup_find_slot:')
change20('LDA $0708,X\nBEQ pickup_slot_found\nLDA $070A,X', 'LDA $0708,X\nBEQ pickup_slot_found\nLDA $070D,X\nBNE pickup_slot_next\nLDA $070A,X')
change20('LDX $57\npickup_slot_found:', '''LDX $57
CPX #$FF
BNE pickup_slot_found
LDX $56
RTS
pickup_slot_found:''')
change20('LDA pickup_order,Y\nSTA $0708,X','''LDA pickup_order,Y
CMP #$0A
BNE pickup_type_ready
LDA $0676
CMP #$03
BCC pickup_type_magnet
LDA #$04
JMP pickup_type_ready
pickup_type_magnet:
LDA #$0A
pickup_type_ready:
STA $0708,X''')
change20('pickup_tick_active:\nLDA $0709,X','''pickup_tick_active:
LDA $070D,X
BEQ pickup_tick_drifting
JSR pickup_attract_velocity
JMP pickup_still_alive
pickup_tick_drifting:
LDA $0709,X''')
change20('render_pickup_has_room:\nLDY #$0A','''render_pickup_has_room:
LDY #$0D
LDA ($43),Y
BNE render_pickup_visible
LDY #$0A''')
start=source.index('pickups_collect:\n');end=source.index('pickup_boost_shot:\n',start)
code='\n'.join(line for line in (P/'magnet_v20.asm').read_text().splitlines() if not line.lstrip().startswith(';'))
source=source[:start]+code+'\n'+source[end:]
# Use the proven wrap-aware 48-heading aim routine with independent labels.
aim=(P/'ufo_v17.asm').read_text().split('ufo_aim_heading:\n',1)[1].split('ufo_shot_tick:',1)[0]
aim='pickup_attract_aim:\n'+aim.replace('ufo_','pickup_attract_')
aim=aim.replace('$0652','$0701,X').replace('$0654','$0703,X').replace('LDA pickup_attract_aim,X','LDA ufo_aim,X')
change20('pickup_boost_shot:\n',aim+'\npickup_boost_shot:\n')
# Attraction can deliver many high-value items simultaneously. Add the decimal
# digits directly instead of incrementing them once for every point awarded.
change20('score_add_loop:\nJSR score_increment\nDEC $25\nBNE score_add_loop', '''score_add_loop:
JSR score_decimal_add''')
decimal='''score_decimal_add:
LDA #$00
STA $6C
STA $6D
LDA $25
score_decimal_hundreds:
CMP #$64
BCC score_decimal_tens
SEC
SBC #$64
INC $6C
JMP score_decimal_hundreds
score_decimal_tens:
CMP #$0A
BCC score_decimal_ones
SEC
SBC #$0A
INC $6D
JMP score_decimal_tens
score_decimal_ones:
CLC
ADC $38
CMP #$0A
BCC score_decimal_ones_ready
SEC
SBC #$0A
INC $6D
score_decimal_ones_ready:
STA $38
LDA $6D
CLC
ADC $37
CMP #$0A
BCC score_decimal_tens_ready
SEC
SBC #$0A
INC $6C
score_decimal_tens_ready:
STA $37
LDA $6C
CLC
ADC $36
CMP #$0A
BCC score_decimal_hundreds_ready
SEC
SBC #$0A
INC $35
score_decimal_hundreds_ready:
STA $36
LDA $35
CMP #$0A
BCC score_decimal_done
LDA #$00
STA $35
INC $34
LDA $34
CMP #$0A
BCC score_decimal_done
LDA #$00
STA $34
INC $33
LDA $33
CMP #$0A
BCC score_decimal_done
LDA #$00
STA $33
score_decimal_done:
RTS
'''
change20('score_increment:\n',decimal+'\nscore_increment:\n')
tables={
 'pickup_order':[1,2,1,3,1,2,1,4,5,6,2,10,3,2,4,7,2,3,6,4,7,4,8,9],
 'pickup_tiles':[0,38,40,42,44,46,48,50,52,54,65],
 'pickup_palettes':[0,1,1,0,0,1,2,2,2,2,0],
 'pickup_score_chunks':[0,1,2,3,4,0,0,8,12,20,4],
 'magnet_bias':[15,19,23,27], 'magnet_width':[31,39,47,55],
}
speed=math.ceil((math.sqrt(8)+1)*256)
assert speed==981
for axis,fn in [('x',math.sin),('y',lambda a:-math.cos(a))]:
    values=[round(speed*fn(h*math.tau/48))&65535 for h in range(48)]
    tables['attract_'+axis+'lo']=[v&255 for v in values]
    tables['attract_'+axis+'hi']=[v>>8 for v in values]
change20('asm=Assembler(MPU());','data.update('+repr(tables)+')\nasm=Assembler(MPU());')
art='''
magnet_rows=['00333300','03333330','33300333','33000033','33000033','33000033','11000011','11000011']
tile(0x141,[[int(c) for c in r] for r in magnet_rows])
tile(0x142,[[2 if c=='3' else int(c) for c in r] for r in magnet_rows])
'''
change20("output=P/'asteroids_nes_v19b_murderoid_respawn.nes'",art+"\noutput=P/'asteroids_nes_v20_magnet.nes'")
source=source.replace('symbols_v19b.json','symbols_v20.json').replace('prototype_v19b.asm','prototype_v20.asm')
exec(compile(source,str(P/'build_v15.py'),'exec'))
