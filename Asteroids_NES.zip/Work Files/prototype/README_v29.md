# V29 brake sound

Based on V28. Successful B+Down requests Pulse 2 effect 9: G5 for three
updates, F5 for three updates, five cycles total (30 updates). Volume 15,
50% duty, matching other ship cues. Only starts on an idle channel; existing
V26 effects interrupt it. Shield, flip and brake do not interrupt one another.
No additional RAM. Adds 30 entries to the secondary sequence bank.

Build: python3 prototype/build_v29.py (Python 3, Pillow, py65).
Test: python3 prototype/test_v29.py.

Focused ROM tests pass for all 30 pitch/volume samples, independent channels,
busy rejection, interruption priorities, successful braking, empty SUPER,
braking while another sound plays, and audio reset. Tests model register
behavior, not audible output. OpenEMU listening verification remains pending.
Historical builds/tests are included for reproducibility. Some old tests expect
silent braking and apply only to their original versions; use test_v29.py here.
