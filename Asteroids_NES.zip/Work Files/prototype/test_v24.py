"""Execute triangle pulse timing and APU register behavior."""
from pathlib import Path
P=Path(__file__).parent
base=(P/'test_v22.py').read_text().split('# AABB boundaries')[0]
base=base.replace('symbols_v22.json','symbols_v24.json').replace('asteroids_nes_v22_gameover.nes','asteroids_nes_v24_triangle_pulse.nes')
exec(compile(base,str(P/'test_v22.py'),'exec'))
writes=[];original=Memory.__setitem__
def record(self,k,v):
    if isinstance(k,int) and 0x4000<=k<=0x401f:writes.append((k,v))
    original(self,k,v)
Memory.__setitem__=record
def clear_rocks():
    for a in records:m[a:a+16]=[0]*16
def rocks(n):
    clear_rocks()
    for i,a in enumerate(records[:n]):m[a+8]=3;m[a+1]=(20+i*17)&255;m[a+3]=80
def pulse_once():
    writes.clear();call('asteroid_pulse24');return writes[:]
for count,interval in [(48,48),(13,48),(12,36),(9,36),(8,24),(5,24),(4,15),(2,15),(1,9)]:
    clear();m[0x67f]=0;rocks(count);got=pulse_once()
    assert m[0x67f]==interval,(count,m[0x67f])
    assert [(a,v) for a,v in got if a in (0x4008,0x400a,0x400b,0x4015)]==[(0x4008,0x18),(0x400a,0x56),(0x400b,3),(0x4015,4)]
    for _ in range(interval):
        assert pulse_once()==[]
    second=pulse_once()
    assert (0x400a,0x26) in second,(count,second)
print('PASS C2/C#2 alternate, all five count tempo tiers and full inter-pulse gaps')
clear();m[0x67f]=10;writes.clear();call('asteroid_pulse24')
assert m[0x67f]==0 and writes[-1]==(0x4015,0)
# Actual gameplay starts it; menu/results turn it off and never pulse.
clear();m[6]=1;m[0x67f]=0;rocks(4);runframe();assert m[0x67f]==15 and m[0x4015]==4
m[6]=0;runframe();assert m[0x67f]==0 and m[0x4015]==0
print('PASS live-game start and menu silence')
