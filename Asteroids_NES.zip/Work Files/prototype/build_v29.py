"""V29: idle-only Pulse 2 brake cue, G5/F5, five six-frame cycles."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v28.py').read_text(),str(P/'build_v28.py'),'exec'))
def change29(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)
change29('special_stop:\nDEC $07','special_stop:\nDEC $07\nLDA #$09\nJSR pulse2_start26')
brake=([timer(79)]*3+[timer(77)]*3)*5
updated={k:list(v) for k,v in newtables.items()}
updated['pulse2_priority26']+=[0]
updated['pulse2_length26']+=[30]
updated['pulse2_offset26']+=[35]
updated['pulse2_extra_low27'] += [x&255 for x in brake]
updated['pulse2_extra_high27'] += [x>>8 for x in brake]
updated['pulse2_extra_volume27'] += [15]*30
change29('data.update('+repr(newtables)+')','data.update('+repr(updated)+')')
for old,new in [('asteroids_nes_v28_respawn_shield.nes','asteroids_nes_v29_brake_sfx.nes'),('symbols_v28.json','symbols_v29.json'),('prototype_v28.asm','prototype_v29.asm')]:change29(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
