ufo_init:
LDA #$58
STA $064A
LDA #$02
STA $064B
ufo_wave_reset:
LDA #$00
STA $0640
STA $0647
STA $0650
STA $41
ufo_reload:
LDA $064A
STA $0648
LDA $064B
STA $0649
RTS
ufo_tick:
LDA $06
BNE ufo_game_tick
RTS
ufo_game_tick:
JSR ufo_shot_tick
LDA $0647
BEQ ufo_not_exploding
DEC $0647
RTS
ufo_not_exploding:
LDA $0640
BEQ ufo_idle
JMP ufo_move
ufo_idle:
LDA $40
BEQ ufo_check_rocks
RTS
ufo_check_rocks:
LDX #$00
ufo_rock_scan:
LDA $0308,X
ORA $0408,X
ORA $0508,X
BNE ufo_timer
TXA
CLC
ADC #$10
TAX
BNE ufo_rock_scan
RTS
ufo_timer:
LDA $0648
ORA $0649
BEQ ufo_spawn
LDA $0648
BNE ufo_timer_low
DEC $0649
ufo_timer_low:
DEC $0648
LDA $0648
ORA $0649
BEQ ufo_spawn
RTS
ufo_spawn:
LDA #$01
STA $0640
STA $41
LDA $3F
SEC
SBC #$04
TAX
JSR random
CMP ufo_small_chance,X
BCS ufo_size_ready
INC $0640
ufo_size_ready:
JSR random
AND #$01
STA $0643
BEQ ufo_from_left
LDA #$F4
JMP ufo_set_x
ufo_from_left:
LDA #$00
ufo_set_x:
STA $0641
JSR random
AND #$7F
CLC
ADC #$30
STA $0642
LDA #$00
STA $0644
LDA #$3C
STA $0645
LDA #$5A
STA $0646
LDA $064A
SEC
SBC #$18
STA $064A
LDA $064B
SBC #$00
STA $064B
BNE ufo_spawn_done
LDA $064A
CMP #$78
BCS ufo_spawn_done
LDA #$78
STA $064A
ufo_spawn_done:
RTS
ufo_move:
DEC $0645
BNE ufo_course_ready
LDA #$3C
STA $0645
JSR random
AND #$03
TAX
LDA #$00
CPX #$02
BCS ufo_set_course
LDA #$01
CPX #$00
BEQ ufo_set_course
LDA #$FF
ufo_set_course:
STA $0644
ufo_course_ready:
LDA $0645
AND #$01
BNE ufo_y_done
LDA $0642
CLC
ADC $0644
CMP #$20
BCC ufo_y_done
CMP #$D8
BCS ufo_y_done
STA $0642
ufo_y_done:
LDA $0640
CMP #$02
BEQ ufo_step_x
LDA $0645
AND #$01
BNE ufo_fire_timer
ufo_step_x:
LDA $0643
BNE ufo_leftward
INC $0641
LDA $0641
CMP #$F5
BCS ufo_exit
JMP ufo_fire_timer
ufo_leftward:
LDA $0641
BEQ ufo_exit
DEC $0641
ufo_fire_timer:
DEC $0646
BNE ufo_move_done
LDA #$5A
STA $0646
LDA $0650
BNE ufo_move_done
JSR ufo_fire
ufo_move_done:
RTS
ufo_exit:
LDA #$00
STA $0640
STA $41
JMP ufo_reload
ufo_fire:
LDA $0641
CLC
ADC #$02
STA $0652
LDA $0642
CLC
ADC #$02
STA $0654
LDA #$00
STA $0651
STA $0653
LDA #$60
STA $0650
LDA $0640
CMP #$02
BEQ ufo_aimed
JSR random
ufo_random_reduce:
CMP #$30
BCC ufo_heading_ready
SEC
SBC #$30
JMP ufo_random_reduce
ufo_aimed:
JSR ufo_aim_heading
ufo_heading_ready:
STA $0659
TAX
LDA ufo_xlo,X
STA $0655
LDA ufo_xhi,X
STA $0656
LDA ufo_ylo,X
STA $0657
LDA ufo_yhi,X
STA $0658
RTS
ufo_aim_heading:
LDA #$00
STA $54
STA $55
LDA $11
SEC
SBC $0652
BPL ufo_dx_positive
INC $54
EOR #$FF
CLC
ADC #$01
ufo_dx_positive:
STA $52
LDA $13
SEC
SBC $0654
BCS ufo_dy_wrapped
CLC
ADC #$F0
ufo_dy_wrapped:
CMP #$78
BCC ufo_dy_positive
SEC
SBC #$F0
BPL ufo_dy_positive
INC $55
EOR #$FF
CLC
ADC #$01
ufo_dy_positive:
STA $53
ufo_aim_scale:
LDA $52
ORA $53
CMP #$10
BCC ufo_aim_lookup
LSR $52
LSR $53
JMP ufo_aim_scale
ufo_aim_lookup:
LDA $53
ASL A
ASL A
ASL A
ASL A
ORA $52
TAX
LDA ufo_aim,X
LDX $55
BEQ ufo_aim_x_sign
STA $52
LDA #$18
SEC
SBC $52
ufo_aim_x_sign:
LDX $54
BEQ ufo_aim_normalize
STA $52
LDA #$30
SEC
SBC $52
ufo_aim_normalize:
JMP normalize_heading
ufo_shot_tick:
LDA $0650
BNE ufo_shot_live
RTS
ufo_shot_live:
DEC $0650
CLC
LDA $0651
ADC $0655
STA $0651
LDA $0652
ADC $0656
STA $0652
CLC
LDA $0653
ADC $0657
STA $0653
LDA $0654
ADC $0658
CMP #$F0
BCC ufo_shot_y_ready
LDX $0658
BMI ufo_shot_y_negative
SEC
SBC #$F0
JMP ufo_shot_y_ready
ufo_shot_y_negative:
CLC
ADC #$F0
ufo_shot_y_ready:
STA $0654
RTS
ufo_collisions:
LDA $06
BEQ ufo_collision_done
LDA $0640
BEQ ufo_collision_done
CMP #$01
BEQ ufo_hit_big
LDA #$08
JMP ufo_hit_width
ufo_hit_big:
LDA #$0C
ufo_hit_width:
STA $52
LDX #$00
ufo_hit_loop:
LDA $0600,X
BEQ ufo_hit_next
LDA $0609,X
BNE ufo_hit_next
LDA $0602,X
SEC
SBC $0641
CMP $52
BCC ufo_hit_x
CMP #$FD
BCC ufo_hit_next
ufo_hit_x:
LDA $0604,X
SEC
SBC $0642
CMP $52
BCC ufo_hit_confirm
CMP #$FD
BCC ufo_hit_next
ufo_hit_confirm:
STX $22
JSR collision_explode
LDA $0640
STA $53
LDA #$00
STA $0640
STA $41
LDA #$0F
STA $0647
JSR ufo_reload
LDA $53
CMP #$01
BEQ ufo_score_big
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
ufo_score_big:
LDA #$C8
JSR score_add
RTS
ufo_hit_next:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE ufo_hit_loop
ufo_collision_done:
RTS
render_ufo:
LDA $0650
BEQ render_ufo_body
LDA $0654
SEC
SBC #$01
STA $0224
LDA #$25
STA $0225
LDA #$00
STA $0226
LDA $0652
STA $0227
render_ufo_body:
LDA $0647
BEQ render_ufo_alive
SEC
SBC #$01
TAX
LDA explosion_drawing,X
STA $0215
JMP render_ufo_single
render_ufo_alive:
LDA $0640
BNE render_ufo_exists
RTS
render_ufo_exists:
CMP #$01
BEQ render_ufo_big
LDA #$24
STA $0215
render_ufo_single:
LDA $0642
SEC
SBC #$01
STA $0214
LDA $0641
STA $0217
LDA #$00
STA $0216
RTS
render_ufo_big:
LDA $0642
SEC
SBC #$01
STA $0214
STA $0218
CLC
ADC #$08
STA $021C
STA $0220
LDA $0641
STA $0217
STA $021F
CLC
ADC #$08
STA $021B
STA $0223
LDA #$00
STA $0216
STA $021A
STA $021E
STA $0222
LDA #$20
STA $0215
LDA #$21
STA $0219
LDA #$22
STA $021D
LDA #$23
STA $0221
RTS
