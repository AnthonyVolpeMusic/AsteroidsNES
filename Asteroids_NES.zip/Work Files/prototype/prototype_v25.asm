reset:
SEI
CLD
LDX #$40
STX $4017
LDX #$FF
TXS
INX
STX $2000
STX $2001
STX $4010
STX $4015
BIT $2002
warm1:
BIT $2002
BPL warm1
LDA #$00
clear:
STA $0000,X
STA $0100,X
STA $0200,X
STA $0300,X
STA $0400,X
STA $0600,X
STA $0600,X
STA $0700,X
INX
BNE clear
warm2:
BIT $2002
BPL warm2
LDA #$20
STA $2006
LDA #$00
STA $2006
LDY #$10
LDX #$00
blank:
STA $2007
INX
BNE blank
DEY
BNE blank
LDA #$3F
STA $2006
LDA #$00
STA $2006
LDX #$00
pal:
LDA palette,X
STA $2007
INX
CPX #$20
BNE pal
LDX #$00
load_asteroids:
LDA asteroid_init0,X
STA $0300,X
LDA asteroid_init1,X
STA $0400,X
LDA asteroid_init2,X
STA $0500,X
INX
BNE load_asteroids
JSR load_title
LDA #$80
STA $11
LDA #$78
STA $13
LDA #$01
STA $00
LDA #$05
STA $07
LDA #$03
STA $3D
LDA #$04
STA $3F
LDA #$20
STA $3A
LDA #$4E
STA $3B
LDA #$A5
STA $2F
LDA #$10
STA $3E
LDA #$88
STA $2000
LDA #$1E
STA $2001
main:
LDA $00
BNE main
JSR sfx_tick25
LDA $0677
CMP #$02
BEQ main_gameover22
CMP #$03
BNE main_play23
JSR controls
JMP main_render21
main_play23:
JSR controls
LDA $06
BEQ main_title21
LDA $0677
BNE main_dead21
JSR shield_tick
JSR physics
JSR bullets
JSR asteroids
JSR murder_tick
JSR pickups_tick
JSR collisions
JSR murder_collisions
JSR ufo_tick
JSR ufo_collisions
JSR enemy_rocks21
JSR player_hits21
LDA $0677
BNE main_render21
JSR pickups_collect
JSR murder_spawn_check
JSR wave_tick
JMP main_render21
main_dead21:
JSR asteroids
JSR death_explosion_tick22
JSR murder_depart_or_tick21
JSR ufo_tick
JSR enemy_rocks21
JSR death_tick21
JMP main_render21
main_gameover22:
JSR death_explosion_tick22
JSR asteroids
JSR murder_depart_or_tick21
JSR pickups_tick
JSR ufo_tick
JSR enemy_rocks21
JSR murder_spawn_check
JSR gameover_tick22
JMP main_render21
main_title21:
JSR asteroid_pulse_off24
JSR asteroids
main_render21:
JSR pulse_gate24c
JSR render
LDA #$01
STA $00
JMP main
nmi:
PHA
TXA
PHA
TYA
PHA
LDA $00
BEQ nmi_done
LDA #$00
STA $2003
LDA #$02
STA $4014
LDA $0677
CMP #$03
BEQ nmi_hud_done
LDA $06
BEQ nmi_hud_done
LDA #$20
STA $2006
LDA #$26
STA $2006
LDX #$00
nmi_score:
LDA $33,X
CLC
ADC #$7B
STA $2007
INX
CPX #$06
BNE nmi_score
LDA #$20
STA $2006
LDA #$35
STA $2006
LDA $07
CLC
ADC #$7B
STA $2007
LDA #$20
STA $2006
LDA #$3F
STA $2006
LDA $3D
CLC
ADC #$7B
STA $2007
nmi_hud_done:
LDA $067C
BEQ nmi_gameover_done22
LDA #$21
STA $2006
LDA #$EB
STA $2006
LDX #$00
nmi_gameover_text22:
LDA gameover_text22,X
STA $2007
INX
CPX #$09
BNE nmi_gameover_text22
nmi_gameover_done22:
LDA #$00
STA $2005
STA $2005
STA $00
nmi_done:
PLA
TAY
PLA
TAX
PLA
RTI
irq:
RTI
load_title:
LDA #$20
STA $2006
LDA #$00
STA $2006
LDX #$00
load_title_page0:
LDA title_nt0,X
STA $2007
INX
BNE load_title_page0
LDX #$00
load_title_page1:
LDA title_nt1,X
STA $2007
INX
BNE load_title_page1
LDX #$00
load_title_page2:
LDA title_nt2,X
STA $2007
INX
BNE load_title_page2
LDX #$00
load_title_page3:
LDA title_nt3,X
STA $2007
INX
BNE load_title_page3
RTS
blank_title:
LDA #$00
STA $2001
LDA #$20
STA $2006
LDA #$00
STA $2006
LDY #$04
LDX #$00
blank_title_loop:
LDA #$00
STA $2007
INX
BNE blank_title_loop
DEY
BNE blank_title_loop
JSR load_hud
LDA #$1E
STA $2001
RTS
load_hud:
LDA #$20
STA $2006
LDA #$20
STA $2006
LDX #$00
load_hud_loop:
LDA hud_line,X
STA $2007
INX
CPX #$20
BNE load_hud_loop
RTS
controls:
LDA $01
STA $02
LDA #$01
STA $4016
LDA #$00
STA $4016
STA $01
LDX #$08
readpad:
LDA $4016
LSR A
ROL $01
DEX
BNE readpad
LDA $06
BNE game_controls
LDA $02
EOR #$FF
AND $01
AND #$10
BEQ title_controls_done
JSR blank_title
JSR murder_init
JSR pickups_init
JSR ufo_init
JSR set_game_rocks
LDA #$01
STA $06
title_controls_done:
RTS
game_controls:
LDA $0677
CMP #$03
BNE ordinary_controls23
JMP results_controls23
ordinary_controls23:
LDA $0677
BEQ controls_alive21
RTS
controls_alive21:
LDA $02
EOR #$FF
AND $01
AND #$40
BNE special_pressed
JMP game_normal
special_pressed:
LDA $07
BNE special_has_power
JMP game_normal
special_has_power:
LDA $01
AND #$04
BNE special_stop
LDA $01
AND #$08
BNE special_rainbow
LDA $08
BEQ shield_available
JMP game_normal
shield_available:
DEC $07
LDA #$3C
STA $08
JMP game_normal
special_stop:
DEC $07
LDA #$00
STA $14
STA $15
STA $16
STA $17
RTS
special_rainbow:
LDX #$00
rainbow_check:
LDA $0600,X
BEQ rainbow_slot_clear
RTS
rainbow_slot_clear:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE rainbow_check
DEC $07
JSR sfx_shot_start25
LDX #$00
LDA #$00
STA $21
rainbow_loop:
LDY $21
LDA $03
CLC
ADC rainbow_offsets,Y
CMP #$30
BCC rainbow_heading_ok
SBC #$30
rainbow_heading_ok:
TAY
LDA #$30
STA $0600,X
LDA $10
STA $0601,X
LDA $11
STA $0602,X
LDA $12
STA $0603,X
LDA $13
STA $0604,X
CLC
LDA $14
ADC bxlo,Y
STA $0605,X
LDA $15
ADC bxhi,Y
STA $0606,X
CLC
LDA $16
ADC bylo,Y
STA $0607,X
LDA $17
ADC byhi,Y
STA $0608,X
TYA
STA $060A,X
JSR pickup_boost_shot
INC $21
TXA
CLC
ADC #$10
TAX
LDA $21
CMP #$04
BNE rainbow_loop
RTS
game_normal:
LDA $04
BEQ rot_ready
DEC $04
JMP flip
rot_ready:
LDA $01
AND #$03
CMP #$01
BEQ right
CMP #$02
BNE flip
LDA $03
BNE left_nonzero
LDA #$30
left_nonzero:
SEC
SBC #$01
STA $03
JMP rot_delay
right:
INC $03
LDA $03
CMP #$30
BCC rot_delay
LDA #$00
STA $03
rot_delay:
LDA #$01
STA $04
flip:
LDA $02
EOR #$FF
AND $01
AND #$04
BEQ thrust
LDA $03
CLC
ADC #$18
CMP #$30
BCC flip_save
SBC #$30
flip_save:
STA $03
thrust:
LDA $01
AND #$08
BEQ shoot
LDX $03
CLC
LDA $14
ADC axlo,X
STA $14
LDA $15
ADC axhi,X
STA $15
BPL positive20
CMP #$FE
BCS capped20
LDA #$FE
STA $15
LDA #$00
STA $14
JMP capped20
positive20:
CMP #$02
BCC capped20
LDA #$02
STA $15
LDA #$00
STA $14
capped20:
CLC
LDA $16
ADC aylo,X
STA $16
LDA $17
ADC ayhi,X
STA $17
BPL positive22
CMP #$FE
BCS capped22
LDA #$FE
STA $17
LDA #$00
STA $16
JMP capped22
positive22:
CMP #$02
BCC capped22
LDA #$02
STA $17
LDA #$00
STA $16
capped22:
shoot:
LDA $05
BEQ can_shoot
DEC $05
RTS
can_shoot:
LDA $01
AND #$80
BEQ controls_done
LDX #$00
find_slot:
LDA $0600,X
BEQ spawn
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE find_slot
RTS
spawn:
JSR sfx_shot_start25
LDA #$30
STA $0600,X
LDA #$08
STA $05
LDY $03
LDA $10
STA $0601,X
LDA $11
STA $0602,X
LDA $12
STA $0603,X
LDA $13
STA $0604,X
CLC
LDA $14
ADC bxlo,Y
STA $0605,X
LDA $15
ADC bxhi,Y
STA $0606,X
CLC
LDA $16
ADC bylo,Y
STA $0607,X
LDA $17
ADC byhi,Y
STA $0608,X
TYA
STA $060A,X
JSR pickup_boost_shot
controls_done:
RTS
overlap21:
LDA $70
SEC
SBC $73
CMP $75
BCC overlap_y21
STA $76
LDA #$00
SEC
SBC $72
CMP $76
BCS overlap_no21
overlap_y21:
LDA $71
SEC
SBC $74
BCS overlap_y_delta21
CLC
ADC #$F0
overlap_y_delta21:
CMP $75
BCC overlap_yes21
STA $76
LDA #$F0
SEC
SBC $72
CMP $76
BCS overlap_no21
overlap_yes21:
SEC
RTS
overlap_no21:
CLC
RTS
scan_regular21:
LDA $70
SEC
SBC #$0F
STA $78
LDX #$00
scan_page3_21:
LDA $0308,X
BEQ scan_page3_next21
LDA $0301,X
SEC
SBC $78
CMP #$1F
BCS scan_page3_next21
LDA $030A,X
BNE scan_page3_next21
LDY $0308,X
LDA hazard_width21,Y
STA $75
LDA $0301,X
STA $73
LDA $0303,X
STA $74
JSR overlap21
BCC scan_page3_next21
STX $43
LDA #$03
STA $44
SEC
RTS
scan_page3_next21:
TXA
CLC
ADC #$10
TAX
BNE scan_page3_21
LDX #$00
scan_page4_21:
LDA $0408,X
BEQ scan_page4_next21
LDA $0401,X
SEC
SBC $78
CMP #$1F
BCS scan_page4_next21
LDA $040A,X
BNE scan_page4_next21
LDY $0408,X
LDA hazard_width21,Y
STA $75
LDA $0401,X
STA $73
LDA $0403,X
STA $74
JSR overlap21
BCC scan_page4_next21
STX $43
LDA #$04
STA $44
SEC
RTS
scan_page4_next21:
TXA
CLC
ADC #$10
TAX
BNE scan_page4_21
LDX #$00
scan_page5_21:
LDA $0508,X
BEQ scan_page5_next21
LDA $0501,X
SEC
SBC $78
CMP #$1F
BCS scan_page5_next21
LDA $050A,X
BNE scan_page5_next21
LDY $0508,X
LDA hazard_width21,Y
STA $75
LDA $0501,X
STA $73
LDA $0503,X
STA $74
JSR overlap21
BCC scan_page5_next21
STX $43
LDA #$05
STA $44
SEC
RTS
scan_page5_next21:
TXA
CLC
ADC #$10
TAX
BNE scan_page5_21
CLC
RTS
scan_murder21:
LDA #$80
STA $43
LDA #$06
STA $44
LDA #$06
STA $77
scan_hazard21:
LDY #$08
LDA ($43),Y
BEQ scan_next21
TAX
LDY #$01
LDA ($43),Y
SEC
SBC $70
CLC
ADC #$0F
CMP #$1F
BCS scan_next21
LDA hazard_width21,X
STA $75
LDY #$0A
LDA ($43),Y
BNE scan_next21
LDY #$01
LDA ($43),Y
STA $73
LDY #$03
LDA ($43),Y
STA $74
JSR overlap21
BCS scan_found21
scan_next21:
LDA $43
CLC
ADC #$10
STA $43
BCC scan_pointer21
INC $44
scan_pointer21:
DEC $77
BNE scan_hazard21
CLC
scan_found21:
RTS
player_hits21:
LDA $0677
ORA $08
BEQ player_check21
RTS
player_check21:
LDA $11
STA $70
LDA $13
STA $71
LDA #$08
STA $72
JSR scan_regular21
BCS player_kill21
JSR scan_murder21
BCC player_ufo21
LDA #$01
STA $0679
JMP player_kill21
player_ufo21:
LDA $0640
BEQ player_shots21
CMP #$01
BEQ player_big_ufo21
LDA #$08
BNE player_ufo_width21
player_big_ufo21:
LDA #$0C
player_ufo_width21:
STA $75
LDA $0641
STA $73
LDA $0642
STA $74
JSR overlap21
BCS player_kill21
player_shots21:
LDX #$00
player_shot_loop21:
LDA $0650,X
BEQ player_shot_next21
LDA $0652,X
STA $73
LDA $0654,X
STA $74
LDA #$04
STA $75
JSR overlap21
BCC player_shot_next21
LDA #$00
STA $0650,X
JMP player_kill21
player_shot_next21:
TXA
CLC
ADC #$10
TAX
CPX #$20
BNE player_shot_loop21
RTS
player_kill21:
LDA $0677
BNE player_kill_done21
JSR death_burst_start22
LDA #$0F
JSR sfx_noise_start25
LDA #$01
STA $0677
LDA #$78
STA $0678
LDA #$00
STA $08
STA $40
LDX #$3F
death_clear_shots21:
STA $0600,X
DEX
BPL death_clear_shots21
LDA $3D
BEQ death_gameover21
DEC $3D
BNE player_kill_done21
death_gameover21:
LDA #$02
STA $0677
LDA #$2C
STA $067A
LDA #$01
STA $067E
STA $067C
player_kill_done21:
RTS
death_tick21:
LDA $0677
CMP #$01
BNE death_return21
LDA $0678
BEQ death_check_depart21
DEC $0678
BNE death_return21
death_check_depart21:
LDA $0679
BEQ death_respawn21
JSR murder_count
BNE death_return21
death_respawn21:
LDA #$00
STA $0677
STA $0679
STA $03
STA $04
STA $05
LDX #$07
death_clear_velocity21:
STA $10,X
DEX
BPL death_clear_velocity21
LDX #$3F
death_clear_shots_again21:
STA $0600,X
DEX
BPL death_clear_shots_again21
LDA #$80
STA $11
LDA #$78
STA $13
LDA #$05
STA $07
LDA #$B4
STA $08
death_return21:
RTS
murder_depart_or_tick21:
LDA $0679
BNE murder_depart21
JMP murder_tick
murder_depart21:
LDX #$00
murder_depart_loop21:
LDA $0688,X
BEQ murder_depart_next21
LDA $0681,X
CLC
ADC #$02
STA $0681,X
BCC murder_depart_next21
LDA #$00
STA $0688,X
murder_depart_next21:
TXA
CLC
ADC #$10
TAX
CPX #$60
BNE murder_depart_loop21
RTS
enemy_rocks21:
LDA #$00
STA $067B
enemy_source21:
LDX $067B
BNE enemy_shot_source21
LDA $0640
BNE enemy_body_source21
JMP enemy_next21
enemy_body_source21:
CMP #$01
BEQ enemy_big21
LDA #$08
BNE enemy_body_width21
enemy_big21:
LDA #$0C
enemy_body_width21:
STA $72
LDA $0641
STA $70
LDA $0642
STA $71
LDA #$0C
LDX $0643
BEQ enemy_heading21
LDA #$24
enemy_heading21:
STA $27
JMP enemy_scan21
enemy_shot_source21:
LDA $0640,X
BNE enemy_shot_live21
JMP enemy_next21
enemy_shot_live21:
LDA $0642,X
STA $70
LDA $0644,X
STA $71
LDA $0649,X
STA $27
LDA #$04
STA $72
enemy_scan21:
JSR scan_regular21
BCC enemy_next21
LDX $067B
LDA #$00
STA $0640,X
CPX #$00
BNE enemy_target21
STA $41
LDA #$0F
STA $0647
JSR ufo_reload
enemy_target21:
LDA $43
STA $45
LDA $44
STA $46
LDY #$08
LDA ($43),Y
STA $26
JSR sfx_asteroid_start25
LDA $26
CMP #$01
BEQ enemy_large21
CMP #$02
BEQ enemy_medium21
LDA #$00
STA ($43),Y
JMP enemy_next21
enemy_large21:
JSR spawn_mediums_generic
JMP enemy_next21
enemy_medium21:
JSR spawn_smalls_generic
enemy_next21:
LDA $067B
CLC
ADC #$10
STA $067B
CMP #$30
BEQ enemy_done21
JMP enemy_source21
enemy_done21:
RTS
death_burst_start22:
LDA #$19
STA $067D
LDX #$00
death_burst_make22:
LDA $10
STA $06E0,X
LDA $11
STA $06E1,X
LDA $12
STA $06E2,X
LDA $13
STA $06E3,X
death_heading_retry22a:
JSR random
AND #$0F
CMP #$0C
BCS death_heading_retry22a
STA $7B
TXA
LSR A
LSR A
LSR A
TAY
LDA death_quadrants22a,Y
CLC
ADC $7B
TAY
LDA death_xlo22a,Y
STA $06E4,X
LDA death_xhi22a,Y
STA $06E5,X
LDA death_ylo22a,Y
STA $06E6,X
LDA death_yhi22a,Y
STA $06E7,X
TXA
CLC
ADC #$08
TAX
CPX #$20
BNE death_burst_make22
RTS
death_explosion_tick22:
LDA $067D
BEQ death_explosion_done22
LDX #$00
death_explosion_move22:
CLC
LDA $06E0,X
ADC $06E4,X
STA $06E0,X
LDA $06E1,X
ADC $06E5,X
STA $06E1,X
CLC
LDA $06E2,X
ADC $06E6,X
STA $06E2,X
LDA $06E3,X
ADC $06E7,X
STA $06E3,X
TXA
CLC
ADC #$08
TAX
CPX #$20
BNE death_explosion_move22
DEC $067D
death_explosion_done22:
RTS
render_death_burst22:
LDA #$19
SEC
SBC $067D
TAX
LDA death_explosion_tile22,X
STA $7A
LDX #$00
LDY #$00
render_death_piece22:
LDA $06E3,X
SEC
SBC #$01
STA $0200,Y
LDA $7A
STA $0201,Y
LDA #$00
STA $0202,Y
LDA $06E1,X
STA $0203,Y
TXA
CLC
ADC #$08
TAX
TYA
CLC
ADC #$04
TAY
CPY #$10
BNE render_death_piece22
RTS
gameover_tick22:
LDA $067A
ORA $067E
BEQ gameover_hold22
LDA $067A
BNE gameover_low22
DEC $067E
LDA #$FF
STA $067A
JMP gameover_return22
gameover_low22:
DEC $067A
LDA $067A
ORA $067E
BNE gameover_return22
gameover_hold22:
JSR results_enter23
gameover_return22:
RTS
results_off23:
LDA #$00
STA $2000
STA $2001
BIT $2002
RTS
results_on23:
BIT $2002
results_vblank23:
BIT $2002
BPL results_vblank23
LDA #$00
STA $2005
STA $2005
LDA #$88
STA $2000
LDA #$1E
STA $2001
RTS
results_rank23:
LDX #$0A
results_compare23:
LDA $32
CMP rank_limit223,X
BCC results_lower23
BNE results_rank_done23
LDA $31
CMP rank_limit123,X
BCC results_lower23
BNE results_rank_done23
LDA $30
CMP rank_limit023,X
BCS results_rank_done23
results_lower23:
DEX
BPL results_compare23
results_rank_done23:
TXA
RTS
results_enter23:
JSR asteroid_pulse_off24
JSR results_off23
LDA #$03
STA $0677
LDA #$00
STA $067C
LDA #$20
STA $2006
LDA #$00
STA $2006
LDX #$00
results_page023:
LDA results_nt023,X
STA $2007
INX
BNE results_page023
LDX #$00
results_page123:
LDA results_nt123,X
STA $2007
INX
BNE results_page123
LDX #$00
results_page223:
LDA results_nt223,X
STA $2007
INX
BNE results_page223
LDX #$00
results_page323:
LDA results_nt323,X
STA $2007
INX
BNE results_page323
LDA #$20
STA $2006
LDA #$ED
STA $2006
LDX #$00
results_score23:
LDA $33,X
CLC
ADC #$7B
STA $2007
INX
CPX #$06
BNE results_score23
LDA #$21
STA $2006
LDA #$80
STA $2006
JSR results_rank23
JSR results_draw_rank23
JSR render
LDA #$00
STA $2003
LDA #$02
STA $4014
JSR results_readpad23
JMP results_on23
results_controls23:
LDA $02
EOR #$FF
AND $01
AND #$30
BEQ results_control_done23
AND #$10
BNE results_replay23
JMP reset
results_control_done23:
RTS
results_readpad23:
LDA #$01
STA $4016
LDA #$00
STA $4016
STA $01
LDX #$08
results_pad_loop23:
LDA $4016
LSR A
ROL $01
DEX
BNE results_pad_loop23
LDA $01
STA $02
RTS
results_replay23:
JSR results_off23
LDA #$00
LDX #$7F
results_clear_zp23:
STA $00,X
DEX
CPX #$02
BNE results_clear_zp23
LDX #$00
results_clear_pools23:
STA $0300,X
STA $0400,X
STA $0500,X
STA $0600,X
STA $0700,X
INX
BNE results_clear_pools23
LDA #$03
STA $3D
LDA #$04
STA $3F
LDA #$05
STA $07
LDA #$80
STA $11
LDA #$78
STA $13
LDA #$20
STA $3A
LDA #$4E
STA $3B
LDA #$10
STA $3E
LDA #$A5
STA $2F
JSR murder_init
JSR pickups_init
JSR ufo_init
JSR set_game_rocks
LDA #$20
STA $2006
LDA #$00
STA $2006
LDY #$04
LDX #$00
LDA #$00
results_blank23:
STA $2007
INX
BNE results_blank23
DEY
BNE results_blank23
JSR load_hud
LDA #$01
STA $06
JSR render
LDA #$00
STA $2003
LDA #$02
STA $4014
JMP results_on23
results_draw_rank23:
CMP #$00
BNE rank_skip023
JMP rank_draw023
rank_skip023:
CMP #$01
BNE rank_skip123
JMP rank_draw123
rank_skip123:
CMP #$02
BNE rank_skip223
JMP rank_draw223
rank_skip223:
CMP #$03
BNE rank_skip323
JMP rank_draw323
rank_skip323:
CMP #$04
BNE rank_skip423
JMP rank_draw423
rank_skip423:
CMP #$05
BNE rank_skip523
JMP rank_draw523
rank_skip523:
CMP #$06
BNE rank_skip623
JMP rank_draw623
rank_skip623:
CMP #$07
BNE rank_skip723
JMP rank_draw723
rank_skip723:
CMP #$08
BNE rank_skip823
JMP rank_draw823
rank_skip823:
CMP #$09
BNE rank_skip923
JMP rank_draw923
rank_skip923:
CMP #$0A
BNE rank_skip1023
JMP rank_draw1023
rank_skip1023:
RTS
rank_draw023:
LDX #$00
rank_chars023:
LDA rank_0_23,X
STA $2007
INX
CPX #$20
BNE rank_chars023
RTS
rank_draw123:
LDX #$00
rank_chars123:
LDA rank_1_23,X
STA $2007
INX
CPX #$20
BNE rank_chars123
RTS
rank_draw223:
LDX #$00
rank_chars223:
LDA rank_2_23,X
STA $2007
INX
CPX #$20
BNE rank_chars223
RTS
rank_draw323:
LDX #$00
rank_chars323:
LDA rank_3_23,X
STA $2007
INX
CPX #$20
BNE rank_chars323
RTS
rank_draw423:
LDX #$00
rank_chars423:
LDA rank_4_23,X
STA $2007
INX
CPX #$20
BNE rank_chars423
RTS
rank_draw523:
LDX #$00
rank_chars523:
LDA rank_5_23,X
STA $2007
INX
CPX #$20
BNE rank_chars523
RTS
rank_draw623:
LDX #$00
rank_chars623:
LDA rank_6_23,X
STA $2007
INX
CPX #$20
BNE rank_chars623
RTS
rank_draw723:
LDX #$00
rank_chars723:
LDA rank_7_23,X
STA $2007
INX
CPX #$20
BNE rank_chars723
RTS
rank_draw823:
LDX #$00
rank_chars823:
LDA rank_8_23,X
STA $2007
INX
CPX #$20
BNE rank_chars823
RTS
rank_draw923:
LDX #$00
rank_chars923:
LDA rank_9_23,X
STA $2007
INX
CPX #$20
BNE rank_chars923
RTS
rank_draw1023:
LDX #$00
rank_chars1023:
LDA rank_10_23,X
STA $2007
INX
CPX #$20
BNE rank_chars1023
RTS
pulse_gate24c:
LDA $06
BEQ pulse_mute24c
LDA $0677
BNE pulse_mute24c
LDA $80
BEQ pulse_mute24c
JMP asteroid_pulse24
pulse_mute24c:
JMP asteroid_pulse_off24
asteroid_pulse24:
LDA $067F
BEQ pulse_due24c
DEC $067F
RTS
pulse_due24c:
LDA $81
pulse_fire24:
STA $067F
LDA $7C
EOR #$01
STA $7C
TAX
LDA #$18
STA $4008
LDA pulse_timer24,X
STA $400A
LDA pulse_high24,X
STA $400B
LDA $4015
AND #$0F
ORA #$04
STA $4015
RTS
asteroid_pulse_off24:
LDA #$00
STA $067F
LDA $4015
AND #$0B
STA $4015
RTS
pulse_recalculate24d:
LDA $7F
BEQ pulse_default24d
LDA $7E
CMP $7F
BCS pulse_complete24
ASL A
ASL A
STA $7D
LDA $7F
ASL A
CLC
ADC $7F
STA $7B
LDA $7D
CMP $7B
BCS pulse_75_24
LDA $7E
ASL A
CMP $7F
BCS pulse_50_24
LDA $7E
ASL A
ASL A
CMP $7F
BCS pulse_25_24
pulse_default24d:
LDA #$30
JMP pulse_interval24
pulse_25_24:
LDA #$24
JMP pulse_interval24
pulse_50_24:
LDA #$19
JMP pulse_interval24
pulse_75_24:
LDA #$10
JMP pulse_interval24
pulse_complete24:
LDA #$09
pulse_interval24:
STA $81
RTS
sfx_tick25:
LDA $82
BEQ sfx_noise_tick25
LDX $83
LDA shot_volume25,X
ORA #$B0
STA $4000
LDA shot_timer25,X
STA $4002
LDA #$00
STA $4003
INC $83
DEC $82
BNE sfx_noise_tick25
LDA $4015
AND #$FE
STA $4015
sfx_noise_tick25:
LDA $84
BEQ sfx_done25
DEC $84
LDA $84
LSR A
ORA #$30
STA $400C
LDA $85
STA $400E
LDA $84
BNE sfx_done25
LDA $4015
AND #$F7
STA $4015
sfx_done25:
RTS
sfx_shot_start25:
LDA #$0B
STA $82
LDA #$01
STA $83
LDA #$BF
STA $4000
LDA #$8E
STA $4002
LDA #$00
STA $4003
LDA $4015
ORA #$01
STA $4015
RTS
sfx_asteroid_start25:
CMP #$01
BEQ sfx_large25
CMP #$02
BEQ sfx_medium25
LDA #$0C
JMP sfx_noise_start25
sfx_large25:
LDA #$0E
JMP sfx_noise_start25
sfx_medium25:
LDA #$0D
sfx_noise_start25:
STA $85
LDA #$1E
STA $84
LDA #$3F
STA $400C
LDA $85
STA $400E
LDA #$00
STA $400F
LDA $4015
ORA #$08
STA $4015
RTS
shield_tick:
LDA $08
BEQ shield_done
DEC $08
shield_done:
RTS
physics:
CLC
LDA $10
ADC $14
STA $10
LDA $11
ADC $15
STA $11
CLC
LDA $12
ADC $16
STA $12
LDA $13
ADC $17
CMP #$F0
BCC ship_y_ok
LDX $17
BMI ship_y_negative
SEC
SBC #$F0
JMP ship_y_ok
ship_y_negative:
CLC
ADC #$F0
ship_y_ok:
STA $13
RTS
bullets:
LDX #$00
bullet_loop:
LDA $0600,X
BNE bullet_active
JMP bullet_next
bullet_active:
LDA $0609,X
BEQ bullet_flying
DEC $0600,X
BNE bullet_next
LDA #$00
STA $0609,X
JMP bullet_next
bullet_flying:
DEC $0600,X
CLC
LDA $0601,X
ADC $0605,X
STA $0601,X
LDA $0602,X
ADC $0606,X
STA $0602,X
CLC
LDA $0603,X
ADC $0607,X
STA $0603,X
LDA $0604,X
ADC $0608,X
CMP #$F0
BCC bullet_y_ok
LDY $0608,X
BMI bullet_y_negative
SEC
SBC #$F0
JMP bullet_y_ok
bullet_y_negative:
CLC
ADC #$F0
bullet_y_ok:
STA $0604,X
bullet_next:
TXA
CLC
ADC #$10
TAX
CPX #$40
BEQ bullets_done
JMP bullet_loop
bullets_done:
RTS
asteroids:
LDX #$00
asteroid_loop0300:
LDA $030A,X
BEQ asteroid_grace_done0300
DEC $030A,X
asteroid_grace_done0300:
CLC
LDA $0300,X
ADC $0304,X
STA $0300,X
LDA $0301,X
ADC $0305,X
STA $0301,X
CLC
LDA $0302,X
ADC $0306,X
STA $0302,X
LDA $0303,X
ADC $0307,X
CMP #$F0
BCC asteroid_y_ok0300
LDY $0307,X
BMI asteroid_y_negative0300
SEC
SBC #$F0
JMP asteroid_y_ok0300
asteroid_y_negative0300:
CLC
ADC #$F0
asteroid_y_ok0300:
STA $0303,X
TXA
CLC
ADC #$10
TAX
BNE asteroid_loop0300
LDX #$00
asteroid_loop0400:
LDA $040A,X
BEQ asteroid_grace_done0400
DEC $040A,X
asteroid_grace_done0400:
CLC
LDA $0400,X
ADC $0404,X
STA $0400,X
LDA $0401,X
ADC $0405,X
STA $0401,X
CLC
LDA $0402,X
ADC $0406,X
STA $0402,X
LDA $0403,X
ADC $0407,X
CMP #$F0
BCC asteroid_y_ok0400
LDY $0407,X
BMI asteroid_y_negative0400
SEC
SBC #$F0
JMP asteroid_y_ok0400
asteroid_y_negative0400:
CLC
ADC #$F0
asteroid_y_ok0400:
STA $0403,X
TXA
CLC
ADC #$10
TAX
BNE asteroid_loop0400
LDX #$00
asteroid_loop0500:
LDA $050A,X
BEQ asteroid_grace_done0500
DEC $050A,X
asteroid_grace_done0500:
CLC
LDA $0500,X
ADC $0504,X
STA $0500,X
LDA $0501,X
ADC $0505,X
STA $0501,X
CLC
LDA $0502,X
ADC $0506,X
STA $0502,X
LDA $0503,X
ADC $0507,X
CMP #$F0
BCC asteroid_y_ok0500
LDY $0507,X
BMI asteroid_y_negative0500
SEC
SBC #$F0
JMP asteroid_y_ok0500
asteroid_y_negative0500:
CLC
ADC #$F0
asteroid_y_ok0500:
STA $0503,X
TXA
CLC
ADC #$10
TAX
BNE asteroid_loop0500
RTS
collisions:
LDX #$00
collision_bullet:
LDA $0600,X
BEQ collision_bullet_inactive
LDA $0609,X
BEQ collision_bullet_live
collision_bullet_inactive:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE collision_bullet_continue_inactive
JMP collision_done
collision_bullet_continue_inactive:
JMP collision_bullet
collision_bullet_live:
STX $22
LDA $0602,X
STA $23
LDA $0604,X
STA $24
LDA $060A,X
STA $27
LDX #$00
collision_rocks_0300:
LDA $0308,X
BNE collision_rock_active_0300
JMP collision_rock_next_0300
collision_rock_active_0300:
STA $26
LDA $030A,X
BEQ collision_rock_ready_0300
JMP collision_rock_next_0300
collision_rock_ready_0300:
LDA $26
CMP #$01
BEQ collision_width_large_0300
CMP #$02
BEQ collision_width_medium_0300
LDA #$08
JMP collision_width_ready_0300
collision_width_large_0300:
LDA #$10
JMP collision_width_ready_0300
collision_width_medium_0300:
LDA #$0C
collision_width_ready_0300:
STA $2B
LDA $23
SEC
SBC $0301,X
CMP $2B
BCC collision_x_ok_0300
CMP #$FD
BCS collision_x_ok_0300
JMP collision_rock_next_0300
collision_x_ok_0300:
LDA $24
SEC
SBC $0303,X
BCS collision_y_delta_0300
SEC
SBC #$10
collision_y_delta_0300:
CMP $2B
BCC collision_y_ok_0300
CMP #$ED
BCS collision_y_ok_0300
JMP collision_rock_next_0300
collision_y_ok_0300:
JSR collision_explode
LDA $26
JSR sfx_asteroid_start25
TXA
STA $45
LDA #$03
STA $46
JSR pickup_drop
LDA $26
CMP #$01
BEQ collision_large_0300
CMP #$02
BEQ collision_medium_0300
LDY #$08
LDA #$00
STA ($45),Y
INC $39
LDA #$64
JSR score_add
JMP collision_next_bullet
collision_large_0300:
JSR spawn_mediums_generic
LDA #$19
JSR score_add
JMP collision_next_bullet
collision_medium_0300:
JSR spawn_smalls_generic
LDA #$32
JSR score_add
JMP collision_next_bullet
collision_rock_next_0300:
TXA
CLC
ADC #$10
TAX
BNE collision_rocks_continue_0300
JMP collision_rocks_done_0300
collision_rocks_continue_0300:
JMP collision_rocks_0300
collision_rocks_done_0300:
LDX #$00
collision_rocks_0400:
LDA $0408,X
BNE collision_rock_active_0400
JMP collision_rock_next_0400
collision_rock_active_0400:
STA $26
LDA $040A,X
BEQ collision_rock_ready_0400
JMP collision_rock_next_0400
collision_rock_ready_0400:
LDA $26
CMP #$01
BEQ collision_width_large_0400
CMP #$02
BEQ collision_width_medium_0400
LDA #$08
JMP collision_width_ready_0400
collision_width_large_0400:
LDA #$10
JMP collision_width_ready_0400
collision_width_medium_0400:
LDA #$0C
collision_width_ready_0400:
STA $2B
LDA $23
SEC
SBC $0401,X
CMP $2B
BCC collision_x_ok_0400
CMP #$FD
BCS collision_x_ok_0400
JMP collision_rock_next_0400
collision_x_ok_0400:
LDA $24
SEC
SBC $0403,X
BCS collision_y_delta_0400
SEC
SBC #$10
collision_y_delta_0400:
CMP $2B
BCC collision_y_ok_0400
CMP #$ED
BCS collision_y_ok_0400
JMP collision_rock_next_0400
collision_y_ok_0400:
JSR collision_explode
LDA $26
JSR sfx_asteroid_start25
TXA
STA $45
LDA #$04
STA $46
JSR pickup_drop
LDA $26
CMP #$01
BEQ collision_large_0400
CMP #$02
BEQ collision_medium_0400
LDY #$08
LDA #$00
STA ($45),Y
INC $39
LDA #$64
JSR score_add
JMP collision_next_bullet
collision_large_0400:
JSR spawn_mediums_generic
LDA #$19
JSR score_add
JMP collision_next_bullet
collision_medium_0400:
JSR spawn_smalls_generic
LDA #$32
JSR score_add
JMP collision_next_bullet
collision_rock_next_0400:
TXA
CLC
ADC #$10
TAX
BNE collision_rocks_continue_0400
JMP collision_rocks_done_0400
collision_rocks_continue_0400:
JMP collision_rocks_0400
collision_rocks_done_0400:
LDX #$00
collision_rocks_0500:
LDA $0508,X
BNE collision_rock_active_0500
JMP collision_rock_next_0500
collision_rock_active_0500:
STA $26
LDA $050A,X
BEQ collision_rock_ready_0500
JMP collision_rock_next_0500
collision_rock_ready_0500:
LDA $26
CMP #$01
BEQ collision_width_large_0500
CMP #$02
BEQ collision_width_medium_0500
LDA #$08
JMP collision_width_ready_0500
collision_width_large_0500:
LDA #$10
JMP collision_width_ready_0500
collision_width_medium_0500:
LDA #$0C
collision_width_ready_0500:
STA $2B
LDA $23
SEC
SBC $0501,X
CMP $2B
BCC collision_x_ok_0500
CMP #$FD
BCS collision_x_ok_0500
JMP collision_rock_next_0500
collision_x_ok_0500:
LDA $24
SEC
SBC $0503,X
BCS collision_y_delta_0500
SEC
SBC #$10
collision_y_delta_0500:
CMP $2B
BCC collision_y_ok_0500
CMP #$ED
BCS collision_y_ok_0500
JMP collision_rock_next_0500
collision_y_ok_0500:
JSR collision_explode
LDA $26
JSR sfx_asteroid_start25
TXA
STA $45
LDA #$05
STA $46
JSR pickup_drop
LDA $26
CMP #$01
BEQ collision_large_0500
CMP #$02
BEQ collision_medium_0500
LDY #$08
LDA #$00
STA ($45),Y
INC $39
LDA #$64
JSR score_add
JMP collision_next_bullet
collision_large_0500:
JSR spawn_mediums_generic
LDA #$19
JSR score_add
JMP collision_next_bullet
collision_medium_0500:
JSR spawn_smalls_generic
LDA #$32
JSR score_add
JMP collision_next_bullet
collision_rock_next_0500:
TXA
CLC
ADC #$10
TAX
BNE collision_rocks_continue_0500
JMP collision_rocks_done_0500
collision_rocks_continue_0500:
JMP collision_rocks_0500
collision_rocks_done_0500:
collision_next_bullet:
LDX $22
TXA
CLC
ADC #$10
TAX
CPX #$40
BEQ collision_done
JMP collision_bullet
collision_done:
RTS
collision_explode:
LDY $22
LDA #$0F
STA $0600,Y
LDA #$01
STA $0609,Y
LDA #$00
STA $0605,Y
STA $0606,Y
STA $0607,Y
STA $0608,Y
RTS
score_add:
STA $25
CLC
LDA $30
ADC $25
STA $30
LDA $31
ADC #$00
STA $31
LDA $32
ADC #$00
STA $32
score_add_loop:
JSR score_decimal_add
LDA $32
CMP $3C
BCC score_check_done
BNE score_extra_life
LDA $31
CMP $3B
BCC score_check_done
BNE score_extra_life
LDA $30
CMP $3A
BCC score_check_done
score_extra_life:
INC $3D
CLC
LDA $3A
ADC #$20
STA $3A
LDA $3B
ADC #$4E
STA $3B
LDA $3C
ADC #$00
STA $3C
score_check_done:
RTS
score_decimal_add:
LDA #$00
STA $6C
STA $6D
LDA $25
score_decimal_hundreds:
CMP #$64
BCC score_decimal_tens
SEC
SBC #$64
INC $6C
JMP score_decimal_hundreds
score_decimal_tens:
CMP #$0A
BCC score_decimal_ones
SEC
SBC #$0A
INC $6D
JMP score_decimal_tens
score_decimal_ones:
CLC
ADC $38
CMP #$0A
BCC score_decimal_ones_ready
SEC
SBC #$0A
INC $6D
score_decimal_ones_ready:
STA $38
LDA $6D
CLC
ADC $37
CMP #$0A
BCC score_decimal_tens_ready
SEC
SBC #$0A
INC $6C
score_decimal_tens_ready:
STA $37
LDA $6C
CLC
ADC $36
CMP #$0A
BCC score_decimal_hundreds_ready
SEC
SBC #$0A
INC $35
score_decimal_hundreds_ready:
STA $36
LDA $35
CMP #$0A
BCC score_decimal_done
LDA #$00
STA $35
INC $34
LDA $34
CMP #$0A
BCC score_decimal_done
LDA #$00
STA $34
INC $33
LDA $33
CMP #$0A
BCC score_decimal_done
LDA #$00
STA $33
score_decimal_done:
RTS
score_increment:
INC $38
LDA $38
CMP #$0A
BCC score_inc_done
LDA #$00
STA $38
INC $37
LDA $37
CMP #$0A
BCC score_inc_done
LDA #$00
STA $37
INC $36
LDA $36
CMP #$0A
BCC score_inc_done
LDA #$00
STA $36
INC $35
LDA $35
CMP #$0A
BCC score_inc_done
LDA #$00
STA $35
INC $34
LDA $34
CMP #$0A
BCC score_inc_done
LDA #$00
STA $34
INC $33
LDA $33
CMP #$0A
BCC score_inc_done
LDA #$00
STA $33
score_inc_done:
RTS
spawn_mediums_generic:
LDA #$02
STA $2D
JMP spawn_children_generic
spawn_smalls_generic:
INC $7E
JSR pulse_recalculate24d
LDA #$03
STA $2D
spawn_children_generic:
LDY #$01
LDA ($45),Y
STA $47
LDY #$03
LDA ($45),Y
STA $48
JSR allocate_asteroid_record
LDA $43
STA $49
LDA $44
STA $4A
LDA $45
STA $43
LDA $46
STA $44
JSR fragment_clockwise
STA $2E
JSR write_fragment
LDA $49
STA $43
LDA $4A
STA $44
JSR fragment_counterclockwise
STA $2E
JSR write_fragment
RTS
allocate_asteroid_record:
LDX #$00
allocate_page3:
LDA $0308,X
BEQ allocate_found3
TXA
CLC
ADC #$10
TAX
BNE allocate_page3
LDX #$00
allocate_page4:
LDA $0408,X
BEQ allocate_found4
TXA
CLC
ADC #$10
TAX
BNE allocate_page4
LDX #$00
allocate_page5:
LDA $0508,X
BEQ allocate_found5
TXA
CLC
ADC #$10
TAX
BNE allocate_page5
RTS
allocate_found3:
STX $43
LDA #$03
STA $44
RTS
allocate_found4:
STX $43
LDA #$04
STA $44
RTS
allocate_found5:
STX $43
LDA #$05
STA $44
RTS
write_fragment:
LDY #$00
LDA #$00
STA ($43),Y
LDY #$01
LDX $2E
LDA $47
CLC
ADC spawnxoff,X
STA ($43),Y
LDY #$02
LDA #$00
STA ($43),Y
LDY #$03
LDA $48
CLC
ADC spawnyoff,X
CMP #$F0
BCC fragment_y_ok
SEC
SBC #$F0
fragment_y_ok:
STA ($43),Y
LDA $2D
CMP #$02
BEQ write_medium_velocity
LDX $2E
LDY #$04
LDA sxlo,X
STA ($43),Y
LDY #$05
LDA sxhi,X
STA ($43),Y
LDY #$06
LDA sylo,X
STA ($43),Y
LDY #$07
LDA syhi,X
STA ($43),Y
JMP write_fragment_finish
write_medium_velocity:
LDX $2E
LDY #$04
LDA mxlo,X
STA ($43),Y
LDY #$05
LDA mxhi,X
STA ($43),Y
LDY #$06
LDA mylo,X
STA ($43),Y
LDY #$07
LDA myhi,X
STA ($43),Y
write_fragment_finish:
LDY #$08
LDA $2D
STA ($43),Y
LDY #$09
LDA $2E
STA ($43),Y
LDY #$0A
LDA #$03
STA ($43),Y
RTS
random:
LDA $2F
ASL A
BCC random_no_xor
EOR #$1D
random_no_xor:
STA $2F
RTS
random_13:
JSR random
AND #$0F
CMP #$0D
BCC random_13_done
SEC
SBC #$0D
random_13_done:
RTS
normalize_heading:
BMI normalize_negative
CMP #$30
BCC normalize_done
SEC
SBC #$30
RTS
normalize_negative:
CLC
ADC #$30
normalize_done:
RTS
fragment_clockwise:
JSR random_13
CLC
ADC $27
JMP normalize_heading
fragment_counterclockwise:
JSR random_13
STA $28
LDA $27
SEC
SBC $28
JMP normalize_heading
large_velocity_page0:
STA $0309,X
TAY
LDA lxlo,Y
STA $0304,X
LDA lxhi,Y
STA $0305,X
LDA lylo,Y
STA $0306,X
LDA lyhi,Y
STA $0307,X
RTS
medium_velocity_page0:
STA $0309,Y
TAX
LDA mxlo,X
STA $0304,Y
LDA mxhi,X
STA $0305,Y
LDA mylo,X
STA $0306,Y
LDA myhi,X
STA $0307,Y
LDA $0301,Y
CLC
ADC spawnxoff,X
STA $0301,Y
LDA $0303,Y
CLC
ADC spawnyoff,X
CMP #$F0
BCC medium_spawn_y_ok
SEC
SBC #$F0
medium_spawn_y_ok:
STA $0303,Y
RTS
small_velocity_page0:
STA $0309,Y
TAX
LDA sxlo,X
STA $0304,Y
LDA sxhi,X
STA $0305,Y
LDA sylo,X
STA $0306,Y
LDA syhi,X
STA $0307,Y
LDA $0301,Y
CLC
ADC spawnxoff,X
STA $0301,Y
LDA $0303,Y
CLC
ADC spawnyoff,X
CMP #$F0
BCC small0_spawn_y_ok
SEC
SBC #$F0
small0_spawn_y_ok:
STA $0303,Y
RTS
small_velocity_page1:
STA $0409,Y
TAX
LDA sxlo,X
STA $0404,Y
LDA sxhi,X
STA $0405,Y
LDA sylo,X
STA $0406,Y
LDA syhi,X
STA $0407,Y
LDA $0401,Y
CLC
ADC spawnxoff,X
STA $0401,Y
LDA $0403,Y
CLC
ADC spawnyoff,X
CMP #$F0
BCC small1_spawn_y_ok
SEC
SBC #$F0
small1_spawn_y_ok:
STA $0403,Y
RTS
ufo_init:
LDA #$58
STA $064A
LDA #$02
STA $064B
ufo_wave_reset:
LDA #$00
STA $0640
STA $0647
STA $0650
STA $0660
STA $41
ufo_reload:
LDA $064A
STA $0648
LDA $064B
STA $0649
RTS
ufo_tick:
LDA $06
BNE ufo_game_tick
RTS
ufo_game_tick:
JSR ufo_shot_tick
JSR ufo_shot_tick2
LDA $0647
BEQ ufo_not_exploding
DEC $0647
RTS
ufo_not_exploding:
LDA $0640
BEQ ufo_idle
JMP ufo_move
ufo_idle:
LDA $40
BEQ ufo_check_rocks
RTS
ufo_check_rocks:
LDX #$00
ufo_rock_scan:
LDA $0308,X
ORA $0408,X
ORA $0508,X
BNE ufo_timer
TXA
CLC
ADC #$10
TAX
BNE ufo_rock_scan
RTS
ufo_timer:
LDA $0648
ORA $0649
BEQ ufo_spawn
LDA $0648
BNE ufo_timer_low
DEC $0649
ufo_timer_low:
DEC $0648
LDA $0648
ORA $0649
BEQ ufo_spawn
RTS
ufo_spawn:
LDA #$01
STA $0640
STA $41
LDA $3F
SEC
SBC #$04
TAX
JSR random
CMP ufo_small_chance,X
BCS ufo_size_ready
INC $0640
ufo_size_ready:
JSR random
AND #$01
STA $0643
BEQ ufo_from_left
LDA #$F4
JMP ufo_set_x
ufo_from_left:
LDA #$00
ufo_set_x:
STA $0641
JSR random
AND #$7F
CLC
ADC #$30
STA $0642
LDA #$00
STA $0644
LDA #$3C
STA $0645
LDA #$3C
STA $0646
LDA $064A
SEC
SBC #$18
STA $064A
LDA $064B
SBC #$00
STA $064B
BNE ufo_spawn_done
LDA $064A
CMP #$78
BCS ufo_spawn_done
LDA #$78
STA $064A
ufo_spawn_done:
RTS
ufo_move:
DEC $0645
BNE ufo_course_ready
LDA #$3C
STA $0645
JSR random
AND #$03
TAX
LDA #$00
CPX #$02
BCS ufo_set_course
LDA #$01
CPX #$00
BEQ ufo_set_course
LDA #$FF
ufo_set_course:
STA $0644
ufo_course_ready:
LDA $0645
AND #$01
BNE ufo_y_done
LDA $0642
CLC
ADC $0644
CMP #$20
BCC ufo_y_done
CMP #$D8
BCS ufo_y_done
STA $0642
ufo_y_done:
LDA $0645
AND #$01
BNE ufo_fire_timer
LDA $0645
AND #$01
BNE ufo_fire_timer
ufo_step_x:
LDA $0643
BNE ufo_leftward
INC $0641
LDA $0641
CMP #$F5
BCS ufo_exit
JMP ufo_fire_timer
ufo_leftward:
LDA $0641
BEQ ufo_exit
DEC $0641
ufo_fire_timer:
DEC $0646
BNE ufo_move_done
LDA #$3C
STA $0646
LDA $0650
BEQ ufo_fire_first
LDA $0660
BNE ufo_move_done
JSR ufo_fire2
RTS
ufo_fire_first:
JSR ufo_fire
ufo_move_done:
RTS
ufo_exit:
LDA #$00
STA $0640
STA $41
JMP ufo_reload
ufo_fire:
LDA $0641
CLC
ADC #$02
STA $0652
LDA $0642
CLC
ADC #$02
STA $0654
LDA #$00
STA $0651
STA $0653
LDA #$60
STA $0650
LDA $0640
CMP #$02
BEQ ufo_aimed
JSR random
ufo_random_reduce:
CMP #$30
BCC ufo_heading_ready
SEC
SBC #$30
JMP ufo_random_reduce
ufo_aimed:
JSR ufo_aim_heading
ufo_heading_ready:
STA $0659
TAX
LDA ufo_xlo,X
STA $0655
LDA ufo_xhi,X
STA $0656
LDA ufo_ylo,X
STA $0657
LDA ufo_yhi,X
STA $0658
RTS
ufo_aim_heading:
LDA #$00
STA $54
STA $55
LDA $11
SEC
SBC $0652
BPL ufo_dx_positive
INC $54
EOR #$FF
CLC
ADC #$01
ufo_dx_positive:
STA $52
LDA $13
SEC
SBC $0654
BCS ufo_dy_wrapped
CLC
ADC #$F0
ufo_dy_wrapped:
CMP #$78
BCC ufo_dy_positive
SEC
SBC #$F0
BPL ufo_dy_positive
INC $55
EOR #$FF
CLC
ADC #$01
ufo_dy_positive:
STA $53
ufo_aim_scale:
LDA $52
ORA $53
CMP #$10
BCC ufo_aim_lookup
LSR $52
LSR $53
JMP ufo_aim_scale
ufo_aim_lookup:
LDA $53
ASL A
ASL A
ASL A
ASL A
ORA $52
TAX
LDA ufo_aim,X
LDX $55
BEQ ufo_aim_x_sign
STA $52
LDA #$18
SEC
SBC $52
ufo_aim_x_sign:
LDX $54
BEQ ufo_aim_normalize
STA $52
LDA #$30
SEC
SBC $52
ufo_aim_normalize:
JMP normalize_heading
ufo_shot_tick:
LDA $0650
BNE ufo_shot_live
RTS
ufo_shot_live:
DEC $0650
CLC
LDA $0651
ADC $0655
STA $0651
LDA $0652
ADC $0656
STA $0652
CLC
LDA $0653
ADC $0657
STA $0653
LDA $0654
ADC $0658
CMP #$F0
BCC ufo_shot_y_ready
LDX $0658
BMI ufo_shot_y_negative
SEC
SBC #$F0
JMP ufo_shot_y_ready
ufo_shot_y_negative:
CLC
ADC #$F0
ufo_shot_y_ready:
STA $0654
RTS
ufo_fire2:
LDA $0641
CLC
ADC #$02
STA $0662
LDA $0642
CLC
ADC #$02
STA $0664
LDA #$00
STA $0661
STA $0663
LDA #$60
STA $0660
LDA $0640
CMP #$02
BEQ ufo_aimed2
JSR random
ufo_random_reduce2:
CMP #$30
BCC ufo_heading_ready2
SEC
SBC #$30
JMP ufo_random_reduce2
ufo_aimed2:
JSR ufo_aim_heading2
ufo_heading_ready2:
STA $0669
TAX
LDA ufo_xlo,X
STA $0665
LDA ufo_xhi,X
STA $0666
LDA ufo_ylo,X
STA $0667
LDA ufo_yhi,X
STA $0668
RTS
ufo_aim_heading2:
LDA #$00
STA $54
STA $55
LDA $11
SEC
SBC $0662
BPL ufo_dx_positive2
INC $54
EOR #$FF
CLC
ADC #$01
ufo_dx_positive2:
STA $52
LDA $13
SEC
SBC $0664
BCS ufo_dy_wrapped2
CLC
ADC #$F0
ufo_dy_wrapped2:
CMP #$78
BCC ufo_dy_positive2
SEC
SBC #$F0
BPL ufo_dy_positive2
INC $55
EOR #$FF
CLC
ADC #$01
ufo_dy_positive2:
STA $53
ufo_aim_scale2:
LDA $52
ORA $53
CMP #$10
BCC ufo_aim_lookup2
LSR $52
LSR $53
JMP ufo_aim_scale2
ufo_aim_lookup2:
LDA $53
ASL A
ASL A
ASL A
ASL A
ORA $52
TAX
LDA ufo_aim,X
LDX $55
BEQ ufo_aim_x_sign2
STA $52
LDA #$18
SEC
SBC $52
ufo_aim_x_sign2:
LDX $54
BEQ ufo_aim_normalize2
STA $52
LDA #$30
SEC
SBC $52
ufo_aim_normalize2:
JMP normalize_heading
ufo_shot_tick2:
LDA $0660
BNE ufo_shot_live2
RTS
ufo_shot_live2:
DEC $0660
CLC
LDA $0661
ADC $0665
STA $0661
LDA $0662
ADC $0666
STA $0662
CLC
LDA $0663
ADC $0667
STA $0663
LDA $0664
ADC $0668
CMP #$F0
BCC ufo_shot_y_ready2
LDX $0668
BMI ufo_shot_y_negative2
SEC
SBC #$F0
JMP ufo_shot_y_ready2
ufo_shot_y_negative2:
CLC
ADC #$F0
ufo_shot_y_ready2:
STA $0664
RTS
ufo_collisions:
LDA $06
BEQ ufo_collision_done
LDA $0640
BEQ ufo_collision_done
CMP #$01
BEQ ufo_hit_big
LDA #$08
JMP ufo_hit_width
ufo_hit_big:
LDA #$0C
ufo_hit_width:
STA $52
LDX #$00
ufo_hit_loop:
LDA $0600,X
BEQ ufo_hit_next
LDA $0609,X
BNE ufo_hit_next
LDA $0602,X
SEC
SBC $0641
CMP $52
BCC ufo_hit_x
CMP #$FD
BCC ufo_hit_next
ufo_hit_x:
LDA $0604,X
SEC
SBC $0642
CMP $52
BCC ufo_hit_confirm
CMP #$FD
BCC ufo_hit_next
ufo_hit_confirm:
STX $22
JSR collision_explode
LDA $0640
STA $53
LDA #$00
STA $0640
STA $41
LDA #$0F
STA $0647
JSR ufo_reload
LDA $53
CMP #$01
BEQ ufo_score_big
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
ufo_score_big:
LDA #$C8
JSR score_add
RTS
ufo_hit_next:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE ufo_hit_loop
ufo_collision_done:
RTS
render_ufo:
LDA $0650
BEQ render_ufo_body
LDA $0654
SEC
SBC #$01
STA $0224
LDA #$25
STA $0225
LDA #$00
STA $0226
LDA $0652
STA $0227
render_ufo_body:
LDA $0660
BEQ render_ufo_body_after_shots
LDA $0664
SEC
SBC #$01
STA $0228
LDA #$25
STA $0229
LDA #$00
STA $022A
LDA $0662
STA $022B
render_ufo_body_after_shots:
LDA $0647
BEQ render_ufo_alive
SEC
SBC #$01
TAX
LDA explosion_drawing,X
STA $0215
JMP render_ufo_single
render_ufo_alive:
LDA $0640
BNE render_ufo_exists
RTS
render_ufo_exists:
CMP #$01
BEQ render_ufo_big
LDA #$24
STA $0215
render_ufo_single:
LDA $0642
SEC
SBC #$01
STA $0214
LDA $0641
STA $0217
LDA #$00
STA $0216
RTS
render_ufo_big:
LDA $0642
SEC
SBC #$01
STA $0214
STA $0218
CLC
ADC #$08
STA $021C
STA $0220
LDA $0641
STA $0217
STA $021F
CLC
ADC #$08
STA $021B
STA $0223
LDA #$00
STA $0216
STA $021A
STA $021E
STA $0222
LDA #$20
STA $0215
LDA #$21
STA $0219
LDA #$22
STA $021D
LDA #$23
STA $0221
RTS
pickups_init:
LDA #$00
STA $0676
STA $0672
JSR pickup_reset_counter
JMP pickups_clear_begin
pickup_reset_counter:
LDA #$00
STA $0670
STA $0671
RTS
pickup_player_death:
RTS
pickups_clear_begin:
LDX #$00
pickups_clear:
STA $0700,X
INX
BNE pickups_clear
RTS
pickup_drop:
LDA $26
CMP #$03
BEQ pickup_small_destroyed
RTS
pickup_small_destroyed:
INC $0670
LDA $0670
AND #$01
BEQ pickup_should_drop
RTS
pickup_should_drop:
STX $56
LDX #$00
LDA #$FF
STA $5A
STA $5B
STA $57
pickup_find_slot:
LDA $0708,X
BEQ pickup_slot_found
LDA $070D,X
BNE pickup_slot_next
LDA $070A,X
CMP $5B
BCC pickup_oldest
BNE pickup_slot_next
LDA $0709,X
CMP $5A
BCS pickup_slot_next
pickup_oldest:
STX $57
LDA $0709,X
STA $5A
LDA $070A,X
STA $5B
pickup_slot_next:
TXA
CLC
ADC #$10
TAX
BNE pickup_find_slot
LDX $57
CPX #$FF
BNE pickup_slot_found
LDX $56
RTS
pickup_slot_found:
STX $57
LDY #$01
LDA ($45),Y
STA $0701,X
LDY #$03
LDA ($45),Y
STA $0703,X
LDA #$00
STA $0700,X
STA $0702,X
STA $070C,X
STA $070D,X
LDA #$0A
STA $070B,X
LDA #$A4
STA $0709,X
LDA #$01
STA $070A,X
LDY $0671
LDA pickup_order,Y
CMP #$0A
BNE pickup_type_ready
LDA $0676
CMP #$03
BCC pickup_type_magnet
LDA #$04
JMP pickup_type_ready
pickup_type_magnet:
LDA #$0A
pickup_type_ready:
STA $0708,X
INC $0671
LDA $0671
CMP #$18
BCC pickup_order_ready
LDA #$00
STA $0671
pickup_order_ready:
JSR random
pickup_random_reduce:
CMP #$30
BCC pickup_direction_ready
SEC
SBC #$30
JMP pickup_random_reduce
pickup_direction_ready:
TAY
LDX $57
LDA pickup_xlo,Y
STA $0704,X
LDA pickup_xhi,Y
STA $0705,X
LDA pickup_ylo,Y
STA $0706,X
LDA pickup_yhi,Y
STA $0707,X
LDX $56
RTS
pickups_tick:
LDA $06
BNE pickups_tick_game
RTS
pickups_tick_game:
LDX #$00
pickups_tick_loop:
LDA $0708,X
BNE pickup_tick_active
JMP pickup_tick_next
pickup_tick_active:
LDA $070D,X
BEQ pickup_tick_drifting
JSR pickup_attract_velocity
JMP pickup_still_alive
pickup_tick_drifting:
LDA $0709,X
BNE pickup_timer_low
DEC $070A,X
pickup_timer_low:
DEC $0709,X
LDA $0709,X
ORA $070A,X
BNE pickup_still_alive
STA $0708,X
JMP pickup_tick_next
pickup_still_alive:
DEC $070B,X
BNE pickup_animation_done
LDA #$0A
STA $070B,X
LDA $070C,X
EOR #$01
STA $070C,X
pickup_animation_done:
CLC
LDA $0700,X
ADC $0704,X
STA $0700,X
LDA $0701,X
ADC $0705,X
STA $0701,X
CLC
LDA $0702,X
ADC $0706,X
STA $0702,X
LDA $0703,X
ADC $0707,X
CMP #$F0
BCC pickup_y_ok
LDY $0707,X
BMI pickup_y_negative
SEC
SBC #$F0
JMP pickup_y_ok
pickup_y_negative:
CLC
ADC #$F0
pickup_y_ok:
STA $0703,X
pickup_tick_next:
TXA
CLC
ADC #$10
TAX
BEQ pickups_tick_done
JMP pickups_tick_loop
pickups_tick_done:
RTS
pickup_attract_velocity:
STX $69
JSR pickup_attract_aim
TAY
LDX $69
LDA attract_xlo,Y
STA $0704,X
LDA attract_xhi,Y
STA $0705,X
LDA attract_ylo,Y
STA $0706,X
LDA attract_yhi,Y
STA $0707,X
RTS
pickup_magnet_convert:
TXA
PHA
LDX #$00
pickup_magnet_convert_loop:
LDA $0708,X
CMP #$0A
BNE pickup_magnet_convert_next
LDA #$04
STA $0708,X
pickup_magnet_convert_next:
TXA
CLC
ADC #$10
TAX
BNE pickup_magnet_convert_loop
PLA
TAX
RTS
pickups_collect:
LDA $06
BNE pickups_collect_game
RTS
pickups_collect_game:
LDX #$00
pickup_collect_loop:
LDA $0708,X
BNE pickup_collect_active
JMP pickup_collect_next
pickup_collect_active:
LDA $070D,X
BNE pickup_collect_arriving
LDY $0676
LDA magnet_bias,Y
STA $6A
LDA magnet_width,Y
STA $6B
JMP pickup_collect_measure
pickup_collect_arriving:
LDA #$07
STA $6A
LDA #$0F
STA $6B
pickup_collect_measure:
LDA $0701,X
SEC
SBC $11
CLC
ADC $6A
CMP $6B
BCC pickup_collect_x_inside
JMP pickup_collect_next
pickup_collect_x_inside:
LDA $0703,X
SEC
SBC $13
BCS pickup_collect_y_positive
CLC
ADC #$F0
pickup_collect_y_positive:
CLC
ADC $6A
CMP #$F0
BCC pickup_collect_y_wrapped
SEC
SBC #$F0
pickup_collect_y_wrapped:
CMP $6B
BCC pickup_collect_inside
JMP pickup_collect_next
pickup_collect_inside:
LDA $070D,X
BNE pickup_collect_award
LDA #$01
STA $070D,X
JMP pickup_collect_next
pickup_collect_award:
LDA $0708,X
TAY
LDA #$00
STA $0708,X
CPY #$05
BEQ pickup_collect_speed
CPY #$06
BEQ pickup_collect_super
CPY #$0A
BEQ pickup_collect_magnet
JMP pickup_collect_points
pickup_collect_speed:
LDA $0672
CMP #$02
BCS pickup_collect_next
INC $0672
JMP pickup_collect_next
pickup_collect_super:
LDA $07
CMP #$05
BCS pickup_collect_next
INC $07
JMP pickup_collect_next
pickup_collect_magnet:
LDA $0676
CMP #$03
BCS pickup_collect_magnet_max
INC $0676
LDA $0676
CMP #$03
BNE pickup_collect_next
JSR pickup_magnet_convert
JMP pickup_collect_next
pickup_collect_magnet_max:
LDY #$04
pickup_collect_points:
STX $56
LDA pickup_score_chunks,Y
STA $57
pickup_points_loop:
LDA #$FA
JSR score_add
DEC $57
BNE pickup_points_loop
LDX $56
pickup_collect_next:
TXA
CLC
ADC #$10
TAX
BEQ pickups_collect_done
JMP pickup_collect_loop
pickups_collect_done:
RTS
pickup_attract_aim:
LDA #$00
STA $54
STA $55
LDA $11
SEC
SBC $0701,X
BPL pickup_attract_dx_positive
INC $54
EOR #$FF
CLC
ADC #$01
pickup_attract_dx_positive:
STA $52
LDA $13
SEC
SBC $0703,X
BCS pickup_attract_dy_wrapped
CLC
ADC #$F0
pickup_attract_dy_wrapped:
CMP #$78
BCC pickup_attract_dy_positive
SEC
SBC #$F0
BPL pickup_attract_dy_positive
INC $55
EOR #$FF
CLC
ADC #$01
pickup_attract_dy_positive:
STA $53
pickup_attract_aim_scale:
LDA $52
ORA $53
CMP #$10
BCC pickup_attract_aim_lookup
LSR $52
LSR $53
JMP pickup_attract_aim_scale
pickup_attract_aim_lookup:
LDA $53
ASL A
ASL A
ASL A
ASL A
ORA $52
TAX
LDA ufo_aim,X
LDX $55
BEQ pickup_attract_aim_x_sign
STA $52
LDA #$18
SEC
SBC $52
pickup_attract_aim_x_sign:
LDX $54
BEQ pickup_attract_aim_normalize
STA $52
LDA #$30
SEC
SBC $52
pickup_attract_aim_normalize:
JMP normalize_heading
pickup_boost_shot:
LDA $0672
BEQ pickup_boost_done
STA $58
STY $59
LDY $060A,X
pickup_boost_loop:
CLC
LDA $0605,X
ADC boost_xlo,Y
STA $0605,X
LDA $0606,X
ADC boost_xhi,Y
STA $0606,X
CLC
LDA $0607,X
ADC boost_ylo,Y
STA $0607,X
LDA $0608,X
ADC boost_yhi,Y
STA $0608,X
DEC $58
BNE pickup_boost_loop
LDY $59
pickup_boost_done:
RTS
render_pickup:
LDA $4E
BNE render_pickup_has_room
RTS
render_pickup_has_room:
LDY #$0D
LDA ($43),Y
BNE render_pickup_visible
LDY #$0A
LDA ($43),Y
BNE render_pickup_visible
LDY #$09
LDA ($43),Y
CMP #$79
BCS render_pickup_visible
AND #$08
BEQ render_pickup_visible
RTS
render_pickup_visible:
LDY #$08
LDA ($43),Y
TAX
LDA pickup_tiles,X
LDY #$0C
CLC
ADC ($43),Y
STA $5A
LDA pickup_palettes,X
STA $5B
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
SEC
SBC #$01
LDY $4C
STA $0200,Y
LDA $5A
STA $0201,Y
LDA $5B
STA $0202,Y
LDA $4F
STA $0203,Y
TYA
CLC
ADC #$04
STA $4C
DEC $4E
RTS
murder_init:
LDA #$00
STA $0673
STA $0674
STA $0675
LDX #$5F
murder_init_loop:
STA $0680,X
DEX
BPL murder_init_loop
RTS
murder_count:
LDY #$00
LDX #$00
murder_count_loop:
LDA $0688,X
BEQ murder_count_next
INY
murder_count_next:
TXA
CLC
ADC #$10
TAX
CPX #$60
BNE murder_count_loop
TYA
RTS
murder_spawn_check:
LDA $06
BEQ murder_retry_return
LDA $3F
CMP #$06
BCC murder_retry_return
LDA $0673
BEQ murder_retry_first
CMP #$01
BEQ murder_retry_watch_family
CMP #$02
BEQ murder_retry_tick
murder_retry_return:
RTS
murder_retry_first:
JMP murder_first_spawn_check
murder_retry_watch_family:
JSR murder_count
BNE murder_retry_return
LDA #$02
STA $0673
STA $0675
LDA #$58
STA $0674
RTS
murder_retry_tick:
LDA $0674
BNE murder_retry_low
DEC $0675
murder_retry_low:
DEC $0674
LDA $0674
ORA $0675
BNE murder_retry_return
LDX #$00
murder_retry_scan:
LDA $0308,X
ORA $0408,X
ORA $0508,X
BNE murder_retry_spawn
TXA
CLC
ADC #$10
TAX
BNE murder_retry_scan
LDA #$03
STA $0673
RTS
murder_retry_spawn:
JMP murder_spawn_count_ready
murder_first_spawn_check:
LDA $06
BEQ murder_spawn_ineligible
LDA $0673
BNE murder_spawn_ineligible
LDA $3F
CMP #$06
BCS murder_spawn_eligible
murder_spawn_ineligible:
RTS
murder_spawn_eligible:
LDY #$00
LDX #$00
murder_regular_count:
LDA $0308,X
BEQ murder_count_page4
INY
murder_count_page4:
LDA $0408,X
BEQ murder_count_page5
INY
murder_count_page5:
LDA $0508,X
BEQ murder_count_regular_next
INY
murder_count_regular_next:
TXA
CLC
ADC #$10
TAX
BNE murder_regular_count
CPY #$04
BCC murder_spawn_count_ready
RTS
murder_spawn_count_ready:
LDA #$01
STA $0673
STA $61
JSR random
AND #$01
BEQ murder_spawn_horizontal_wall
LDA $11
CMP #$7C
BCC murder_spawn_right
LDA #$00
JMP murder_spawn_x_wall
murder_spawn_right:
LDA #$F0
murder_spawn_x_wall:
STA $62
murder_spawn_random_y:
JSR random
CMP #$E1
BCS murder_spawn_random_y
STA $63
JMP murder_spawn_position_ready
murder_spawn_horizontal_wall:
LDA $13
CMP #$74
BCC murder_spawn_bottom
LDA #$00
JMP murder_spawn_y_wall
murder_spawn_bottom:
LDA #$E0
murder_spawn_y_wall:
STA $63
murder_spawn_random_x:
JSR random
CMP #$F1
BCS murder_spawn_random_x
STA $62
murder_spawn_position_ready:
LDA #$00
STA $65
LDX #$00
JSR murder_make_child
STX $60
JSR murder_aim
LDX $60
STA $0689,X
JSR murder_velocity
murder_spawn_return:
RTS
murder_tick:
LDA $06
BNE murder_tick_game
RTS
murder_tick_game:
LDX #$00
murder_tick_loop:
LDA $0688,X
BNE murder_tick_active
JMP murder_tick_next
murder_tick_active:
LDA $068A,X
BEQ murder_grace_done
DEC $068A,X
murder_grace_done:
DEC $068B,X
BNE murder_move
LDA #$04
STA $068B,X
STX $60
JSR murder_aim
LDX $60
SEC
SBC $0689,X
BCS murder_turn_delta
CLC
ADC #$30
murder_turn_delta:
BEQ murder_move
CMP #$18
BCS murder_turn_left
INC $0689,X
LDA $0689,X
CMP #$30
BCC murder_turn_ready
LDA #$00
STA $0689,X
JMP murder_turn_ready
murder_turn_left:
LDA $0689,X
BNE murder_turn_decrement
LDA #$30
STA $0689,X
murder_turn_decrement:
DEC $0689,X
murder_turn_ready:
JSR murder_velocity
murder_move:
CLC
LDA $0680,X
ADC $0684,X
STA $0680,X
LDA $0681,X
ADC $0685,X
STA $0681,X
CLC
LDA $0682,X
ADC $0686,X
STA $0682,X
LDA $0683,X
ADC $0687,X
CMP #$F0
BCC murder_y_ready
LDY $0687,X
BMI murder_y_negative
SEC
SBC #$F0
JMP murder_y_ready
murder_y_negative:
CLC
ADC #$F0
murder_y_ready:
STA $0683,X
murder_tick_next:
TXA
CLC
ADC #$10
TAX
CPX #$60
BEQ murder_tick_done
JMP murder_tick_loop
murder_tick_done:
RTS
murder_make_child:
LDA #$00
STA $0680,X
STA $0682,X
LDA $62
STA $0681,X
LDA $63
STA $0683,X
LDA $61
STA $0688,X
LDA $65
JSR normalize_heading
STA $0689,X
LDA #$03
STA $068A,X
LDA #$04
STA $068B,X
JSR murder_velocity
RTS
murder_collisions:
LDA $06
BNE murder_collision_game
RTS
murder_collision_game:
LDX #$00
murder_bullet_loop:
STX $22
LDA $0600,X
BEQ murder_next_bullet
LDA $0609,X
BNE murder_next_bullet
LDA $0602,X
STA $23
LDA $0604,X
STA $24
LDX #$00
murder_collision_loop:
LDA $0688,X
BEQ murder_next_record
LDA $068A,X
BNE murder_next_record
LDY $0688,X
LDA murder_width,Y
STA $68
LDA $23
SEC
SBC $0681,X
CMP $68
BCC murder_hit_x
CMP #$FD
BCC murder_next_record
murder_hit_x:
LDA $24
SEC
SBC $0683,X
BCS murder_hit_y_positive
CLC
ADC #$F0
murder_hit_y_positive:
CMP $68
BCC murder_hit
CMP #$ED
BCC murder_next_record
murder_hit:
JSR collision_explode
JSR murder_destroy
JMP murder_next_bullet
murder_next_record:
TXA
CLC
ADC #$10
TAX
CPX #$60
BNE murder_collision_loop
murder_next_bullet:
LDX $22
TXA
CLC
ADC #$10
TAX
CPX #$40
BEQ murder_collisions_done
JMP murder_bullet_loop
murder_collisions_done:
RTS
murder_destroy:
STX $60
LDA $0681,X
STA $62
LDA $0683,X
STA $63
LDA $0689,X
SEC
SBC #$08
JSR normalize_heading
STA $65
LDA $0688,X
STA $61
LDA #$00
STA $0688,X
LDA $61
JSR sfx_asteroid_start25
LDA $61
CMP #$01
BEQ murder_destroy_large
CMP #$02
BEQ murder_destroy_medium
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
RTS
murder_destroy_large:
LDA #$64
JSR score_add
LDA #$02
STA $61
LDA #$03
STA $64
LDA #$20
STA $66
JMP murder_split_loop
murder_destroy_medium:
LDA #$C8
JSR score_add
LDA #$03
STA $61
LDA #$02
STA $64
LDA #$10
STA $66
murder_split_loop:
LDX $60
JSR murder_make_child
LDA $60
CLC
ADC $66
STA $60
LDA $65
CLC
ADC #$10
JSR normalize_heading
STA $65
DEC $64
BNE murder_split_loop
RTS
render_murder:
LDY #$08
LDA ($43),Y
CMP #$03
BEQ render_murder_small
LDA $4E
CMP #$04
BCS render_murder_big_ready
RTS
render_murder_big_ready:
LDA ($43),Y
CMP #$01
BEQ render_murder_large
LDA #$39
JMP render_murder_big
render_murder_large:
LDA #$3D
render_murder_big:
STA $4D
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
STA $50
JSR render_murder_tile
INC $4D
LDA $4F
CLC
ADC #$08
STA $4F
JSR render_murder_tile
INC $4D
LDA $4F
SEC
SBC #$08
STA $4F
LDA $50
CLC
ADC #$08
CMP #$F0
BCC render_murder_bottom
SEC
SBC #$F0
render_murder_bottom:
STA $50
JSR render_murder_tile
INC $4D
LDA $4F
CLC
ADC #$08
STA $4F
JSR render_murder_tile
RTS
render_murder_small:
LDA $4E
BNE render_murder_small_fits
RTS
render_murder_small_fits:
LDA #$38
STA $4D
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
STA $50
render_murder_tile:
LDA $0679
BEQ render_depart_visible21
LDY #$01
LDA $4F
CMP ($43),Y
BCS render_depart_visible21
RTS
render_depart_visible21:
LDY $4C
LDA $50
SEC
SBC #$01
STA $0200,Y
LDA $4D
STA $0201,Y
LDA #$02
STA $0202,Y
LDA $4F
STA $0203,Y
TYA
CLC
ADC #$04
STA $4C
DEC $4E
RTS
murder_aim:
LDA #$00
STA $54
STA $55
LDA $11
SEC
SBC $0681,X
BPL murder_dx_positive
INC $54
EOR #$FF
CLC
ADC #$01
murder_dx_positive:
STA $52
LDA $13
SEC
SBC $0683,X
BCS murder_dy_wrapped
CLC
ADC #$F0
murder_dy_wrapped:
CMP #$78
BCC murder_dy_positive
SEC
SBC #$F0
BPL murder_dy_positive
INC $55
EOR #$FF
CLC
ADC #$01
murder_dy_positive:
STA $53
murder_aim_scale:
LDA $52
ORA $53
CMP #$10
BCC murder_aim_lookup
LSR $52
LSR $53
JMP murder_aim_scale
murder_aim_lookup:
LDA $53
ASL A
ASL A
ASL A
ASL A
ORA $52
TAX
LDA ufo_aim,X
LDX $55
BEQ murder_aim_x_sign
STA $52
LDA #$18
SEC
SBC $52
murder_aim_x_sign:
LDX $54
BEQ murder_aim_normalize
STA $52
LDA #$30
SEC
SBC $52
murder_aim_normalize:
JMP normalize_heading
murder_velocity:
LDY $0689,X
LDA $0688,X
CMP #$01
BEQ murder_vel_l
CMP #$02
BEQ murder_vel_m
JMP murder_vel_s
murder_vel_l:
LDA murder_lxlo,Y
STA $0684,X
LDA murder_lxhi,Y
STA $0685,X
LDA murder_lylo,Y
STA $0686,X
LDA murder_lyhi,Y
STA $0687,X
RTS
murder_vel_m:
LDA murder_mxlo,Y
STA $0684,X
LDA murder_mxhi,Y
STA $0685,X
LDA murder_mylo,Y
STA $0686,X
LDA murder_myhi,Y
STA $0687,X
RTS
murder_vel_s:
LDA murder_sxlo,Y
STA $0684,X
LDA murder_sxhi,Y
STA $0685,X
LDA murder_sylo,Y
STA $0686,X
LDA murder_syhi,Y
STA $0687,X
RTS
wave_tick:
LDA #$01
STA $80
JSR murder_count
BEQ murder_wave_clear
JMP wave_cancel
murder_wave_clear:
LDA $06
BEQ wave_return
LDX #$00
wave_scan:
LDA $0308,X
ORA $0408,X
ORA $0508,X
BNE wave_cancel
TXA
CLC
ADC #$10
TAX
BNE wave_scan
LDA #$00
STA $80
LDA $41
BNE wave_cancel
LDA $40
BNE wave_countdown
LDA #$F0
STA $40
RTS
wave_countdown:
DEC $40
BNE wave_return
JSR next_wave
RTS
wave_cancel:
LDA #$00
STA $40
wave_return:
RTS
next_wave:
JSR murder_init
JSR pickup_reset_counter
JSR ufo_wave_reset
LDA $3F
CMP #$0C
BCS wave_count_capped
INC $3F
wave_count_capped:
LDA #$00
STA $03
STA $04
STA $05
STA $08
STA $39
STA $40
LDX #$07
wave_reset_ship:
STA $10,X
DEX
BPL wave_reset_ship
LDX #$3F
wave_clear_projectiles:
STA $0600,X
DEX
BPL wave_clear_projectiles
LDA #$80
STA $11
LDA #$78
STA $13
LDA #$05
STA $07
JSR set_game_rocks
RTS
set_game_rocks:
LDA #$01
STA $80
LDA #$00
STA $067F
LDA $3F
BNE set_game_count_ready
LDA #$04
STA $3F
set_game_count_ready:
LDA $3F
ASL A
STA $7F
LDA #$00
STA $7E
STA $7C
LDA #$30
STA $81
LDA $3F
ASL A
ASL A
ASL A
ASL A
STA $2C
LDA #$00
LDX #$00
set_game_clear_records:
STA $0300,X
STA $0400,X
STA $0500,X
INX
BNE set_game_clear_records
LDX #$00
set_game_rock_loop:
JSR random
AND #$03
BEQ spawn_left
CMP #$01
BEQ spawn_right
CMP #$02
BEQ spawn_top
spawn_bottom:
JSR random
AND #$DF
CLC
ADC #$10
STA $0301,X
LDA #$E0
STA $0303,X
LDA #$00
JMP spawn_large_heading
spawn_top:
JSR random
AND #$DF
CLC
ADC #$10
STA $0301,X
LDA #$20
STA $0303,X
LDA #$18
JMP spawn_large_heading
spawn_left:
LDA #$00
STA $0301,X
JSR random
AND #$BF
CLC
ADC #$20
STA $0303,X
LDA #$0C
JMP spawn_large_heading
spawn_right:
LDA #$F0
STA $0301,X
JSR random
AND #$BF
CLC
ADC #$20
STA $0303,X
LDA #$24
spawn_large_heading:
STA $28
JSR random_13
CLC
ADC $28
SEC
SBC #$06
JSR normalize_heading
STA $27
LDY #$08
LDA #$01
STA $0308,X
LDY #$0A
LDA #$00
STA $030A,X
LDA $27
JSR large_velocity_page0
TXA
CLC
ADC #$10
TAX
CPX $2C
BEQ set_game_rocks_done
JMP set_game_rock_loop
set_game_rocks_done:
RTS
render:
LDX #$00
LDA #$F8
hide:
STA $0200,X
INX
BNE hide
LDA $06
BNE render_game
JMP render_title
render_game:
LDA $0677
CMP #$03
BNE render_world23
RTS
render_world23:
LDA $0677
BEQ render_alive21
JMP render_player_bullets21
render_alive21:
LDA $13
SEC
SBC #$01
STA $0200
LDX $03
LDA drawing,X
STA $0201
LDA $08
BEQ ship_normal_palette
LSR A
LSR A
AND #$03
JMP ship_palette_done
ship_normal_palette:
LDA #$00
ship_palette_done:
STA $0202
LDA $11
STA $0203
render_player_bullets21:
LDX #$00
LDY #$04
render_bullet:
LDA $0600,X
BEQ hide_bullet
LDA $0609,X
BEQ render_normal_bullet
STX $20
LDA $0600,X
SEC
SBC #$01
TAX
LDA explosion_drawing,X
LDX $20
JMP render_bullet_tile_ready
render_normal_bullet:
LDA #$11
render_bullet_tile_ready:
STA $0201,Y
LDA $0604,X
SEC
SBC #$01
STA $0200,Y
LDA #$00
STA $0202,Y
LDA $0602,X
STA $0203,Y
JMP advance_bullet_oam
hide_bullet:
LDA #$F8
STA $0200,Y
advance_bullet_oam:
INY
INY
INY
INY
render_next:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE render_bullet
LDA $067D
BEQ render_burst_done22a
JSR render_death_burst22
render_burst_done22a:
JSR render_ufo
JSR render_asteroids
RTS
render_asteroids:
LDA #$2C
STA $4C
LDA #$35
STA $4E
LDA #$46
STA $51
LDA $42
STA $4B
CLC
ADC #$09
CMP #$46
BCC rotation_ready
SEC
SBC #$46
rotation_ready:
STA $42
render_pool_loop:
LDX $4B
LDA render_record_low,X
STA $43
LDA render_record_high,X
STA $44
LDY #$08
LDA ($43),Y
BNE render_pool_active
JMP render_pool_next
render_pool_active:
LDA $44
CMP #$06
BNE render_not_murder
JSR render_murder
JMP render_pool_next
render_not_murder:
LDA $44
CMP #$07
BNE render_regular_rock
JSR render_pickup
JMP render_pool_next
render_regular_rock:
LDA ($43),Y
CMP #$03
BEQ render_pool_small
LDA $4E
CMP #$04
BCS render_pool_big_fits
JMP render_pool_next
render_pool_big_fits:
LDA ($43),Y
CMP #$01
BEQ render_pool_large
LDA #$17
JMP render_pool_big
render_pool_large:
LDA #$13
render_pool_big:
STA $4D
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
STA $50
JSR render_pool_tile
INC $4D
LDA $4F
CLC
ADC #$08
STA $4F
JSR render_pool_tile
INC $4D
LDA $4F
SEC
SBC #$08
STA $4F
LDA $50
CLC
ADC #$08
CMP #$F0
BCC render_pool_bottom_ready
SEC
SBC #$F0
render_pool_bottom_ready:
STA $50
JSR render_pool_tile
INC $4D
LDA $4F
CLC
ADC #$08
STA $4F
JSR render_pool_tile
JMP render_pool_next
render_pool_small:
LDA $4E
BEQ render_pool_next
LDA #$12
STA $4D
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
STA $50
JSR render_pool_tile
render_pool_next:
INC $4B
LDA $4B
CMP #$46
BCC render_pool_no_wrap
LDA #$00
STA $4B
render_pool_no_wrap:
DEC $51
BEQ render_pool_done
JMP render_pool_loop
render_pool_done:
RTS
render_pool_tile:
LDY $4C
LDA $50
SEC
SBC #$01
STA $0200,Y
LDA $4D
STA $0201,Y
LDA #$01
STA $0202,Y
LDA $4F
STA $0203,Y
TYA
CLC
ADC #$04
STA $4C
DEC $4E
RTS
render_title:
LDX #$00
LDY #$00
render_title_asteroid:
LDA $0303,X
SEC
SBC #$01
STA $0200,Y
LDA #$12
STA $0201,Y
LDA #$01
STA $0202,Y
LDA $0301,X
STA $0203,Y
INY
INY
INY
INY
TXA
CLC
ADC #$10
TAX
CPX #$80
BNE render_title_asteroid
RTS

ufo_xlo:
.byte $00,$54,$A6,$F5,$40,$86,$C5,$FC,$2A,$4F,$6A,$7B,$80,$7B,$6A,$4F,$2A,$FC,$C5,$86,$40,$F5,$A6,$54,$00,$AC,$5A,$0B,$C0,$7A,$3B,$04,$D6,$B1,$96,$85,$80,$85,$96,$B1,$D6,$04,$3B,$7A,$C0,$0B,$5A,$AC
ufo_xhi:
.byte $00,$00,$00,$00,$01,$01,$01,$01,$02,$02,$02,$02,$02,$02,$02,$02,$02,$01,$01,$01,$01,$00,$00,$00,$00,$FF,$FF,$FF,$FE,$FE,$FE,$FE,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FE,$FE,$FE,$FE,$FF,$FF,$FF
ufo_ylo:
.byte $80,$85,$96,$B1,$D6,$04,$3B,$7A,$C0,$0B,$5A,$AC,$00,$54,$A6,$F5,$40,$86,$C5,$FC,$2A,$4F,$6A,$7B,$80,$7B,$6A,$4F,$2A,$FC,$C5,$86,$40,$F5,$A6,$54,$00,$AC,$5A,$0B,$C0,$7A,$3B,$04,$D6,$B1,$96,$85
ufo_yhi:
.byte $FD,$FD,$FD,$FD,$FD,$FE,$FE,$FE,$FE,$FF,$FF,$FF,$00,$00,$00,$00,$01,$01,$01,$01,$02,$02,$02,$02,$02,$02,$02,$02,$02,$01,$01,$01,$01,$00,$00,$00,$00,$FF,$FF,$FF,$FE,$FE,$FE,$FE,$FD,$FD,$FD,$FD
ufo_aim:
.byte $00,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$18,$12,$10,$0E,$0E,$0E,$0D,$0D,$0D,$0D,$0D,$0D,$0D,$0D,$0D,$0D,$18,$14,$12,$10,$10,$0F,$0E,$0E,$0E,$0E,$0E,$0D,$0D,$0D,$0D,$0D,$18,$16,$14,$12,$11,$10,$10,$0F,$0F,$0E,$0E,$0E,$0E,$0E,$0E,$0E,$18,$16,$14,$13,$12,$11,$10,$10,$10,$0F,$0F,$0F,$0E,$0E,$0E,$0E,$18,$16,$15,$14,$13,$12,$11,$11,$10,$10,$10,$0F,$0F,$0F,$0F,$0E,$18,$17,$16,$14,$14,$13,$12,$11,$11,$10,$10,$10,$10,$0F,$0F,$0F,$18,$17,$16,$15,$14,$13,$13,$12,$11,$11,$11,$10,$10,$10,$10,$0F,$18,$17,$16,$15,$14,$14,$13,$13,$12,$12,$11,$11,$10,$10,$10,$10,$18,$17,$16,$16,$15,$14,$14,$13,$12,$12,$12,$11,$11,$11,$10,$10,$18,$17,$16,$16,$15,$14,$14,$13,$13,$12,$12,$12,$11,$11,$11,$10,$18,$17,$17,$16,$15,$15,$14,$14,$13,$13,$12,$12,$12,$11,$11,$11,$18,$17,$17,$16,$16,$15,$14,$14,$14,$13,$13,$12,$12,$12,$11,$11,$18,$17,$17,$16,$16,$15,$15,$14,$14,$13,$13,$13,$12,$12,$12,$11,$18,$17,$17,$16,$16,$15,$15,$14,$14,$14,$13,$13,$13,$12,$12,$12,$18,$17,$17,$16,$16,$16,$15,$15,$14,$14,$14,$13,$13,$13,$12,$12
ufo_small_chance:
.byte $00,$18,$30,$48,$60,$78,$90,$A8,$C0
render_record_low:
.byte $00,$10,$20,$30,$40,$50,$60,$70,$80,$90,$A0,$B0,$C0,$D0,$E0,$F0,$00,$10,$20,$30,$40,$50,$60,$70,$80,$90,$A0,$B0,$C0,$D0,$E0,$F0,$00,$10,$20,$30,$40,$50,$60,$70,$80,$90,$A0,$B0,$C0,$D0,$E0,$F0,$00,$10,$20,$30,$40,$50,$60,$70,$80,$90,$A0,$B0,$C0,$D0,$E0,$F0,$80,$90,$A0,$B0,$C0,$D0
render_record_high:
.byte $03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$07,$06,$06,$06,$06,$06,$06
palette:
.byte $0F,$30,$0F,$0F,$0F,$16,$28,$08,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$30,$24,$16,$0F,$37,$27,$17,$0F,$30,$12,$2A,$0F,$30,$16,$2A
drawing:
.byte $01,$01,$02,$02,$02,$03,$03,$03,$04,$04,$04,$05,$05,$05,$06,$06,$06,$07,$07,$07,$08,$08,$08,$09,$09,$09,$0A,$0A,$0A,$0B,$0B,$0B,$0C,$0C,$0C,$0D,$0D,$0D,$0E,$0E,$0E,$0F,$0F,$0F,$10,$10,$10,$01
pickup_order:
.byte $01,$02,$01,$03,$01,$02,$01,$04,$05,$06,$02,$0A,$03,$02,$04,$07,$02,$03,$06,$04,$07,$04,$08,$09
pickup_tiles:
.byte $00,$26,$28,$2A,$2C,$2E,$30,$32,$34,$36,$41
pickup_palettes:
.byte $00,$01,$01,$00,$00,$01,$02,$02,$02,$02,$00
pickup_score_chunks:
.byte $00,$01,$02,$03,$04,$00,$00,$08,$0C,$14,$04
pickup_xlo:
.byte $00,$05,$0A,$0F,$13,$17,$1B,$1E,$21,$23,$25,$26,$26,$26,$25,$23,$21,$1E,$1B,$17,$13,$0F,$0A,$05,$00,$FB,$F6,$F1,$ED,$E9,$E5,$E2,$DF,$DD,$DB,$DA,$DA,$DA,$DB,$DD,$DF,$E2,$E5,$E9,$ED,$F1,$F6,$FB
pickup_xhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
boost_xlo:
.byte $00,$19,$32,$49,$60,$75,$88,$98,$A6,$B1,$B9,$BE,$C0,$BE,$B9,$B1,$A6,$98,$88,$75,$60,$49,$32,$19,$00,$E7,$CE,$B7,$A0,$8B,$78,$68,$5A,$4F,$47,$42,$40,$42,$47,$4F,$5A,$68,$78,$8B,$A0,$B7,$CE,$E7
boost_xhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
pickup_ylo:
.byte $DA,$DA,$DB,$DD,$DF,$E2,$E5,$E9,$ED,$F1,$F6,$FB,$00,$05,$0A,$0F,$13,$17,$1B,$1E,$21,$23,$25,$26,$26,$26,$25,$23,$21,$1E,$1B,$17,$13,$0F,$0A,$05,$00,$FB,$F6,$F1,$ED,$E9,$E5,$E2,$DF,$DD,$DB,$DA
pickup_yhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
boost_ylo:
.byte $40,$42,$47,$4F,$5A,$68,$78,$8B,$A0,$B7,$CE,$E7,$00,$19,$32,$49,$60,$75,$88,$98,$A6,$B1,$B9,$BE,$C0,$BE,$B9,$B1,$A6,$98,$88,$75,$60,$49,$32,$19,$00,$E7,$CE,$B7,$A0,$8B,$78,$68,$5A,$4F,$47,$42
boost_yhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
rainbow_offsets:
.byte $06,$02,$2E,$2A
small_child_low:
.byte $00,$00,$00,$00,$C0,$E0,$00,$20,$40,$60,$80,$A0,$00,$00,$00,$00
small_child_page:
.byte $00,$00,$00,$00,$03,$03,$04,$04,$04,$04,$04,$04,$00,$00,$00,$00
explosion_drawing:
.byte $1F,$1F,$1F,$1E,$1E,$1E,$1D,$1D,$1D,$1C,$1C,$1C,$1B,$1B,$1B
title_nt0:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$01,$02,$03,$04,$11,$12,$13,$14,$21,$22,$23,$24,$31,$32,$33,$34,$41,$42,$43,$44,$51,$52,$53,$54,$00,$00,$00,$00,$00,$00,$00,$00,$05,$06,$07,$08,$15,$16,$17,$18,$25,$26,$27,$28,$35,$36,$37,$38,$45,$46,$47,$48,$55,$56,$57,$58,$00,$00,$00,$00,$00,$00,$00,$00,$09,$0A,$0B,$0C,$19,$1A,$1B,$1C,$29,$2A,$2B,$2C,$39,$3A,$3B,$3C,$49,$4A,$4B,$4C,$59,$5A,$5B,$5C,$00,$00,$00,$00
title_nt1:
.byte $00,$00,$00,$00,$0D,$0E,$0F,$10,$1D,$1E,$1F,$20,$2D,$2E,$2F,$30,$3D,$3E,$3F,$40,$4D,$4E,$4F,$50,$5D,$5E,$5F,$60,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$70,$72,$65,$73,$73,$00,$73,$65,$6C,$65,$63,$74,$00,$74,$6F,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$63,$68,$6F,$6F,$73,$65,$00,$67,$61,$6D,$65,$00,$6D,$6F,$64,$65,$8A,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$61,$72,$63,$61,$64,$65,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
title_nt2:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$70,$72,$65,$73,$73,$00,$73,$74,$61,$72,$74,$00,$74,$6F,$00,$62,$65,$67,$69,$6E,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
title_nt3:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$89,$7D,$7B,$7D,$81,$00,$61,$6E,$74,$68,$6F,$6E,$79,$00,$76,$6F,$6C,$70,$65,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$55,$55,$55,$55,$55,$55,$00,$00,$05,$05,$05,$05,$05,$05,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
hud_line:
.byte $73,$63,$6F,$72,$65,$8A,$7B,$7B,$7B,$7B,$7B,$7B,$00,$00,$00,$73,$75,$70,$65,$72,$8A,$80,$00,$00,$00,$6C,$69,$76,$65,$73,$8A,$7E
asteroid_init0:
.byte $00,$0F,$00,$0E,$00,$00,$80,$FF,$01,$00,$00,$00,$00,$00,$00,$00,$00,$E1,$00,$18,$00,$00,$80,$FF,$01,$00,$00,$00,$00,$00,$00,$00,$00,$0A,$00,$69,$00,$00,$80,$FF,$01,$00,$00,$00,$00,$00,$00,$00,$00,$F0,$00,$7D,$31,$00,$8A,$FF,$01,$00,$00,$00,$00,$00,$00,$00,$00,$19,$00,$CD,$31,$00,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$DC,$00,$D2,$31,$00,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$4C,$00,$B8,$5B,$00,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$AF,$00,$AE,$5B,$00,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$5B,$00,$93,$5B,$00,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$A4,$00,$C2,$76,$00,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$ED,$00,$01,$76,$00,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$36,$00,$30,$76,$00,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7F,$00,$5F,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C8,$00,$8E,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$11,$00,$BD,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$5A,$00,$EC,$76,$00,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00
asteroid_init1:
.byte $00,$A3,$00,$2B,$76,$00,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$EC,$00,$5A,$76,$00,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$35,$00,$89,$5B,$00,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7E,$00,$B8,$5B,$00,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C7,$00,$E7,$5B,$00,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$10,$00,$26,$31,$00,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$59,$00,$55,$31,$00,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$A2,$00,$84,$31,$00,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$EB,$00,$B3,$00,$00,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$34,$00,$E2,$00,$00,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7D,$00,$21,$00,$00,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C6,$00,$50,$CF,$FF,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0F,$00,$7F,$CF,$FF,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$58,$00,$AE,$CF,$FF,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$A1,$00,$DD,$A5,$FF,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$EA,$00,$1C,$A5,$FF,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$33,$00,$4B,$A5,$FF,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7C,$00,$7A,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C5,$00,$A9,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0E,$00,$D8,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$57,$00,$17,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$A0,$00,$46,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$E9,$00,$75,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$32,$00,$A4,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7B,$00,$D3,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C4,$00,$12,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0D,$00,$41,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$56,$00,$70,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$9F,$00,$9F,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$E8,$00,$CE,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$31,$00,$0D,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7A,$00,$3C,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00
asteroid_init2:
.byte $00,$33,$00,$4B,$A5,$FF,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7C,$00,$7A,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C5,$00,$A9,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0E,$00,$D8,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$57,$00,$17,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$A0,$00,$46,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$E9,$00,$75,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$32,$00,$A4,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7B,$00,$D3,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C4,$00,$12,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0D,$00,$41,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$56,$00,$70,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$9F,$00,$9F,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$E8,$00,$CE,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$31,$00,$0D,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7A,$00,$3C,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00
axlo:
.byte $00,$02,$03,$05,$06,$07,$08,$0A,$0A,$0B,$0C,$0C,$0C,$0C,$0C,$0B,$0A,$0A,$08,$07,$06,$05,$03,$02,$00,$FE,$FD,$FB,$FA,$F9,$F8,$F6,$F6,$F5,$F4,$F4,$F4,$F4,$F4,$F5,$F6,$F6,$F8,$F9,$FA,$FB,$FD,$FE
axhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
aylo:
.byte $F4,$F4,$F4,$F5,$F6,$F6,$F8,$F9,$FA,$FB,$FD,$FE,$00,$02,$03,$05,$06,$07,$08,$0A,$0A,$0B,$0C,$0C,$0C,$0C,$0C,$0B,$0A,$0A,$08,$07,$06,$05,$03,$02,$00,$FE,$FD,$FB,$FA,$F9,$F8,$F6,$F6,$F5,$F4,$F4
ayhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
bxlo:
.byte $00,$64,$C7,$26,$80,$D4,$1F,$61,$99,$C6,$E6,$F9,$00,$F9,$E6,$C6,$99,$61,$1F,$D4,$80,$26,$C7,$64,$00,$9C,$39,$DA,$80,$2C,$E1,$9F,$67,$3A,$1A,$07,$00,$07,$1A,$3A,$67,$9F,$E1,$2C,$80,$DA,$39,$9C
bxhi:
.byte $00,$00,$00,$01,$01,$01,$02,$02,$02,$02,$02,$02,$03,$02,$02,$02,$02,$02,$02,$01,$01,$01,$00,$00,$00,$FF,$FF,$FE,$FE,$FE,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FE,$FE,$FE,$FF,$FF
bylo:
.byte $00,$07,$1A,$3A,$67,$9F,$E1,$2C,$80,$DA,$39,$9C,$00,$64,$C7,$26,$80,$D4,$1F,$61,$99,$C6,$E6,$F9,$00,$F9,$E6,$C6,$99,$61,$1F,$D4,$80,$26,$C7,$64,$00,$9C,$39,$DA,$80,$2C,$E1,$9F,$67,$3A,$1A,$07
byhi:
.byte $FD,$FD,$FD,$FD,$FD,$FD,$FD,$FE,$FE,$FE,$FF,$FF,$00,$00,$00,$01,$01,$01,$02,$02,$02,$02,$02,$02,$03,$02,$02,$02,$02,$02,$02,$01,$01,$01,$00,$00,$00,$FF,$FF,$FE,$FE,$FE,$FD,$FD,$FD,$FD,$FD,$FD
lxlo:
.byte $00,$11,$21,$31,$40,$4E,$5B,$66,$6F,$76,$7C,$7F,$80,$7F,$7C,$76,$6F,$66,$5B,$4E,$40,$31,$21,$11,$00,$EF,$DF,$CF,$C0,$B2,$A5,$9A,$91,$8A,$84,$81,$80,$81,$84,$8A,$91,$9A,$A5,$B2,$C0,$CF,$DF,$EF
lxhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
lylo:
.byte $80,$81,$84,$8A,$91,$9A,$A5,$B2,$C0,$CF,$DF,$EF,$00,$11,$21,$31,$40,$4E,$5B,$66,$6F,$76,$7C,$7F,$80,$7F,$7C,$76,$6F,$66,$5B,$4E,$40,$31,$21,$11,$00,$EF,$DF,$CF,$C0,$B2,$A5,$9A,$91,$8A,$84,$81
lyhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
mxlo:
.byte $00,$15,$29,$3D,$50,$61,$71,$7F,$8B,$94,$9B,$9F,$A0,$9F,$9B,$94,$8B,$7F,$71,$61,$50,$3D,$29,$15,$00,$EB,$D7,$C3,$B0,$9F,$8F,$81,$75,$6C,$65,$61,$60,$61,$65,$6C,$75,$81,$8F,$9F,$B0,$C3,$D7,$EB
mxhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
mylo:
.byte $60,$61,$65,$6C,$75,$81,$8F,$9F,$B0,$C3,$D7,$EB,$00,$15,$29,$3D,$50,$61,$71,$7F,$8B,$94,$9B,$9F,$A0,$9F,$9B,$94,$8B,$7F,$71,$61,$50,$3D,$29,$15,$00,$EB,$D7,$C3,$B0,$9F,$8F,$81,$75,$6C,$65,$61
myhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
sxlo:
.byte $00,$19,$32,$49,$60,$75,$88,$98,$A6,$B1,$B9,$BE,$C0,$BE,$B9,$B1,$A6,$98,$88,$75,$60,$49,$32,$19,$00,$E7,$CE,$B7,$A0,$8B,$78,$68,$5A,$4F,$47,$42,$40,$42,$47,$4F,$5A,$68,$78,$8B,$A0,$B7,$CE,$E7
sxhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
sylo:
.byte $40,$42,$47,$4F,$5A,$68,$78,$8B,$A0,$B7,$CE,$E7,$00,$19,$32,$49,$60,$75,$88,$98,$A6,$B1,$B9,$BE,$C0,$BE,$B9,$B1,$A6,$98,$88,$75,$60,$49,$32,$19,$00,$E7,$CE,$B7,$A0,$8B,$78,$68,$5A,$4F,$47,$42
syhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
spawnxoff:
.byte $00,$01,$02,$03,$04,$05,$06,$06,$07,$07,$08,$08,$08,$08,$08,$07,$07,$06,$06,$05,$04,$03,$02,$01,$00,$FF,$FE,$FD,$FC,$FB,$FA,$FA,$F9,$F9,$F8,$F8,$F8,$F8,$F8,$F9,$F9,$FA,$FA,$FB,$FC,$FD,$FE,$FF
spawnyoff:
.byte $F8,$F8,$F8,$F9,$F9,$FA,$FA,$FB,$FC,$FD,$FE,$FF,$00,$01,$02,$03,$04,$05,$06,$06,$07,$07,$08,$08,$08,$08,$08,$07,$07,$06,$06,$05,$04,$03,$02,$01,$00,$FF,$FE,$FD,$FC,$FB,$FA,$FA,$F9,$F9,$F8,$F8
murder_width:
.byte $00,$10,$0C,$08
murder_lxlo:
.byte $00,$11,$21,$31,$40,$4E,$5B,$66,$6F,$76,$7C,$7F,$80,$7F,$7C,$76,$6F,$66,$5B,$4E,$40,$31,$21,$11,$00,$EF,$DF,$CF,$C0,$B2,$A5,$9A,$91,$8A,$84,$81,$80,$81,$84,$8A,$91,$9A,$A5,$B2,$C0,$CF,$DF,$EF
murder_lxhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
murder_lylo:
.byte $80,$81,$84,$8A,$91,$9A,$A5,$B2,$C0,$CF,$DF,$EF,$00,$11,$21,$31,$40,$4E,$5B,$66,$6F,$76,$7C,$7F,$80,$7F,$7C,$76,$6F,$66,$5B,$4E,$40,$31,$21,$11,$00,$EF,$DF,$CF,$C0,$B2,$A5,$9A,$91,$8A,$84,$81
murder_lyhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
murder_mxlo:
.byte $00,$1F,$3E,$5C,$78,$92,$AA,$BE,$D0,$DE,$E8,$EE,$F0,$EE,$E8,$DE,$D0,$BE,$AA,$92,$78,$5C,$3E,$1F,$00,$E1,$C2,$A4,$88,$6E,$56,$42,$30,$22,$18,$12,$10,$12,$18,$22,$30,$42,$56,$6E,$88,$A4,$C2,$E1
murder_mxhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
murder_mylo:
.byte $10,$12,$18,$22,$30,$42,$56,$6E,$88,$A4,$C2,$E1,$00,$1F,$3E,$5C,$78,$92,$AA,$BE,$D0,$DE,$E8,$EE,$F0,$EE,$E8,$DE,$D0,$BE,$AA,$92,$78,$5C,$3E,$1F,$00,$E1,$C2,$A4,$88,$6E,$56,$42,$30,$22,$18,$12
murder_myhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
murder_sxlo:
.byte $00,$32,$63,$93,$C0,$EA,$10,$31,$4D,$63,$73,$7D,$80,$7D,$73,$63,$4D,$31,$10,$EA,$C0,$93,$63,$32,$00,$CE,$9D,$6D,$40,$16,$F0,$CF,$B3,$9D,$8D,$83,$80,$83,$8D,$9D,$B3,$CF,$F0,$16,$40,$6D,$9D,$CE
murder_sxhi:
.byte $00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FE,$FE,$FE,$FE,$FE,$FE,$FE,$FE,$FE,$FE,$FE,$FE,$FE,$FF,$FF,$FF,$FF,$FF
murder_sylo:
.byte $80,$83,$8D,$9D,$B3,$CF,$F0,$16,$40,$6D,$9D,$CE,$00,$32,$63,$93,$C0,$EA,$10,$31,$4D,$63,$73,$7D,$80,$7D,$73,$63,$4D,$31,$10,$EA,$C0,$93,$63,$32,$00,$CE,$9D,$6D,$40,$16,$F0,$CF,$B3,$9D,$8D,$83
murder_syhi:
.byte $FE,$FE,$FE,$FE,$FE,$FE,$FE,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FE,$FE,$FE,$FE,$FE,$FE
magnet_bias:
.byte $0F,$13,$17,$1B
magnet_width:
.byte $1F,$27,$2F,$37
attract_xlo:
.byte $00,$80,$FE,$77,$EA,$55,$B6,$0A,$52,$8A,$B4,$CD,$D5,$CD,$B4,$8A,$52,$0A,$B6,$55,$EA,$77,$FE,$80,$00,$80,$02,$89,$16,$AB,$4A,$F6,$AE,$76,$4C,$33,$2B,$33,$4C,$76,$AE,$F6,$4A,$AB,$15,$89,$02,$80
attract_xhi:
.byte $00,$00,$00,$01,$01,$02,$02,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$02,$02,$01,$01,$00,$00,$00,$FF,$FF,$FE,$FE,$FD,$FD,$FC,$FC,$FC,$FC,$FC,$FC,$FC,$FC,$FC,$FC,$FC,$FD,$FD,$FE,$FE,$FF,$FF
attract_ylo:
.byte $2B,$33,$4C,$76,$AE,$F6,$4A,$AB,$15,$89,$02,$80,$00,$80,$FE,$77,$EA,$55,$B6,$0A,$52,$8A,$B4,$CD,$D5,$CD,$B4,$8A,$52,$0A,$B6,$55,$EB,$77,$FE,$80,$00,$80,$02,$89,$15,$AB,$4A,$F6,$AE,$76,$4C,$33
attract_yhi:
.byte $FC,$FC,$FC,$FC,$FC,$FC,$FD,$FD,$FE,$FE,$FF,$FF,$00,$00,$00,$01,$01,$02,$02,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$02,$02,$01,$01,$00,$00,$00,$FF,$FF,$FE,$FE,$FD,$FD,$FC,$FC,$FC,$FC,$FC
shot_timer25:
.byte $8E,$90,$93,$95,$98,$9A,$9D,$9F,$A2,$A4,$A7,$A9
shot_volume25:
.byte $0F,$0E,$0D,$0C,$0A,$09,$08,$06,$05,$04,$02,$00
pulse_timer24:
.byte $26,$56
pulse_high24:
.byte $03,$03
hazard_width21:
.byte $00,$10,$0C,$08
death_explosion_tile22:
.byte $1B,$1B,$1B,$1B,$1B,$1C,$1C,$1C,$1C,$1C,$1D,$1D,$1D,$1D,$1D,$1E,$1E,$1E,$1E,$1E,$1F,$1F,$1F,$1F,$1F
gameover_text22:
.byte $67,$61,$6D,$65,$00,$6F,$76,$65,$72
death_quadrants22a:
.byte $00,$0C,$18,$24
death_xlo22a:
.byte $00,$21,$42,$62,$80,$9C,$B5,$CB,$DE,$ED,$F7,$FE,$00,$FE,$F7,$ED,$DE,$CB,$B5,$9C,$80,$62,$42,$21,$00,$DF,$BE,$9E,$80,$64,$4B,$35,$22,$13,$09,$02,$00,$02,$09,$13,$22,$35,$4B,$64,$80,$9E,$BE,$DF
death_xhi22a:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$01,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
death_ylo22a:
.byte $00,$02,$09,$13,$22,$35,$4B,$64,$80,$9E,$BE,$DF,$00,$21,$42,$62,$80,$9C,$B5,$CB,$DE,$ED,$F7,$FE,$00,$FE,$F7,$ED,$DE,$CB,$B5,$9C,$80,$62,$42,$21,$00,$DF,$BE,$9E,$80,$64,$4B,$35,$22,$13,$09,$02
death_yhi22a:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$01,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
results_nt023:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$66,$69,$6E,$61,$6C,$00,$73,$63,$6F,$72,$65,$8A,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
results_nt123:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$79,$6F,$75,$72,$00,$72,$61,$6E,$6B,$8A,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
results_nt223:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$70,$72,$65,$73,$73,$00,$73,$74,$61,$72,$74,$00,$74,$6F,$00,$72,$65,$70,$6C,$61,$79,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$70,$72,$65,$73,$73,$00,$73,$65,$6C,$65,$63,$74,$00,$74,$6F,$00,$67,$6F,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$74,$6F,$00,$74,$68,$65,$00,$6D,$61,$69,$6E,$00,$6D,$65,$6E,$75,$00,$00,$00,$00,$00,$00,$00,$00
results_nt323:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_0_23:
.byte $00,$00,$00,$00,$00,$00,$67,$61,$72,$62,$61,$67,$65,$00,$73,$63,$6F,$77,$00,$63,$61,$70,$74,$61,$69,$6E,$00,$00,$00,$00,$00,$00
rank_1_23:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$67,$61,$6C,$61,$63,$74,$69,$63,$00,$63,$6F,$6F,$6B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_2_23:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$72,$6F,$6F,$6B,$69,$65,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_3_23:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$65,$6E,$73,$69,$67,$6E,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_4_23:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$70,$69,$6C,$6F,$74,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_5_23:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$61,$63,$65,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_6_23:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$6C,$69,$65,$75,$74,$65,$6E,$61,$6E,$74,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_7_23:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$77,$61,$72,$72,$69,$6F,$72,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_8_23:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$63,$61,$70,$74,$61,$69,$6E,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_9_23:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$63,$6F,$6D,$6D,$61,$6E,$64,$65,$72,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_10_23:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$73,$70,$61,$63,$65,$00,$6C,$6F,$72,$64,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
rank_limit023:
.byte $00,$C4,$88,$10,$98,$20,$30,$40,$60,$80,$A0
rank_limit123:
.byte $00,$09,$13,$27,$3A,$4E,$75,$9C,$EA,$38,$86
rank_limit223:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$01,$01