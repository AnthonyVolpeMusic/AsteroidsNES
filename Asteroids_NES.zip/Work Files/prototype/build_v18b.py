"""V18b: finalized 24-item pickup sequence and EXTRA SUPER pickup."""
from pathlib import Path
P = Path(__file__).parent

# Compose the confirmed V18a source, then alter only the generated program.
exec(compile((P/'build_v18a.py').read_text(), str(P/'build_v18a.py'), 'exec'))

# Reset the small-asteroid parity and sequence index at a new wave.  The named
# death hook is kept beside it; Player One is presently invincible, so there is
# no live death dispatcher to call it yet.
source = source.replace(
    'pickups_init:\nLDA #$00\nSTA $0670\nSTA $0671\nSTA $0672',
    'pickups_init:\nLDA #$00\nSTA $0672\nJSR pickup_reset_counter\nJMP pickups_clear_begin\npickup_reset_counter:\nLDA #$00\nSTA $0670\nSTA $0671\nRTS\npickup_player_death:\nJSR pickup_reset_counter\nRTS\npickups_clear_begin:\nLDX #$00\npickups_clear:'
).replace('pickups_clear:\nLDX #$00\npickups_clear:', 'pickups_clear:\nLDX #$00')
source = source.replace('pickups_clear_begin:\nLDX #$00\npickups_clear:\nLDX #$00\nSTA', 'pickups_clear_begin:\nLDX #$00\npickups_clear:\nSTA')
source = source.replace('next_wave:\nLDA #$00\nSTA $0670\nSTA $0671', 'next_wave:\nJSR pickup_reset_counter')

# The order has 24 entries: pickup types 1..4 score, 5 boosts shot speed,
# 6 awards SUPER, and 7..9 score 2000/3000/5000.
source = source.replace("'pickup_order': [1, 2, 1, 3, 1, 2, 1, 4, 5]", "'pickup_order': [1, 2, 1, 3, 1, 2, 1, 4, 5, 6, 1, 2, 3, 2, 4, 7, 2, 3, 6, 4, 7, 4, 8, 9]")
source = source.replace("'pickup_tiles': [0, 38, 40, 42, 44, 46]", "'pickup_tiles': [0, 38, 40, 42, 44, 46, 48, 50, 52, 54]")
source = source.replace("'pickup_palettes': [0, 1, 1, 0, 0, 1]", "'pickup_palettes': [0, 1, 1, 0, 0, 1, 2, 2, 2, 2]")
source = source.replace("'pickup_score_chunks': [0, 1, 2, 3, 4, 0]", "'pickup_score_chunks': [0, 1, 2, 3, 4, 0, 0, 8, 12, 20]")
source = source.replace('CMP #$09\nBCC pickup_order_ready', 'CMP #$18\nBCC pickup_order_ready')

# Sprite palette 2 is white $30, blue $12, green $2A.  It is only used by
# Extra SUPER and the new high-value pickups.
source = source.replace("0x0f,0x30,0x16,0x2a, 0x0f,0x30,0x16,0x2a]", "0x0f,0x30,0x12,0x2a, 0x0f,0x30,0x16,0x2a]")

# Type six is a one-point SUPER replenishment, capped at the five-point meter.
source = source.replace(
    'CPY #$05\nBNE pickup_collect_points\nLDA $0672\nCMP #$02\nBCS pickup_collect_next\nINC $0672\nJMP pickup_collect_next',
    'CPY #$05\nBEQ pickup_collect_speed\nCPY #$06\nBEQ pickup_collect_super\nJMP pickup_collect_points\npickup_collect_speed:\nLDA $0672\nCMP #$02\nBCS pickup_collect_next\nINC $0672\nJMP pickup_collect_next\npickup_collect_super:\nLDA $07\nCMP #$05\nBCS pickup_collect_next\nINC $07\nJMP pickup_collect_next'
)

new_frames = [
 # EXTRA SUPER: black transparent, white 1, blue 2, green 3.
 ['30032002','33332222','33111122','33112222','33331122','33111122','03332220','00332200'],
 ['20023003','22223333','22111133','22113333','22221133','22111133','02223330','00223300'],
 # 2000
 ['33002000','00320200','03002030','30000303','33300030','00000020','00000202','00000020'],
 ['22003000','00230300','02003020','20000202','22200020','00000030','00000303','00000030'],
 # 3000
 ['33001000','00310100','03001030','00300303','33000030','00000010','00000101','00000010'],
 ['11003000','00130300','01003010','00100101','11000010','00000030','00000303','00000030'],
 # 5000
 ['22201000','20010100','22001020','00200202','22000020','00000010','00000101','00000010'],
 ['11102000','10020200','11002010','00100101','11000010','00000020','00000202','00000020'],
]
asset_code = "\nnew_pickup_frames=" + repr(new_frames) + "\nfor i,rows in enumerate(new_pickup_frames):\n assert len(rows)==8 and all(len(row)==8 for row in rows)\n tile(0x130+i,[[int(c) for c in row] for row in rows])\n"
source = source.replace("output=P/'asteroids_nes_v18a_small_asteroid_pickups.nes'", asset_code + "\noutput=P/'asteroids_nes_v18b_finalized_pickups.nes'")
source = source.replace('prototype_v18a.asm', 'prototype_v18b.asm').replace('symbols_v18a.json', 'symbols_v18b.json')
exec(compile(source, str(P/'build_v15.py'), 'exec'))
