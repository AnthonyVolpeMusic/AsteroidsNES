# V19b — Murderoid respawn timer

Based on confirmed V19a. On level 4 onward, after the entire current Murderoid family has been destroyed, a 600-update timer starts (10 seconds at nominal 60 Hz). It starts at the end of the final-kill update; the next 600 updates count down. If any regular asteroid remains at expiry, another large Murderoid spawns using the same farthest-wall algorithm. Each subsequent destroyed family starts a fresh timer.

The first-family trigger remains three or fewer regular asteroids. Replacement families require any regular asteroid; UFOs and pickups alone never trigger replacement. Waiting for a replacement does not block the usual four-second wave-clear countdown. New-game/new-wave initialization clears the timer. Player One remains invincible.

State $0673: 0 first family pending, 1 family active, 2 timer running, 3 expired without regular asteroids. $0674/$0675: 16-bit timer, low/high bytes. No object slots or graphics added.

Build: `python prototype/build_v19b.py`

Test: `python prototype/test_v19b.py`

Tests include the existing pickup, hunter, scoring, OAM, and farthest-wall regressions, plus exact 600-update timing, multiple replacement cycles, active-family gating, remaining-asteroid checks, UFO-only exclusion, wave transition timing, and timer reset. CPU-level tests do not replace a visual emulator playtest. Start the new ROM fresh rather than loading an older build's save state.
