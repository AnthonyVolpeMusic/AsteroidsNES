"""Execute V19 6502 code: regression, lineage, gates, aiming and OAM."""
from pathlib import Path
import random, math, ast
from collections import Counter
P=Path(__file__).parent
# Run the established pickup/ship/wave suite against this ROM.
base=(P/'test_v18b.py').read_text().replace('symbols_v18b.json','symbols_v19.json').replace('asteroids_nes_v18b_finalized_pickups.nes','asteroids_nes_v19_murderoids.nes')
exec(compile(base,str(P/'test_v18b.py'),'exec'))
mr=list(range(0x680,0x6e0,16))
def hunters():return {a:m[a+8] for a in mr if m[a+8]}
def mreset():
    reset();call('murder_init');m[0x3f]=7;m[0x670]=13;m[0x671]=7
def shot(b,x,y):m[b:b+16]=[47,0,x,0,y,0,0,0,0,0,12,0,0,0,0,0]

# Trigger levels 1..3 never, level 4 onward <=3 regulars; just once per wave.
for roots in range(4,13):
    for count in range(5):
        mreset();m[0x3f]=roots
        for i in range(count):m[0x308+i*16]=3
        call('murder_spawn_check')
        want=roots>=7 and count<=3
        assert bool(hunters())==want,(roots,count,hunters())
        assert m[0x673]==int(want)
        if want:
            assert hunters()=={0x680:1}
            for a in mr:m[a+8]=0
            call('murder_spawn_check');assert not hunters()
        call('next_wave');assert not hunters() and m[0x673]==0
mreset();m[6]=0;call('murder_spawn_check');assert not hunters()
print('PASS level-4 threshold, 3-or-fewer trigger, once per wave, new-wave reset')

# Every birth and destruction is accounted for under random split ordering.
for seed in range(100):
    mreset();call('murder_spawn_check')
    born=Counter({1:1});dead=Counter();rng=random.Random(seed)
    protected=m[0x300:0x600]+m[0x640:0x673]+m[0x700:0x800]
    while hunters():
        before=hunters();target=rng.choice(list(before));kind=before[target]
        for a in before:m[a+1]=210;m[a+3]=200;m[a+10]=0
        m[target+1]=60;m[target+3]=70
        m[0x600:0x640]=[0]*64;shot(0x600,64,74)
        prev=score();call('murder_collisions');after=hunters()
        removed={a:k for a,k in before.items() if after.get(a)!=k}
        added={a:k for a,k in after.items() if before.get(a)!=k}
        assert removed=={target:kind},(seed,removed,target)
        assert Counter(added.values())==({2:3} if kind==1 else {3:2} if kind==2 else {})
        assert score()-prev=={1:100,2:200,3:400}[kind]
        assert m[0x609]==1
        for a in added:assert m[a+10]==3
        dead[kind]+=1;born.update(added.values())
        assert m[0x300:0x600]+m[0x640:0x673]+m[0x700:0x800]==protected
    assert born==dead==Counter({1:1,2:3,3:6}) and score()==3100
print('PASS 100 families: 1/3/6 births and deaths, exactly 3100 points, no pickups or record corruption')

# Four missiles overlapping the parent: only the parent can die this update.
mreset();call('murder_spawn_check');m[0x681]=60;m[0x683]=70;m[0x68a]=0
for b in range(0x600,0x640,16):shot(b,64,74)
call('murder_collisions');assert Counter(hunters().values())=={2:3} and score()==100
assert sum(m[b+9] for b in range(0x600,0x640,16))==1
call('murder_collisions');assert score()==100
for _ in range(2):call('murder_tick')
assert all(m[a+10]>0 for a in hunters())
# Overlapping small hunters: one live bullet can award only one kill.
mreset()
for a in mr:m[a:a+16]=[0,60,0,70,0,0,0,0,3,0,0,4,0,0,0,0]
shot(0x600,64,74);call('murder_collisions')
assert len(hunters())==5 and score()==400
# Regular dispatcher consumes the bullet before the hunter dispatcher.
mreset();m[0x308]=3;m[0x301]=60;m[0x303]=70
m[0x688]=3;m[0x681]=60;m[0x683]=70
shot(0x600,64,74);call('collisions');call('murder_collisions')
assert score()==100 and hunters()=={0x680:3}
print('PASS overlapping hits, immediate projectile consumption, split grace, dispatcher isolation')

# All headings hold specified speeds; steering wraps and rotates shortest way.
for kind,speed in [(1,128),(2,240),(3,384)]:
    for h in range(48):
        mreset();m[0x688]=kind;m[0x689]=h;c.x=0;call('murder_velocity')
        assert abs(math.hypot(signed(0x684),signed(0x686))-speed)<1
for x,y,shipx,shipy,want in [(100,100,100,50,0),(100,100,150,100,12),(100,100,100,150,24),(100,100,50,100,36),(250,100,5,100,12),(100,235,100,5,24),(100,5,100,235,0)]:
    mreset();m[0x681]=x;m[0x683]=y;m[0x11]=shipx;m[0x13]=shipy;c.x=0
    call('murder_aim');assert c.a==want,(x,y,c.a,want)
mreset();m[0x688]=3;m[0x681]=100;m[0x683]=100;m[0x689]=47;m[0x68b]=1
m[0x11]=100;m[0x13]=50
call('murder_tick');assert m[0x689]==0
m[0x68b]=1;m[0x11]=50;m[0x13]=m[0x683]
call('murder_tick');assert m[0x689]==47
print('PASS all 48 headings: 0.5/0.9375/1.5 px per frame; wrap-aware pursuit and gradual turning')

# Hunters gate the wave transition, even when UFO and ordinary rocks are gone.
mreset();call('murder_spawn_check');m[0x40]=1;call('wave_tick');assert m[0x40]==0
for a in mr:m[a+8]=0
call('wave_tick');assert m[0x40]==240
for _ in range(240):call('wave_tick')
assert m[0x3f]==8 and len(kinds())==8 and m[0x673]==0

# Fill every draw record; verify complete bodies and no record memory writes.
mreset()
for i,a in enumerate(records):m[a+8]=2;m[a+1]=i*3;m[a+3]=100
for i,a in enumerate(pickups):pset(a,1,180+i*4,100,400-i)
for i,a in enumerate(mr):m[a+8]=2;m[a+1]=i*20;m[a+3]=140
stable=m[0x300:0x800];seen=set();m[0x42]=0
for _ in range(70):
    call('render');assert m[0x300:0x800]==stable
    assert m[0x42]<70 and m[0x4c]<=252
    ptr=0x22c
    while ptr<0x300 and m[ptr]!=248:
        tile=m[ptr+1]
        if tile==0x26:ptr+=4
        else:
            assert tile in (0x17,0x39) and ptr+16<=0x300,(ptr,tile)
            assert [m[ptr+j*4+1] for j in range(4)]==list(range(tile,tile+4))
            if tile==0x39:seen.add(m[ptr+3]);assert m[ptr+2]==2
            ptr+=16
assert seen==set(range(0,120,20))
print('PASS 70-record OAM rotation, complete bodies, all six hunters get turns, wave gating')

# Encoded CHR exactly matches the approved numeric source art and mirroring.
tree=ast.parse((P/'build_v19.py').read_text());art={}
for node in tree.body:
    if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('small','medium','left'):
        art[node.targets[0].id]=ast.literal_eval(node.value)
rom=(P/'asteroids_nes_v19_murderoids.nes').read_bytes();chrdata=rom[32784:]
def decode(index):
    raw=chrdata[index*16:index*16+16]
    return [''.join(str(((raw[y]>>(7-x))&1)+2*((raw[y+8]>>(7-x))&1)) for x in range(8)) for y in range(8)]
assert decode(0x138)==art['small']
for base,rows in [(0x139,[r+'0000' for r in art['medium']]+['0'*16]*4),(0x13d,[r+r[::-1] for r in art['left']])]:
    for ty in range(2):
        for tx in range(2):assert decode(base+ty*2+tx)==[r[tx*8:tx*8+8] for r in rows[ty*8:ty*8+8]]

# Main-loop integration: force eligible late-wave gameplay, then fly/fire.
mreset();m[0x3f]=7
for i in range(3):m[0x308+i*16]=3;m[0x301+i*16]=30+i*50;m[0x303+i*16]=100
call('ufo_init');m[0x648]=1;m[0x649]=0
c.pc=S['main'];m[0]=1
for i in range(900):
    frame(0x89 if i%120<60 else 0x82)
    assert all(m[a+8] in range(4) and (not m[a+8] or (m[a+3]<240 and m[a+9]<48)) for a in mr)
    assert m[0x3d]>=3
assert m[0x673]==1
print('PASS approved CHR art, 900 integrated hunter/UFO/pickup frames, invincible player')
