"""V24b — gate the triangle asteroid pulse by play state."""
from pathlib import Path

P = Path(__file__).parent
exec(compile((P / 'build_v24a.py').read_text(), str(P / 'build_v24a.py'), 'exec'))

def change24b(old, new):
    global source
    assert source.count(old) == 1, (old, source.count(old))
    source = source.replace(old, new, 1)

# Alive play uses the pulse only while at least one regular asteroid or
# Murderoid record is active.  This also mutes the four-second wave-clear gap.
change24b('''JSR asteroids
JSR asteroid_pulse24
JSR murder_tick''', '''JSR asteroids
JSR asteroid_pulse_gate24b
JSR murder_tick''')

# A destroyed ship and its five-second Game Over run keep the world moving,
# but never keep the asteroid pulse sounding.
change24b('''main_dead21:
JSR asteroids
JSR asteroid_pulse24
JSR death_explosion_tick22''', '''main_dead21:
JSR asteroids
JSR asteroid_pulse_off24
JSR death_explosion_tick22''')
change24b('''main_gameover22:
JSR death_explosion_tick22
JSR asteroids
JSR asteroid_pulse24''', '''main_gameover22:
JSR death_explosion_tick22
JSR asteroids
JSR asteroid_pulse_off24''')

gate = '''asteroid_pulse_gate24b:
LDX #$00
pulse_regular_scan24b:
LDA $0308,X
ORA $0408,X
ORA $0508,X
BNE pulse_on24b
TXA
CLC
ADC #$10
TAX
BNE pulse_regular_scan24b
JSR murder_count
BNE pulse_on24b
JMP asteroid_pulse_off24
pulse_on24b:
JMP asteroid_pulse24
'''
change24b('asteroid_pulse24:\n', gate + 'asteroid_pulse24:\n')

# Disable only the triangle bit. This keeps the routine safe once pulse/noise
# sound effects are added later.
change24b('''asteroid_pulse_off24:
LDA #$00
STA $067F
STA $4015
RTS''', '''asteroid_pulse_off24:
LDA #$00
STA $067F
LDA $4015
AND #$FB
STA $4015
RTS''')

for old, new in [
    ('asteroids_nes_v24a_medium_progress.nes', 'asteroids_nes_v24b_pulse_gated.nes'),
    ('symbols_v24a.json', 'symbols_v24b.json'),
    ('prototype_v24a.asm', 'prototype_v24b.asm'),
]:
    change24b(old, new)

exec(compile(source, str(P / 'build_v15.py'), 'exec'))
