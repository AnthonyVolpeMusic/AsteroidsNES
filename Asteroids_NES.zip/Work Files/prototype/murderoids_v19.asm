; Six reserved 16-byte records $0680-$06DF. Type 1 large, 2 medium, 3 small.
; 0/1 X, 2/3 Y, 4..7 velocity, 8 type, 9 heading, A grace, B turn timer.
; $0673 = family spawned this wave. Scratch $60-$68; aiming uses $52-$55.
murder_init:
LDA #$00
STA $0673
LDX #$5F
murder_init_loop:
STA $0680,X
DEX
BPL murder_init_loop
RTS
murder_count:
LDY #$00
LDX #$00
murder_count_loop:
LDA $0688,X
BEQ murder_count_next
INY
murder_count_next:
TXA
CLC
ADC #$10
TAX
CPX #$60
BNE murder_count_loop
TYA
RTS
murder_spawn_check:
LDA $06
BEQ murder_spawn_return
LDA $0673
BNE murder_spawn_return
LDA $3F
CMP #$07
BCC murder_spawn_return
LDY #$00
LDX #$00
murder_regular_count:
LDA $0308,X
BEQ murder_count_page4
INY
murder_count_page4:
LDA $0408,X
BEQ murder_count_page5
INY
murder_count_page5:
LDA $0508,X
BEQ murder_count_regular_next
INY
murder_count_regular_next:
TXA
CLC
ADC #$10
TAX
BNE murder_regular_count
CPY #$04
BCS murder_spawn_return
LDA #$01
STA $0673
STA $61
; Spawn opposite the ship across the toroidal playfield.
LDA $11
CLC
ADC #$80
STA $62
LDA $13
CLC
ADC #$78
BCC murder_spawn_y_no_carry
CLC
ADC #$10
JMP murder_spawn_y_ready
murder_spawn_y_no_carry:
CMP #$F0
BCC murder_spawn_y_ready
SEC
SBC #$F0
murder_spawn_y_ready:
STA $63
LDA #$00
STA $65
LDX #$00
JSR murder_make_child
STX $60
JSR murder_aim
LDX $60
STA $0689,X
JSR murder_velocity
murder_spawn_return:
RTS
murder_tick:
LDA $06
BNE murder_tick_game
RTS
murder_tick_game:
LDX #$00
murder_tick_loop:
LDA $0688,X
BNE murder_tick_active
JMP murder_tick_next
murder_tick_active:
LDA $068A,X
BEQ murder_grace_done
DEC $068A,X
murder_grace_done:
DEC $068B,X
BNE murder_move
LDA #$04
STA $068B,X
STX $60
JSR murder_aim
LDX $60
; Turn at most 7.5 degrees per four refreshes, shortest way around.
SEC
SBC $0689,X
BCS murder_turn_delta
CLC
ADC #$30
murder_turn_delta:
BEQ murder_move
CMP #$18
BCS murder_turn_left
INC $0689,X
LDA $0689,X
CMP #$30
BCC murder_turn_ready
LDA #$00
STA $0689,X
JMP murder_turn_ready
murder_turn_left:
LDA $0689,X
BNE murder_turn_decrement
LDA #$30
STA $0689,X
murder_turn_decrement:
DEC $0689,X
murder_turn_ready:
JSR murder_velocity
murder_move:
CLC
LDA $0680,X
ADC $0684,X
STA $0680,X
LDA $0681,X
ADC $0685,X
STA $0681,X
CLC
LDA $0682,X
ADC $0686,X
STA $0682,X
LDA $0683,X
ADC $0687,X
CMP #$F0
BCC murder_y_ready
LDY $0687,X
BMI murder_y_negative
SEC
SBC #$F0
JMP murder_y_ready
murder_y_negative:
CLC
ADC #$F0
murder_y_ready:
STA $0683,X
murder_tick_next:
TXA
CLC
ADC #$10
TAX
CPX #$60
BEQ murder_tick_done
JMP murder_tick_loop
murder_tick_done:
RTS
murder_make_child:
LDA #$00
STA $0680,X
STA $0682,X
LDA $62
STA $0681,X
LDA $63
STA $0683,X
LDA $61
STA $0688,X
LDA $65
JSR normalize_heading
STA $0689,X
LDA #$03
STA $068A,X
LDA #$04
STA $068B,X
JSR murder_velocity
RTS
murder_collisions:
LDA $06
BNE murder_collision_game
RTS
murder_collision_game:
LDX #$00
murder_bullet_loop:
STX $22
LDA $0600,X
BEQ murder_next_bullet
LDA $0609,X
BNE murder_next_bullet
LDA $0602,X
STA $23
LDA $0604,X
STA $24
LDX #$00
murder_collision_loop:
LDA $0688,X
BEQ murder_next_record
LDA $068A,X
BNE murder_next_record
LDY $0688,X
LDA murder_width,Y
STA $68
LDA $23
SEC
SBC $0681,X
CMP $68
BCC murder_hit_x
CMP #$FD
BCC murder_next_record
murder_hit_x:
LDA $24
SEC
SBC $0683,X
BCS murder_hit_y_positive
CLC
ADC #$F0
murder_hit_y_positive:
CMP $68
BCC murder_hit
CMP #$ED
BCC murder_next_record
murder_hit:
JSR collision_explode
JSR murder_destroy
JMP murder_next_bullet
murder_next_record:
TXA
CLC
ADC #$10
TAX
CPX #$60
BNE murder_collision_loop
murder_next_bullet:
LDX $22
TXA
CLC
ADC #$10
TAX
CPX #$40
BEQ murder_collisions_done
JMP murder_bullet_loop
murder_collisions_done:
RTS
murder_destroy:
; Parent snapshot precedes reusing its record. X is the family slot offset.
STX $60
LDA $0681,X
STA $62
LDA $0683,X
STA $63
LDA $0689,X
SEC
SBC #$08
JSR normalize_heading
STA $65
LDA $0688,X
STA $61
LDA #$00
STA $0688,X
LDA $61
CMP #$01
BEQ murder_destroy_large
CMP #$02
BEQ murder_destroy_medium
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
RTS
murder_destroy_large:
LDA #$64
JSR score_add
LDA #$02
STA $61
LDA #$03
STA $64
LDA #$20
STA $66
JMP murder_split_loop
murder_destroy_medium:
LDA #$C8
JSR score_add
LDA #$03
STA $61
LDA #$02
STA $64
LDA #$10
STA $66
murder_split_loop:
LDX $60
JSR murder_make_child
LDA $60
CLC
ADC $66
STA $60
LDA $65
CLC
ADC #$10
JSR normalize_heading
STA $65
DEC $64
BNE murder_split_loop
RTS
; Called from the shared rotating OAM pool. No partial four-tile bodies.
render_murder:
LDY #$08
LDA ($43),Y
CMP #$03
BEQ render_murder_small
LDA $4E
CMP #$04
BCS render_murder_big_ready
RTS
render_murder_big_ready:
LDA ($43),Y
CMP #$01
BEQ render_murder_large
LDA #$39
JMP render_murder_big
render_murder_large:
LDA #$3D
render_murder_big:
STA $4D
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
STA $50
JSR render_murder_tile
INC $4D
LDA $4F
CLC
ADC #$08
STA $4F
JSR render_murder_tile
INC $4D
LDA $4F
SEC
SBC #$08
STA $4F
LDA $50
CLC
ADC #$08
CMP #$F0
BCC render_murder_bottom
SEC
SBC #$F0
render_murder_bottom:
STA $50
JSR render_murder_tile
INC $4D
LDA $4F
CLC
ADC #$08
STA $4F
JSR render_murder_tile
RTS
render_murder_small:
LDA $4E
BNE render_murder_small_fits
RTS
render_murder_small_fits:
LDA #$38
STA $4D
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
STA $50
render_murder_tile:
LDY $4C
LDA $50
SEC
SBC #$01
STA $0200,Y
LDA $4D
STA $0201,Y
LDA #$02
STA $0202,Y
LDA $4F
STA $0203,Y
TYA
CLC
ADC #$04
STA $4C
DEC $4E
RTS
