from pathlib import Path
P=Path(__file__).parent
old=(P/'test_v29.py').read_text().replace("load('v29','asteroids_nes_v29_brake_sfx.nes')", "load('v30','asteroids_nes_v30_silent_flip.nes')")
exec(compile(old,str(P/'test_v29.py'),'exec'))
for heading in range(48):
    for active in (0,1,6,7,9):
        fresh29();m[3]=heading;m[1]=4;m[2]=0
        if active:call('pulse2_start26',active)
        before=m[0x87:0x8c];audio=m[0x4000:0x4016]
        call('flip')
        assert m[3]==(heading+24)%48
        assert m[0x87:0x8c]==before and m[0x4000:0x4016]==audio
        m[2]=4;call('flip');assert m[3]==(heading+24)%48
print('PASS silent 180-degree flip for all 48 headings, idle/busy Pulse 2 unchanged, held Down does not repeat')
