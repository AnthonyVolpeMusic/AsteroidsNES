; $067F is the inter-pulse countdown. $7C toggles C2/C#2.
asteroid_pulse24:
LDY #$00
LDX #$00
pulse_count24:
LDA $0308,X
BEQ pulse_page4_24
INY
pulse_page4_24:
LDA $0408,X
BEQ pulse_page5_24
INY
pulse_page5_24:
LDA $0508,X
BEQ pulse_next24
INY
pulse_next24:
TXA
CLC
ADC #$10
TAX
BNE pulse_count24
TYA
BEQ asteroid_pulse_off24
STA $7D
LDA $067F
BEQ pulse_fire24
DEC $067F
RTS
pulse_fire24:
LDA $7D
CMP #$0D
BCC pulse_12_24
LDA #$30
JMP pulse_interval24
pulse_12_24:
CMP #$09
BCC pulse_8_24
LDA #$24
JMP pulse_interval24
pulse_8_24:
CMP #$05
BCC pulse_4_24
LDA #$18
JMP pulse_interval24
pulse_4_24:
CMP #$02
BCC pulse_1_24
LDA #$0F
JMP pulse_interval24
pulse_1_24:
LDA #$09
pulse_interval24:
STA $067F
LDA $7C
EOR #$01
STA $7C
TAX
LDA #$18
STA $4008
LDA pulse_timer24,X
STA $400A
LDA pulse_high24,X
STA $400B
LDA #$04
STA $4015
RTS
asteroid_pulse_off24:
LDA #$00
STA $067F
STA $4015
RTS
