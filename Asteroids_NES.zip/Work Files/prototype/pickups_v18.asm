pickups_init:
LDA #$00
STA $0670
STA $0671
STA $0672
LDX #$00
pickups_clear:
STA $0700,X
INX
BNE pickups_clear
RTS
pickup_drop:
INC $0670
LDA $0670
AND #$01
BEQ pickup_should_drop
RTS
pickup_should_drop:
STX $56
LDX #$00
LDA #$FF
STA $5A
STA $5B
pickup_find_slot:
LDA $0708,X
BEQ pickup_slot_found
LDA $070A,X
CMP $5B
BCC pickup_oldest
BNE pickup_slot_next
LDA $0709,X
CMP $5A
BCS pickup_slot_next
pickup_oldest:
STX $57
LDA $0709,X
STA $5A
LDA $070A,X
STA $5B
pickup_slot_next:
TXA
CLC
ADC #$10
TAX
BNE pickup_find_slot
LDX $57
pickup_slot_found:
STX $57
LDY #$01
LDA ($45),Y
STA $0701,X
LDY #$03
LDA ($45),Y
STA $0703,X
LDA #$00
STA $0700,X
STA $0702,X
STA $070C,X
LDA #$0A
STA $070B,X
LDA #$A4
STA $0709,X
LDA #$01
STA $070A,X
LDY $0671
LDA pickup_order,Y
STA $0708,X
INC $0671
LDA $0671
CMP #$09
BCC pickup_order_ready
LDA #$00
STA $0671
pickup_order_ready:
JSR random
pickup_random_reduce:
CMP #$30
BCC pickup_direction_ready
SEC
SBC #$30
JMP pickup_random_reduce
pickup_direction_ready:
TAY
LDX $57
LDA pickup_xlo,Y
STA $0704,X
LDA pickup_xhi,Y
STA $0705,X
LDA pickup_ylo,Y
STA $0706,X
LDA pickup_yhi,Y
STA $0707,X
LDX $56
RTS
pickups_tick:
LDA $06
BNE pickups_tick_game
RTS
pickups_tick_game:
LDX #$00
pickups_tick_loop:
LDA $0708,X
BNE pickup_tick_active
JMP pickup_tick_next
pickup_tick_active:
LDA $0709,X
BNE pickup_timer_low
DEC $070A,X
pickup_timer_low:
DEC $0709,X
LDA $0709,X
ORA $070A,X
BNE pickup_still_alive
STA $0708,X
JMP pickup_tick_next
pickup_still_alive:
DEC $070B,X
BNE pickup_animation_done
LDA #$0A
STA $070B,X
LDA $070C,X
EOR #$01
STA $070C,X
pickup_animation_done:
CLC
LDA $0700,X
ADC $0704,X
STA $0700,X
LDA $0701,X
ADC $0705,X
STA $0701,X
CLC
LDA $0702,X
ADC $0706,X
STA $0702,X
LDA $0703,X
ADC $0707,X
CMP #$F0
BCC pickup_y_ok
LDY $0707,X
BMI pickup_y_negative
SEC
SBC #$F0
JMP pickup_y_ok
pickup_y_negative:
CLC
ADC #$F0
pickup_y_ok:
STA $0703,X
pickup_tick_next:
TXA
CLC
ADC #$10
TAX
BEQ pickups_tick_done
JMP pickups_tick_loop
pickups_tick_done:
RTS
pickups_collect:
LDA $06
BNE pickups_collect_game
RTS
pickups_collect_game:
LDX #$00
pickup_collect_loop:
LDA $0708,X
BNE pickup_collect_active
JMP pickup_collect_next
pickup_collect_active:
LDA $0701,X
SEC
SBC $11
CLC
ADC #$0F
CMP #$1F
BCS pickup_collect_next
LDA $0703,X
SEC
SBC $13
BCS pickup_collect_y_positive
CLC
ADC #$F0
pickup_collect_y_positive:
CLC
ADC #$0F
CMP #$F0
BCC pickup_collect_y_wrapped
SEC
SBC #$F0
pickup_collect_y_wrapped:
CMP #$1F
BCS pickup_collect_next
LDA $0708,X
TAY
LDA #$00
STA $0708,X
CPY #$05
BNE pickup_collect_points
LDA $0672
CMP #$02
BCS pickup_collect_next
INC $0672
JMP pickup_collect_next
pickup_collect_points:
STX $56
LDA pickup_score_chunks,Y
STA $57
pickup_points_loop:
LDA #$FA
JSR score_add
DEC $57
BNE pickup_points_loop
LDX $56
pickup_collect_next:
TXA
CLC
ADC #$10
TAX
BEQ pickups_collect_done
JMP pickup_collect_loop
pickups_collect_done:
RTS
pickup_boost_shot:
LDA $0672
BEQ pickup_boost_done
STA $58
STY $59
LDY $060A,X
pickup_boost_loop:
CLC
LDA $0605,X
ADC boost_xlo,Y
STA $0605,X
LDA $0606,X
ADC boost_xhi,Y
STA $0606,X
CLC
LDA $0607,X
ADC boost_ylo,Y
STA $0607,X
LDA $0608,X
ADC boost_yhi,Y
STA $0608,X
DEC $58
BNE pickup_boost_loop
LDY $59
pickup_boost_done:
RTS
render_pickup:
LDA $4E
BNE render_pickup_has_room
RTS
render_pickup_has_room:
LDY #$0A
LDA ($43),Y
BNE render_pickup_visible
LDY #$09
LDA ($43),Y
CMP #$79
BCS render_pickup_visible
AND #$08
BEQ render_pickup_visible
RTS
render_pickup_visible:
LDY #$08
LDA ($43),Y
TAX
LDA pickup_tiles,X
LDY #$0C
CLC
ADC ($43),Y
STA $5A
LDA pickup_palettes,X
STA $5B
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
SEC
SBC #$01
LDY $4C
STA $0200,Y
LDA $5A
STA $0201,Y
LDA $5B
STA $0202,Y
LDA $4F
STA $0203,Y
TYA
CLC
ADC #$04
STA $4C
DEC $4E
RTS
