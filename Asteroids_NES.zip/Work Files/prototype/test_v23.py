from pathlib import Path
P=Path(__file__).parent
base=(P/'test_v22.py').read_text().split('# AABB boundaries')[0].replace('symbols_v22.json','symbols_v23.json').replace('asteroids_nes_v22_gameover.nes','asteroids_nes_v23_rank_screen.nes')
exec(compile(base,str(P/'test_v22.py'),'exec'))
# Track actual PPU address/data writes, including NMI HUD suppression.
ppu=[0]*16384;addr=0;latch=0
oldget=Memory.__getitem__;oldset=Memory.__setitem__
def get(self,k):
    global latch
    if k==0x2002:latch=0
    return oldget(self,k)
def put(self,k,v):
    global addr,latch
    if k==0x2006:
        if not latch:addr=(v&63)<<8;latch=1
        else:addr=(addr&0xff00)|v;latch=0
    elif k==0x2007:ppu[addr&16383]=v;addr=(addr+1)&16383
    oldset(self,k,v)
Memory.__getitem__=get;Memory.__setitem__=put
ranks=['GARBAGE SCOW CAPTAIN','GALACTIC COOK','ROOKIE','ENSIGN','PILOT','ACE','LIEUTENANT','WARRIOR','CAPTAIN','COMMANDER','SPACE LORD']
limits=[0,2500,5000,10000,15000,20000,30000,40000,60000,80000,100000]
def setscore(n):
    m[0x30:0x33]=[(n>>(i*8))&255 for i in range(3)]
    m[0x33:0x39]=[int(d) for d in f'{n%1000000:06d}']
def decode(y):
    def char(v):
        if v==0:return ' '
        if v==0x8a:return ':'
        if 0x7b<=v<=0x84:return str(v-0x7b)
        return chr(65+v-0x61)
    return ''.join(char(v) for v in ppu[0x2000+y*32:0x2020+y*32])
for n in sorted({0,999999,*[max(0,t+d) for t in limits for d in (-1,0,1)]}):
    reset();setscore(n);m.pad=0;call('results_enter23')
    expected=max(i for i,t in enumerate(limits) if n>=t)
    assert decode(12).strip()==ranks[expected],(n,decode(12))
    assert decode(7).strip()==f'{n:06d}'
    for y,s in [(5,'FINAL SCORE:'),(10,'YOUR RANK:'),(18,'PRESS START TO REPLAY'),(22,'PRESS SELECT TO GO'),(23,'TO THE MAIN MENU')]:
        assert decode(y).strip()==s
    before=ppu.copy();runframe();assert ppu==before,'NMI overwrote results'
    assert all(m[0x200+4*i]==248 for i in range(64))
print('PASS every rank boundary and actual centered PPU text/score, HUD suppressed')
reset();m[0x3d]=1;rock(0x300,3);setscore(20000);runframe()
for _ in range(299):runframe();assert m[0x677]==2
runframe();assert m[0x677]==3 and decode(12).strip()=='ACE'
# Held Start entering results is ignored until released.
m.pad=0x10;call('results_enter23');runframe(0x10);assert m[0x677]==3
runframe(0);m[0x672]=2;m[0x676]=3;m[0x671]=23
runframe(0x10)
assert m[0x677]==0 and m[6]==1 and m[0x3d]==3 and m[7]==5
assert score()==0 and m[0x3f]==4 and kinds()==[1]*4
assert m[0x672]==m[0x676]==m[0x671]==0 and not any(m[0x600:0x640])
assert m[0x11]==128 and m[0x13]==120 and not any(m[0x14:0x18])
assert decode(12).strip()=='' and decode(1).startswith('SCORE:000000')
call('results_enter23');runframe(0);runframe(0x20)
assert m[6]==0 and m[0x677]==0 and decode(15).strip()=='ARCADE'
runframe(0);runframe(0x10);assert m[6]==1 and kinds()==[1]*4
print('PASS 300-update transition, held-button protection, replay reset, menu and new start')
