"""Compose V17 UFO additions over the preserved V16/V15 sources."""
from pathlib import Path
import math
P=Path(__file__).parent
base=(P/'build_v16.py').read_text()
# Obtain V16 source without executing its final assembler/build operation.
exec(base[:base.index('exec(compile(source,')])
def change(old,new):
    global source
    assert old in source, old
    source=source.replace(old,new,1)
change('JSR collisions\nJSR wave_tick','JSR collisions\nJSR ufo_tick\nJSR ufo_collisions\nJSR wave_tick')
change('JSR blank_title\nJSR set_game_rocks','JSR blank_title\nJSR ufo_init\nJSR set_game_rocks')
change('next_wave:\n','next_wave:\nJSR ufo_wave_reset\n')
change('JSR render_asteroids\nRTS','JSR render_ufo\nJSR render_asteroids\nRTS')
change('wave_tick:\n',(P/'ufo_v17.asm').read_text()+'\nwave_tick:\n')
change('0x0f,0x30,0x24,0x0f,','0x0f,0x30,0x24,0x16,')
tables={}
for axis,fn in [('x',lambda a:math.sin(a)),('y',lambda a:-math.cos(a))]:
    vec=[round(fn(h*math.pi/24)*640)&65535 for h in range(48)]
    tables['ufo_'+axis+'lo']=[v&255 for v in vec]
    tables['ufo_'+axis+'hi']=[v>>8 for v in vec]
tables['ufo_aim']=[round(math.atan2(x,-y)*24/math.pi)%48 if x or y else 0 for y in range(16) for x in range(16)]
tables['ufo_small_chance']=[0,24,48,72,96,120,144,168,192]
change('data={}\n','data='+repr(tables)+'\n')
assets='''
big_ufo=['000011110000','000113311000','000113311000','000011110000',
 '000222222000','002222222200','021212212120','222222222222',
 '333333333333','033333333330','003333333300','000033330000']
small_ufo=['00111100','00133100','00111100','02222220','22222222','33333333','03333330','00333300']
ufo_shot=['00000000','00000000','00233200','00322300','00322300','00233200','00000000','00000000']
assert all(len(r)==12 for r in big_ufo) and len(big_ufo)==12
padded=[r+'0000' for r in big_ufo]+['0'*16]*4
for ty in range(2):
 for tx in range(2):
  tile(0x120+ty*2+tx,[[int(padded[ty*8+y][tx*8+x]) for x in range(8)] for y in range(8)])
tile(0x124,[[int(c) for c in r] for r in small_ufo])
tile(0x125,[[int(c) for c in r] for r in ufo_shot])
'''
change("output=P/'asteroids_nes_v16_oam_rotation.nes'",assets+"\noutput=P/'asteroids_nes_v17_ufos.nes'")
source=source.replace('prototype_v16.asm','prototype_v17.asm').replace('symbols_v16.json','symbols_v17.json')
exec(compile(source,str(P/'build_v15.py'),'exec'))
