# Asteroids V17a — UFO pressure adjustment

V17 remains the confirmed working baseline. V17a changes only UFO firing and horizontal speed.

- The UFO now attempts to fire every 60 updates (about one second), instead of every 90.
- It can hold up to two enemy projectiles at once. Each has its own ten-byte RAM record, 96-update lifetime, wrap logic, velocity and heading. A live shot is never overwritten; an expired slot is reused.
- The small UFO moves horizontally only every other update, the same half-pixel average speed as the big UFO. It keeps its aimed firing behavior.
- OAM reserves slots 5–8 for the big UFO, 9–10 for its two projectiles, and starts the bounded asteroid/pickup rotation pool at slot 11. The pool now has 53 hardware sprites rather than 54. The small UFO occupies its first reserved slot; the unused big-UFO entries remain hidden.
- Player One remains invincible. No player collision changes are added.

Build and test:

    python3 -m pip install py65 pillow
    python3 prototype/build_v17a.py
    python3 prototype/test_v17a.py
    python3 prototype/test_full_wave.py 17a 100 4
    python3 prototype/test_full_wave.py 17a 100 12

Passed tests include the prior wave transition suite, exact two-slot cadence/reuse/no-overwrite checks, matched UFO movement, aimed small-UFO shot, two protected enemy-projectile OAM entries in a crowded 48-medium scene, and 100 full waves at four and twelve roots (2,100 and 6,300 asteroid points respectively).

Play from a fresh boot. The two UFO projectiles presently remain nonlethal because Player One is deliberately invincible during gameplay development.
