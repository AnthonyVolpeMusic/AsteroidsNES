"""V18a: only small asteroid kills advance the pickup sequence."""
from pathlib import Path
P = Path(__file__).parent
source = (P/'build_v18.py').read_text()
source = source.replace("exec(compile(source,str(P/'build_v15.py'),'exec'))", "source = source.replace('pickup_drop:\\n', 'pickup_drop:\\nLDA $26\\nCMP #$03\\nBEQ pickup_small_destroyed\\nRTS\\npickup_small_destroyed:\\n')\nsource = source.replace('asteroids_nes_v18_pickups.nes', 'asteroids_nes_v18a_small_asteroid_pickups.nes').replace('symbols_v18.json', 'symbols_v18a.json').replace('prototype_v18.asm', 'prototype_v18a.asm')\nexec(compile(source,str(P/'build_v15.py'),'exec'))")
exec(compile(source, str(P/'build_v18.py'), 'exec'))
