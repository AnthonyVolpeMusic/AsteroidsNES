from pathlib import Path
P=Path(__file__).parent
text=(P/'test_v24a.py').read_text().replace('symbols_v24a.json','symbols_v24c.json').replace('asteroids_nes_v24a_medium_progress.nes','asteroids_nes_v24c_audio_optimized.nes')
exec(compile(text,str(P/'test_v24a.py'),'exec'))
def resetall():
    m[:0x800]=[0]*0x800
    m[6]=1;m[0x3d]=3;m[0x3f]=4;m[0x7f]=8;m[0x11]=128;m[0x13]=120;m[0x2f]=165
def timed(label):
    t=c.processorCycles;call(label);return c.processorCycles-t
resetall();m[0x308]=1;call('wave_tick');call('pulse_gate24c');assert m[0x4015]&4
m[0x308]=0;m[0x688]=3;call('wave_tick');assert m[0x80]==1
m[0x688]=0;m[0x41]=1;call('wave_tick');call('pulse_gate24c');assert m[0x80]==0 and not m[0x4015]&4
resetall();call('set_game_rocks');call('pulse_gate24c');assert m[0x4015]&4
call('player_kill21');call('pulse_gate24c');assert not m[0x4015]&4
for _ in range(120):call('death_tick21')
call('pulse_gate24c');assert m[0x677]==0 and m[0x4015]&4
resetall();call('next_wave');call('pulse_gate24c');assert m[0x4015]&4
print('PASS wave-clear including UFO-only, lone Murderoid, death, respawn, next wave gates')
resetall();m[0x80]=1;m[0x67f]=10
print('V24c ordinary audio service cycles:',timed('pulse_gate24c'))
# Representative level-five layout, same RAM snapshot with/without audio.
resetall();m[0x3f]=8;m[8]=255;call('set_game_rocks');m[0x67f]=10
snapshot=m[:];m[0]=1;c.pc=S['main'];start=c.processorCycles;frame();cost=c.processorCycles-start
m[:]=snapshot
# Test-only RAM ROM override: central service RTS. Never written to deliverable.
address=S['pulse_gate24c'];saved=m[address];m[address]=0x60
m[0]=1;c.pc=S['main'];start=c.processorCycles;frame();silent=c.processorCycles-start
m[address]=saved
print('Level-five opening CPU cycles (NMI included; DMA stall excluded): music',cost,'audio bypass',silent,'delta',cost-silent)
assert cost-silent<100
