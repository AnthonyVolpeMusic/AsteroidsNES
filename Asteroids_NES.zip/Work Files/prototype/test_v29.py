"""Brake sequence and actual controls; execute assembled ROM."""
from pathlib import Path
P=Path(__file__).parent
# Reuse established CPU/APU bus helpers without running old stop-is-silent test.
base=(P/'test_v25a.py').read_text().split("load('v25','asteroids_nes_v25_core_sfx.nes')")[0]
exec(compile(base,str(P/'test_v25a.py'),'exec'))
def fresh29():
    load('v29','asteroids_nes_v29_brake_sfx.nes')
    m[7]=5;m[0x3a]=0x20;m[0x3b]=0x4e
def timer(n):return round(1789773/(16*440*2**((n-69)/12))-1)
fresh29();call('sfx_shot_start25');call('sfx_noise_start25',14);call('asteroid_pulse24')
call('pulse2_start26',9)
samples=[]
for _ in range(30):
    samples.append((m[0x4006]+256*(m[0x4007]&7),m[0x4004]&15))
    assert m.enabled==15 and all(m.length)
    call('pulse2_tick26')
assert samples==([(timer(79),15)]*3+[(timer(77),15)]*3)*5
assert m.enabled==13 and m[0x87]==m[0x89]==0 and not m.ignored
for active in range(1,10):
    fresh29();call('pulse2_start26',active);call('pulse2_tick26')
    before=m[0x87:0x8b];call('pulse2_start26',9);assert m[0x87:0x8b]==before
for incoming in range(1,9):
    fresh29();call('pulse2_start26',9);call('pulse2_start26',incoming)
    assert m[0x87]==(incoming if incoming<7 else 9)
# game normal controls read the already-polled pad; exact successful stop path.
fresh29();m[1]=0x44;m[2]=0;m[0x14:0x18]=[12,1,45,255]
call('special_pressed')
assert m[7]==4 and m[0x87]==9 and not any(m[0x14:0x18]) and m[3]==0
fresh29();m[1]=0x44;m[2]=0;m[7]=0
call('special_pressed');assert m[0x87]!=9 and m[7]==0
fresh29();call('pulse2_start26',6);m[1]=0x44;m[2]=0
call('special_pressed');assert m[7]==4 and m[0x87]==6
call('audio_reset25a');assert m[0x87]==m[0x89]==0
print('PASS 30-frame G5/F5 brake; five cycles; independent channels; busy rejection; priorities; successful/empty-SUPER/busy braking; reset')
