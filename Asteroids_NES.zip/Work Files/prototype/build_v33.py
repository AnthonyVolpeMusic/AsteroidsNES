"""V33: four modes, Evil steering, and weighted performance counter."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v32.py').read_text(),str(P/'build_v32.py'),'exec'))
marker='asm=Assembler(MPU()); labels={};pc=0x8000'
assert source.count(marker)==1
source=source.replace(marker,"exec(compile((P/'patch_v33.py').read_text(),str(P/'patch_v33.py'),'exec'))\n"+marker)
for old,new in [('asteroids_nes_v32_drunk.nes','asteroids_nes_v33_evil.nes'),('symbols_v32.json','symbols_v33.json'),('prototype_v32.asm','prototype_v33.asm')]:
    assert source.count(old)==1
    source=source.replace(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
