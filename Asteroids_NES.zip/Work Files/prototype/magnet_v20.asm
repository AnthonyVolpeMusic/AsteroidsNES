; Pickup D is latched attraction state. $0676 magnet tier 0..3.
; Attraction speed is ceil((sqrt(2*2 + 2*2)+1)*256) = 981.
pickup_attract_velocity:
STX $69
JSR pickup_attract_aim
TAY
LDX $69
LDA attract_xlo,Y
STA $0704,X
LDA attract_xhi,Y
STA $0705,X
LDA attract_ylo,Y
STA $0706,X
LDA attract_yhi,Y
STA $0707,X
RTS
pickup_magnet_convert:
TXA
PHA
LDX #$00
pickup_magnet_convert_loop:
LDA $0708,X
CMP #$0A
BNE pickup_magnet_convert_next
LDA #$04
STA $0708,X
pickup_magnet_convert_next:
TXA
CLC
ADC #$10
TAX
BNE pickup_magnet_convert_loop
PLA
TAX
RTS
pickups_collect:
LDA $06
BNE pickups_collect_game
RTS
pickups_collect_game:
LDX #$00
pickup_collect_loop:
LDA $0708,X
BNE pickup_collect_active
JMP pickup_collect_next
pickup_collect_active:
LDA $070D,X
BNE pickup_collect_arriving
LDY $0676
LDA magnet_bias,Y
STA $6A
LDA magnet_width,Y
STA $6B
JMP pickup_collect_measure
pickup_collect_arriving:
; Actual contact is an 8x8 ship versus an 8x8 pickup, distinct from capture.
LDA #$07
STA $6A
LDA #$0F
STA $6B
pickup_collect_measure:
LDA $0701,X
SEC
SBC $11
CLC
ADC $6A
CMP $6B
BCC pickup_collect_x_inside
JMP pickup_collect_next
pickup_collect_x_inside:
LDA $0703,X
SEC
SBC $13
BCS pickup_collect_y_positive
CLC
ADC #$F0
pickup_collect_y_positive:
CLC
ADC $6A
CMP #$F0
BCC pickup_collect_y_wrapped
SEC
SBC #$F0
pickup_collect_y_wrapped:
CMP $6B
BCC pickup_collect_inside
JMP pickup_collect_next
pickup_collect_inside:
LDA $070D,X
BNE pickup_collect_award
; Capture now; move visibly next update. Never award at the large boundary.
LDA #$01
STA $070D,X
JMP pickup_collect_next
pickup_collect_award:
LDA $0708,X
TAY
LDA #$00
STA $0708,X
CPY #$05
BEQ pickup_collect_speed
CPY #$06
BEQ pickup_collect_super
CPY #$0A
BEQ pickup_collect_magnet
JMP pickup_collect_points
pickup_collect_speed:
LDA $0672
CMP #$02
BCS pickup_collect_next
INC $0672
JMP pickup_collect_next
pickup_collect_super:
LDA $07
CMP #$05
BCS pickup_collect_next
INC $07
JMP pickup_collect_next
pickup_collect_magnet:
LDA $0676
CMP #$03
BCS pickup_collect_magnet_max
INC $0676
LDA $0676
CMP #$03
BNE pickup_collect_next
JSR pickup_magnet_convert
JMP pickup_collect_next
pickup_collect_magnet_max:
LDY #$04
pickup_collect_points:
STX $56
LDA pickup_score_chunks,Y
STA $57
pickup_points_loop:
LDA #$FA
JSR score_add
DEC $57
BNE pickup_points_loop
LDX $56
pickup_collect_next:
TXA
CLC
ADC #$10
TAX
BEQ pickups_collect_done
JMP pickup_collect_loop
pickups_collect_done:
RTS
