"""V25: player shot plus asteroid/Murderoid/death sound effects."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v24d.py').read_text(),str(P/'build_v24d.py'),'exec'))
def change25(old,new,count=1):
    global source
    assert source.count(old)==count,(old,source.count(old))
    source=source.replace(old,new,count)

# Advance envelopes before controls/gameplay can start a fresh full-volume SFX.
change25('''main:
LDA $00
BNE main
LDA $0677''','''main:
LDA $00
BNE main
JSR sfx_tick25
LDA $0677''')

# Normal fire and one sound for the four-bullet rainbow volley.
change25('''spawn:
LDA #$30
STA $0600,X''','''spawn:
JSR sfx_shot_start25
LDA #$30
STA $0600,X''')
change25('''DEC $07
LDX #$00
LDA #$00
STA $21''','''DEC $07
JSR sfx_shot_start25
LDX #$00
LDA #$00
STA $21''')

# Player death restarts the #15 noise envelope.
change25('''JSR death_burst_start22
LDA #$01
STA $0677''','''JSR death_burst_start22
LDA #$0F
JSR sfx_noise_start25
LDA #$01
STA $0677''')

# Player-bullet regular-asteroid hits use the destroyed asteroid's kind.
change25('''JSR collision_explode
TXA
STA $45''','''JSR collision_explode
LDA $26
JSR sfx_asteroid_start25
TXA
STA $45''')

# Enemy projectiles/bodies use the same sound selection for regular asteroids.
change25('''LDY #$08
LDA ($43),Y
CMP #$01''','''LDY #$08
LDA ($43),Y
STA $26
JSR sfx_asteroid_start25
LDA $26
CMP #$01''')

# Murderoids retain their kind in $61 after removal.
change25('''LDA #$00
STA $0688,X
LDA $61
CMP #$01''','''LDA #$00
STA $0688,X
LDA $61
JSR sfx_asteroid_start25
LDA $61
CMP #$01''')

sfx = '''sfx_tick25:
LDA $82
BEQ sfx_noise_tick25
LDX $83
LDA shot_volume25,X
ORA #$B0
STA $4000
LDA shot_timer25,X
STA $4002
LDA #$00
STA $4003
INC $83
DEC $82
BNE sfx_noise_tick25
LDA $4015
AND #$FE
STA $4015
sfx_noise_tick25:
LDA $84
BEQ sfx_done25
DEC $84
LDA $84
LSR A
ORA #$30
STA $400C
LDA $85
STA $400E
LDA $84
BNE sfx_done25
LDA $4015
AND #$F7
STA $4015
sfx_done25:
RTS
sfx_shot_start25:
LDA #$0B
STA $82
LDA #$01
STA $83
LDA #$BF
STA $4000
LDA #$8E
STA $4002
LDA #$00
STA $4003
LDA $4015
ORA #$01
STA $4015
RTS
sfx_asteroid_start25:
CMP #$01
BEQ sfx_large25
CMP #$02
BEQ sfx_medium25
LDA #$0C
JMP sfx_noise_start25
sfx_large25:
LDA #$0E
JMP sfx_noise_start25
sfx_medium25:
LDA #$0D
sfx_noise_start25:
STA $85
LDA #$1E
STA $84
LDA #$3F
STA $400C
LDA $85
STA $400E
LDA #$00
STA $400F
LDA $4015
ORA #$08
STA $4015
RTS
'''
change25('shield_tick:\n',sfx+'shield_tick:\n')
change25("data.update({'pulse_timer24'", "data.update({'shot_timer25':[0x8E,0x90,0x93,0x95,0x98,0x9A,0x9D,0x9F,0xA2,0xA4,0xA7,0xA9], 'shot_volume25':[0x0F,0x0E,0x0D,0x0C,0x0A,0x09,0x08,0x06,0x05,0x04,0x02,0x00]})\ndata.update({'pulse_timer24'")
for old,new in [('asteroids_nes_v24d_cached_tempo.nes','asteroids_nes_v25_core_sfx.nes'),('symbols_v24d.json','symbols_v25.json'),('prototype_v24d.asm','prototype_v25.asm')]:change25(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
