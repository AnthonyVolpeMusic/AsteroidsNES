"""V18b assembled-6502 tests: 24-item sequence and EXTRA SUPER."""
from pathlib import Path
P = Path(__file__).parent
source = (P/'test_v18.py').read_text()
source = source.replace('symbols_v18.json', 'symbols_v18b.json').replace('asteroids_nes_v18_pickups.nes', 'asteroids_nes_v18b_finalized_pickups.nes')
source = source.replace('kind=1+kill%3', 'kind=3')
source = source.replace('    clear()\n    addr=', '''    for excluded in (1, 2):
        clear()
        m[0x300:0x310]=[0,60,0,70,0,0,0,0,excluded,12,0,0,0,0,0,0]
        m[0x600:0x640]=[0]*64
        m[0x600:0x610]=[47,0,64,0,74,0,0,0,0,0,12,0,0,0,0,0]
        parity,sequence=m[0x670],m[0x671]
        old=score()
        call('collisions')
        assert score()-old=={1:25,2:50}[excluded]
        assert (m[0x670],m[0x671])==(parity,sequence)
        assert not active()
    clear()
    addr=''')
source = source.replace("call('pickup_drop')", "m[0x26]=3\ncall('pickup_drop')")
source = source.replace('every-second kill across all sizes/pages', 'every-second small kill; large/medium excluded without changing parity')
source = source.replace("expected=[1,2,1,3,1,2,1,4,5]*2", "expected=[1,2,1,3,1,2,1,4,5,6,1,2,3,2,4,7,2,3,6,4,7,4,8,9]")
source = source.replace('for kill in range(36):', 'for kill in range(48):')
source = source.replace('0<=m[0x671]<9', '0<=m[0x671]<24').replace('m[a+8] in range(6)', 'm[a+8] in range(10)')
exec(compile(source, str(P/'test_v18.py'), 'exec'))

# All new point items award their printed values exactly once; EXTRA SUPER
# increments the existing meter only up to five.
reset()
for i,(kind,points) in enumerate(((7,2000),(8,3000),(9,5000))):
    pset(0x700+i*16,kind,128,120)
call('pickups_collect')
assert score()==10000 and not active(),score()
m[7]=3
pset(0x700,6,128,120);call('pickups_collect');assert m[7]==4
pset(0x700,6,128,120);call('pickups_collect');assert m[7]==5
pset(0x700,6,128,120);call('pickups_collect');assert m[7]==5

# Verify both reset entry points preserve the meter but restart the 24-item
# order and parity counter.  The current test ROM deliberately has no live
# player death because Player One is invincible.
m[0x670]=1;m[0x671]=23;m[7]=4
call('pickup_player_death')
assert (m[0x670],m[0x671],m[7])==(0,0,4)
m[0x670]=1;m[0x671]=23
call('next_wave')
assert (m[0x670],m[0x671])==(0,0)
print('PASS 24-item order; 2000/3000/5000 awards; EXTRA SUPER cap; level/death counter resets')
