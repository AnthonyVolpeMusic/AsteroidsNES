# V19a — farthest-wall Murderoid spawning

Replaces V19's opposite-point spawn with Anthony's Smiley vs Angryman rule:

1. Randomly choose the left/right pair or top/bottom pair using one random bit.
2. Choose the farther wall in that pair based on Player One's center.
3. Spawn the full 16x16 large Murderoid inside that wall, with a random position along it.

Left/right X is 0/240; random Y is 0–224. Top/bottom Y is 0/224; random X is 0–240. Bounds use the existing 256x240 playfield. Invalid random coordinates are redrawn. Exact center ties select left or top. All other V19 gameplay, scores, split allocation, trigger, pursuit, OAM rotation, and invincibility remain as before.

Build: `python prototype/build_v19a.py`

Tests: `python prototype/test_v19a.py`

The V19 hunter/ship/pickup regression suite is retargeted to V19a, followed by 2,295 spawn cases covering all 255 nonzero random seeds at nine ship positions, including center boundaries and corners. Tests verify the farther wall choice, random positions on both axes, all four walls, and the full 16x16 sprite staying in bounds.

Open the new ROM fresh rather than loading an older-version save state.
