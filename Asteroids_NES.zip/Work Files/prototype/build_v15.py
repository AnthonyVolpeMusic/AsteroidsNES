from pathlib import Path
import math,re,json,zipfile
from PIL import Image
from py65.devices.mpu6502 import MPU
from py65.assembler import Assembler
P=Path(__file__).parent
lines=[]
def emit(s): lines.extend(x.strip() for x in s.strip().splitlines() if x.strip())
# ZP: 00 ready,01 buttons,02 old,03 heading,04 rotation cooldown,05 fire cooldown,06 game state,07 power,08 shield timer
# 10/11 X,12/13 Y,14/15 VX,16/17 VY; 20+ main scratch. NMI uses no scratch.
# 40 wave-clear countdown, 41 reserved active-enemy count (future UFOs).
emit('''
reset:
SEI
CLD
LDX #$40
STX $4017
LDX #$FF
TXS
INX
STX $2000
STX $2001
STX $4010
STX $4015
BIT $2002
warm1:
BIT $2002
BPL warm1
LDA #$00
clear:
STA $0000,X
STA $0100,X
STA $0200,X
STA $0300,X
STA $0400,X
STA $0600,X
STA $0600,X
STA $0700,X
INX
BNE clear
warm2:
BIT $2002
BPL warm2
LDA #$20
STA $2006
LDA #$00
STA $2006
LDY #$10
LDX #$00
blank:
STA $2007
INX
BNE blank
DEY
BNE blank
LDA #$3F
STA $2006
LDA #$00
STA $2006
LDX #$00
pal:
LDA palette,X
STA $2007
INX
CPX #$20
BNE pal
LDX #$00
load_asteroids:
LDA asteroid_init0,X
STA $0300,X
LDA asteroid_init1,X
STA $0400,X
LDA asteroid_init2,X
STA $0500,X
INX
BNE load_asteroids
JSR load_title
LDA #$80
STA $11
LDA #$78
STA $13
LDA #$01
STA $00
LDA #$05
STA $07
LDA #$03
STA $3D
LDA #$04
STA $3F
LDA #$20
STA $3A
LDA #$4E
STA $3B
LDA #$A5
STA $2F
LDA #$10
STA $3E
LDA #$88
STA $2000
LDA #$1E
STA $2001
main:
LDA $00
BNE main
JSR controls
JSR shield_tick
JSR physics
JSR bullets
JSR asteroids
JSR collisions
JSR wave_tick
JSR render
LDA #$01
STA $00
JMP main
nmi:
PHA
TXA
PHA
TYA
PHA
LDA $00
BEQ nmi_done
LDA #$00
STA $2003
LDA #$02
STA $4014
LDA $06
BEQ nmi_hud_done
LDA #$20
STA $2006
LDA #$26
STA $2006
LDX #$00
nmi_score:
LDA $33,X
CLC
ADC #$7B
STA $2007
INX
CPX #$06
BNE nmi_score
LDA #$20
STA $2006
LDA #$35
STA $2006
LDA $07
CLC
ADC #$7B
STA $2007
LDA #$20
STA $2006
LDA #$3F
STA $2006
LDA $3D
CLC
ADC #$7B
STA $2007
nmi_hud_done:
LDA #$00
STA $2005
STA $2005
STA $00
nmi_done:
PLA
TAY
PLA
TAX
PLA
RTI
irq:
RTI
load_title:
LDA #$20
STA $2006
LDA #$00
STA $2006
LDX #$00
load_title_page0:
LDA title_nt0,X
STA $2007
INX
BNE load_title_page0
LDX #$00
load_title_page1:
LDA title_nt1,X
STA $2007
INX
BNE load_title_page1
LDX #$00
load_title_page2:
LDA title_nt2,X
STA $2007
INX
BNE load_title_page2
LDX #$00
load_title_page3:
LDA title_nt3,X
STA $2007
INX
BNE load_title_page3
RTS
blank_title:
LDA #$00
STA $2001
LDA #$20
STA $2006
LDA #$00
STA $2006
LDY #$04
LDX #$00
blank_title_loop:
LDA #$00
STA $2007
INX
BNE blank_title_loop
DEY
BNE blank_title_loop
JSR load_hud
LDA #$1E
STA $2001
RTS
load_hud:
LDA #$20
STA $2006
LDA #$20
STA $2006
LDX #$00
load_hud_loop:
LDA hud_line,X
STA $2007
INX
CPX #$20
BNE load_hud_loop
RTS
controls:
LDA $01
STA $02
LDA #$01
STA $4016
LDA #$00
STA $4016
STA $01
LDX #$08
readpad:
LDA $4016
LSR A
ROL $01
DEX
BNE readpad
LDA $06
BNE game_controls
LDA $02
EOR #$FF
AND $01
AND #$10
BEQ title_controls_done
JSR blank_title
JSR set_game_rocks
LDA #$01
STA $06
title_controls_done:
RTS
game_controls:
LDA $02
EOR #$FF
AND $01
AND #$40
BNE special_pressed
JMP game_normal
special_pressed:
LDA $07
BNE special_has_power
JMP game_normal
special_has_power:
LDA $01
AND #$04
BNE special_stop
LDA $01
AND #$08
BNE special_rainbow
LDA $08
BEQ shield_available
JMP game_normal
shield_available:
DEC $07
LDA #$3C
STA $08
JMP game_normal
special_stop:
DEC $07
LDA #$00
STA $14
STA $15
STA $16
STA $17
RTS
special_rainbow:
LDX #$00
rainbow_check:
LDA $0600,X
BEQ rainbow_slot_clear
RTS
rainbow_slot_clear:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE rainbow_check
DEC $07
LDX #$00
LDA #$00
STA $21
rainbow_loop:
LDY $21
LDA $03
CLC
ADC rainbow_offsets,Y
CMP #$30
BCC rainbow_heading_ok
SBC #$30
rainbow_heading_ok:
TAY
LDA #$30
STA $0600,X
LDA $10
STA $0601,X
LDA $11
STA $0602,X
LDA $12
STA $0603,X
LDA $13
STA $0604,X
CLC
LDA $14
ADC bxlo,Y
STA $0605,X
LDA $15
ADC bxhi,Y
STA $0606,X
CLC
LDA $16
ADC bylo,Y
STA $0607,X
LDA $17
ADC byhi,Y
STA $0608,X
TYA
STA $060A,X
INC $21
TXA
CLC
ADC #$10
TAX
LDA $21
CMP #$04
BNE rainbow_loop
RTS
game_normal:
LDA $04
BEQ rot_ready
DEC $04
JMP flip
rot_ready:
LDA $01
AND #$03
CMP #$01
BEQ right
CMP #$02
BNE flip
LDA $03
BNE left_nonzero
LDA #$30
left_nonzero:
SEC
SBC #$01
STA $03
JMP rot_delay
right:
INC $03
LDA $03
CMP #$30
BCC rot_delay
LDA #$00
STA $03
rot_delay:
LDA #$01
STA $04
flip:
LDA $02
EOR #$FF
AND $01
AND #$04
BEQ thrust
LDA $03
CLC
ADC #$18
CMP #$30
BCC flip_save
SBC #$30
flip_save:
STA $03
thrust:
LDA $01
AND #$08
BEQ shoot
LDX $03
''')
for v,table in [(0x14,'ax'),(0x16,'ay')]:
 emit(f'''CLC
 LDA ${v:02X}
 ADC {table}lo,X
 STA ${v:02X}
 LDA ${v+1:02X}
 ADC {table}hi,X
 STA ${v+1:02X}
 BPL positive{v}
 CMP #$FE
 BCS capped{v}
 LDA #$FE
 STA ${v+1:02X}
 LDA #$00
 STA ${v:02X}
 JMP capped{v}
 positive{v}:
 CMP #$02
 BCC capped{v}
 LDA #$02
 STA ${v+1:02X}
 LDA #$00
 STA ${v:02X}
 capped{v}:''')
emit('''shoot:
LDA $05
BEQ can_shoot
DEC $05
RTS
can_shoot:
LDA $01
AND #$80
BEQ controls_done
LDX #$00
find_slot:
LDA $0600,X
BEQ spawn
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE find_slot
RTS
spawn:
LDA #$30
STA $0600,X
LDA #$08
STA $05
LDY $03
''')
for i in range(4): emit(f'LDA ${0x10+i:02X}\nSTA ${0x601+i:04X},X')
for v,t,off in [(0x14,'bx',0x605),(0x16,'by',0x607)]:
 emit(f'''CLC
LDA ${v:02X}
ADC {t}lo,Y
STA ${off:04X},X
LDA ${v+1:02X}
ADC {t}hi,Y
STA ${off+1:04X},X''')
emit('''TYA
STA $060A,X
controls_done:
RTS
shield_tick:
LDA $08
BEQ shield_done
DEC $08
shield_done:
RTS
physics:
CLC
LDA $10
ADC $14
STA $10
LDA $11
ADC $15
STA $11
CLC
LDA $12
ADC $16
STA $12
LDA $13
ADC $17
CMP #$F0
BCC ship_y_ok
LDX $17
BMI ship_y_negative
SEC
SBC #$F0
JMP ship_y_ok
ship_y_negative:
CLC
ADC #$F0
ship_y_ok:
STA $13
RTS
bullets:
LDX #$00
bullet_loop:
LDA $0600,X
BNE bullet_active
JMP bullet_next
bullet_active:
LDA $0609,X
BEQ bullet_flying
DEC $0600,X
BNE bullet_next
LDA #$00
STA $0609,X
JMP bullet_next
bullet_flying:
DEC $0600,X
CLC
LDA $0601,X
ADC $0605,X
STA $0601,X
LDA $0602,X
ADC $0606,X
STA $0602,X
CLC
LDA $0603,X
ADC $0607,X
STA $0603,X
LDA $0604,X
ADC $0608,X
CMP #$F0
BCC bullet_y_ok
LDY $0608,X
BMI bullet_y_negative
SEC
SBC #$F0
JMP bullet_y_ok
bullet_y_negative:
CLC
ADC #$F0
bullet_y_ok:
STA $0604,X
bullet_next:
TXA
CLC
ADC #$10
TAX
CPX #$40
BEQ bullets_done
JMP bullet_loop
bullets_done:
RTS
asteroids:
''')
for page in (0x0300,0x0400,0x0500):
 emit(f'''LDX #$00
asteroid_loop{page:04x}:
LDA ${page+10:04X},X
BEQ asteroid_grace_done{page:04x}
DEC ${page+10:04X},X
asteroid_grace_done{page:04x}:
CLC
LDA ${page+0:04X},X
ADC ${page+4:04X},X
STA ${page+0:04X},X
LDA ${page+1:04X},X
ADC ${page+5:04X},X
STA ${page+1:04X},X
CLC
LDA ${page+2:04X},X
ADC ${page+6:04X},X
STA ${page+2:04X},X
LDA ${page+3:04X},X
ADC ${page+7:04X},X
CMP #$F0
BCC asteroid_y_ok{page:04x}
LDY ${page+7:04X},X
BMI asteroid_y_negative{page:04x}
SEC
SBC #$F0
JMP asteroid_y_ok{page:04x}
asteroid_y_negative{page:04x}:
CLC
ADC #$F0
asteroid_y_ok{page:04x}:
STA ${page+3:04X},X
TXA
CLC
ADC #$10
TAX
BNE asteroid_loop{page:04x}''')
emit('''RTS
collisions:
LDX #$00
collision_bullet:
LDA $0600,X
BEQ collision_bullet_inactive
LDA $0609,X
BEQ collision_bullet_live
collision_bullet_inactive:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE collision_bullet_continue_inactive
JMP collision_done
collision_bullet_continue_inactive:
JMP collision_bullet
collision_bullet_live:
STX $22
LDA $0602,X
STA $23
LDA $0604,X
STA $24
LDA $060A,X
STA $27
''')
for page in (0x0300,0x0400,0x0500):
 emit(f'''LDX #$00
collision_rocks_{page:04x}:
LDA ${page+8:04X},X
BNE collision_rock_active_{page:04x}
JMP collision_rock_next_{page:04x}
collision_rock_active_{page:04x}:
STA $26
LDA ${page+10:04X},X
BEQ collision_rock_ready_{page:04x}
JMP collision_rock_next_{page:04x}
collision_rock_ready_{page:04x}:
LDA $26
CMP #$01
BEQ collision_width_large_{page:04x}
CMP #$02
BEQ collision_width_medium_{page:04x}
LDA #$08
JMP collision_width_ready_{page:04x}
collision_width_large_{page:04x}:
LDA #$10
JMP collision_width_ready_{page:04x}
collision_width_medium_{page:04x}:
LDA #$0C
collision_width_ready_{page:04x}:
STA $2B
LDA $23
SEC
SBC ${page+1:04X},X
CMP $2B
BCC collision_x_ok_{page:04x}
CMP #$FD
BCS collision_x_ok_{page:04x}
JMP collision_rock_next_{page:04x}
collision_x_ok_{page:04x}:
LDA $24
SEC
SBC ${page+3:04X},X
BCS collision_y_delta_{page:04x}
SEC
SBC #$10
collision_y_delta_{page:04x}:
CMP $2B
BCC collision_y_ok_{page:04x}
CMP #$ED
BCS collision_y_ok_{page:04x}
JMP collision_rock_next_{page:04x}
collision_y_ok_{page:04x}:
JSR collision_explode
TXA
STA $45
LDA #${page >> 8:02X}
STA $46
LDA $26
CMP #$01
BEQ collision_large_{page:04x}
CMP #$02
BEQ collision_medium_{page:04x}
LDY #$08
LDA #$00
STA ($45),Y
INC $39
LDA #$64
JSR score_add
JMP collision_next_bullet
collision_large_{page:04x}:
''')
 if True:
  emit('''JSR spawn_mediums_generic
LDA #$19
JSR score_add
JMP collision_next_bullet''')
 emit(f'''collision_medium_{page:04x}:
''')
 if True:
  emit('''JSR spawn_smalls_generic
LDA #$32
JSR score_add
JMP collision_next_bullet''')
 emit(f'''collision_rock_next_{page:04x}:
TXA
CLC
ADC #$10
TAX
BNE collision_rocks_continue_{page:04x}
JMP collision_rocks_done_{page:04x}
collision_rocks_continue_{page:04x}:
JMP collision_rocks_{page:04x}
collision_rocks_done_{page:04x}:''')
emit('''collision_next_bullet:
LDX $22
TXA
CLC
ADC #$10
TAX
CPX #$40
BEQ collision_done
JMP collision_bullet
collision_done:
RTS
collision_explode:
LDY $22
LDA #$0F
STA $0600,Y
LDA #$01
STA $0609,Y
LDA #$00
STA $0605,Y
STA $0606,Y
STA $0607,Y
STA $0608,Y
RTS
score_add:
STA $25
CLC
LDA $30
ADC $25
STA $30
LDA $31
ADC #$00
STA $31
LDA $32
ADC #$00
STA $32
score_add_loop:
JSR score_increment
DEC $25
BNE score_add_loop
LDA $32
CMP $3C
BCC score_check_done
BNE score_extra_life
LDA $31
CMP $3B
BCC score_check_done
BNE score_extra_life
LDA $30
CMP $3A
BCC score_check_done
score_extra_life:
INC $3D
CLC
LDA $3A
ADC #$20
STA $3A
LDA $3B
ADC #$4E
STA $3B
LDA $3C
ADC #$00
STA $3C
score_check_done:
RTS
score_increment:
INC $38
LDA $38
CMP #$0A
BCC score_inc_done
LDA #$00
STA $38
INC $37
LDA $37
CMP #$0A
BCC score_inc_done
LDA #$00
STA $37
INC $36
LDA $36
CMP #$0A
BCC score_inc_done
LDA #$00
STA $36
INC $35
LDA $35
CMP #$0A
BCC score_inc_done
LDA #$00
STA $35
INC $34
LDA $34
CMP #$0A
BCC score_inc_done
LDA #$00
STA $34
INC $33
LDA $33
CMP #$0A
BCC score_inc_done
LDA #$00
STA $33
score_inc_done:
RTS
spawn_mediums_generic:
LDA #$02
STA $2D
JMP spawn_children_generic
spawn_smalls_generic:
LDA #$03
STA $2D
spawn_children_generic:
LDY #$01
LDA ($45),Y
STA $47
LDY #$03
LDA ($45),Y
STA $48
JSR allocate_asteroid_record
LDA $43
STA $49
LDA $44
STA $4A
LDA $45
STA $43
LDA $46
STA $44
JSR fragment_clockwise
STA $2E
JSR write_fragment
LDA $49
STA $43
LDA $4A
STA $44
JSR fragment_counterclockwise
STA $2E
JSR write_fragment
RTS
allocate_asteroid_record:
LDX #$00
allocate_page3:
LDA $0308,X
BEQ allocate_found3
TXA
CLC
ADC #$10
TAX
BNE allocate_page3
LDX #$00
allocate_page4:
LDA $0408,X
BEQ allocate_found4
TXA
CLC
ADC #$10
TAX
BNE allocate_page4
LDX #$00
allocate_page5:
LDA $0508,X
BEQ allocate_found5
TXA
CLC
ADC #$10
TAX
BNE allocate_page5
RTS
allocate_found3:
STX $43
LDA #$03
STA $44
RTS
allocate_found4:
STX $43
LDA #$04
STA $44
RTS
allocate_found5:
STX $43
LDA #$05
STA $44
RTS
write_fragment:
LDY #$00
LDA #$00
STA ($43),Y
LDY #$01
LDX $2E
LDA $47
CLC
ADC spawnxoff,X
STA ($43),Y
LDY #$02
LDA #$00
STA ($43),Y
LDY #$03
LDA $48
CLC
ADC spawnyoff,X
CMP #$F0
BCC fragment_y_ok
SEC
SBC #$F0
fragment_y_ok:
STA ($43),Y
LDA $2D
CMP #$02
BEQ write_medium_velocity
LDX $2E
LDY #$04
LDA sxlo,X
STA ($43),Y
LDY #$05
LDA sxhi,X
STA ($43),Y
LDY #$06
LDA sylo,X
STA ($43),Y
LDY #$07
LDA syhi,X
STA ($43),Y
JMP write_fragment_finish
write_medium_velocity:
LDX $2E
LDY #$04
LDA mxlo,X
STA ($43),Y
LDY #$05
LDA mxhi,X
STA ($43),Y
LDY #$06
LDA mylo,X
STA ($43),Y
LDY #$07
LDA myhi,X
STA ($43),Y
write_fragment_finish:
LDY #$08
LDA $2D
STA ($43),Y
LDY #$09
LDA $2E
STA ($43),Y
LDY #$0A
LDA #$03
STA ($43),Y
RTS
random:
LDA $2F
ASL A
BCC random_no_xor
EOR #$1D
random_no_xor:
STA $2F
RTS
random_13:
JSR random
AND #$0F
CMP #$0D
BCC random_13_done
SEC
SBC #$0D
random_13_done:
RTS
normalize_heading:
BMI normalize_negative
CMP #$30
BCC normalize_done
SEC
SBC #$30
RTS
normalize_negative:
CLC
ADC #$30
normalize_done:
RTS
fragment_clockwise:
JSR random_13
CLC
ADC $27
JMP normalize_heading
fragment_counterclockwise:
JSR random_13
STA $28
LDA $27
SEC
SBC $28
JMP normalize_heading
large_velocity_page0:
STA $0309,X
TAY
LDA lxlo,Y
STA $0304,X
LDA lxhi,Y
STA $0305,X
LDA lylo,Y
STA $0306,X
LDA lyhi,Y
STA $0307,X
RTS
medium_velocity_page0:
STA $0309,Y
TAX
LDA mxlo,X
STA $0304,Y
LDA mxhi,X
STA $0305,Y
LDA mylo,X
STA $0306,Y
LDA myhi,X
STA $0307,Y
LDA $0301,Y
CLC
ADC spawnxoff,X
STA $0301,Y
LDA $0303,Y
CLC
ADC spawnyoff,X
CMP #$F0
BCC medium_spawn_y_ok
SEC
SBC #$F0
medium_spawn_y_ok:
STA $0303,Y
RTS
small_velocity_page0:
STA $0309,Y
TAX
LDA sxlo,X
STA $0304,Y
LDA sxhi,X
STA $0305,Y
LDA sylo,X
STA $0306,Y
LDA syhi,X
STA $0307,Y
LDA $0301,Y
CLC
ADC spawnxoff,X
STA $0301,Y
LDA $0303,Y
CLC
ADC spawnyoff,X
CMP #$F0
BCC small0_spawn_y_ok
SEC
SBC #$F0
small0_spawn_y_ok:
STA $0303,Y
RTS
small_velocity_page1:
STA $0409,Y
TAX
LDA sxlo,X
STA $0404,Y
LDA sxhi,X
STA $0405,Y
LDA sylo,X
STA $0406,Y
LDA syhi,X
STA $0407,Y
LDA $0401,Y
CLC
ADC spawnxoff,X
STA $0401,Y
LDA $0403,Y
CLC
ADC spawnyoff,X
CMP #$F0
BCC small1_spawn_y_ok
SEC
SBC #$F0
small1_spawn_y_ok:
STA $0403,Y
RTS
wave_tick:
LDA $06
BEQ wave_return
LDA $41
BNE wave_cancel
LDX #$00
wave_scan:
LDA $0308,X
ORA $0408,X
ORA $0508,X
BNE wave_cancel
TXA
CLC
ADC #$10
TAX
BNE wave_scan
LDA $40
BNE wave_countdown
LDA #$F0
STA $40
RTS
wave_countdown:
DEC $40
BNE wave_return
JSR next_wave
RTS
wave_cancel:
LDA #$00
STA $40
wave_return:
RTS
next_wave:
LDA $3F
CMP #$0C
BCS wave_count_capped
INC $3F
wave_count_capped:
LDA #$00
STA $03
STA $04
STA $05
STA $08
STA $39
STA $40
LDX #$07
wave_reset_ship:
STA $10,X
DEX
BPL wave_reset_ship
LDX #$3F
wave_clear_projectiles:
STA $0600,X
DEX
BPL wave_clear_projectiles
LDA #$80
STA $11
LDA #$78
STA $13
LDA #$05
STA $07
JSR set_game_rocks
RTS
set_game_rocks:
LDA $3F
BNE set_game_count_ready
LDA #$04
STA $3F
set_game_count_ready:
ASL A
ASL A
ASL A
ASL A
STA $2C
LDA #$00
LDX #$00
set_game_clear_records:
STA $0300,X
STA $0400,X
STA $0500,X
INX
BNE set_game_clear_records
LDX #$00
set_game_rock_loop:
JSR random
AND #$03
BEQ spawn_left
CMP #$01
BEQ spawn_right
CMP #$02
BEQ spawn_top
spawn_bottom:
JSR random
AND #$DF
CLC
ADC #$10
STA $0301,X
LDA #$E0
STA $0303,X
LDA #$00
JMP spawn_large_heading
spawn_top:
JSR random
AND #$DF
CLC
ADC #$10
STA $0301,X
LDA #$20
STA $0303,X
LDA #$18
JMP spawn_large_heading
spawn_left:
LDA #$00
STA $0301,X
JSR random
AND #$BF
CLC
ADC #$20
STA $0303,X
LDA #$0C
JMP spawn_large_heading
spawn_right:
LDA #$F0
STA $0301,X
JSR random
AND #$BF
CLC
ADC #$20
STA $0303,X
LDA #$24
spawn_large_heading:
STA $28
JSR random_13
CLC
ADC $28
SEC
SBC #$06
JSR normalize_heading
STA $27
LDY #$08
LDA #$01
STA $0308,X
LDY #$0A
LDA #$00
STA $030A,X
LDA $27
JSR large_velocity_page0
TXA
CLC
ADC #$10
TAX
CPX $2C
BEQ set_game_rocks_done
JMP set_game_rock_loop
set_game_rocks_done:
RTS
render:
LDX #$00
LDA #$F8
hide:
STA $0200,X
INX
BNE hide
LDA $06
BNE render_game
JMP render_title
render_game:
LDA $13
SEC
SBC #$01
STA $0200
LDX $03
LDA drawing,X
STA $0201
LDA $08
BEQ ship_normal_palette
LSR A
LSR A
AND #$03
JMP ship_palette_done
ship_normal_palette:
LDA #$00
ship_palette_done:
STA $0202
LDA $11
STA $0203
LDX #$00
LDY #$04
render_bullet:
LDA $0600,X
BEQ hide_bullet
LDA $0609,X
BEQ render_normal_bullet
STX $20
LDA $0600,X
SEC
SBC #$01
TAX
LDA explosion_drawing,X
LDX $20
JMP render_bullet_tile_ready
render_normal_bullet:
LDA #$11
render_bullet_tile_ready:
STA $0201,Y
LDA $0604,X
SEC
SBC #$01
STA $0200,Y
LDA #$00
STA $0202,Y
LDA $0602,X
STA $0203,Y
JMP advance_bullet_oam
hide_bullet:
LDA #$F8
STA $0200,Y
advance_bullet_oam:
INY
INY
INY
INY
render_next:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE render_bullet
JSR render_asteroids
RTS
render_asteroids:
LDY #$14
''')
for page in (0x0300,0x0400,0x0500):
 emit(f'''LDX #$00
render_rocks_{page:04x}:
LDA ${page+8:04X},X
BNE render_rock_active_{page:04x}
JMP render_rock_next_{page:04x}
render_rock_active_{page:04x}:
CMP #$01
BEQ render_large_{page:04x}
CMP #$02
BEQ render_medium_{page:04x}
JMP render_small_{page:04x}
render_large_{page:04x}:
LDA ${page+3:04X},X
SEC
SBC #$01
STA $0200,Y
STA $0204,Y
CLC
ADC #$08
CMP #$F0
BCC render_large_y_ok_{page:04x}
SEC
SBC #$F0
render_large_y_ok_{page:04x}:
STA $0208,Y
STA $020C,Y
LDA #$13
STA $0201,Y
LDA #$14
STA $0205,Y
LDA #$15
STA $0209,Y
LDA #$16
STA $020D,Y
JMP render_big_common_{page:04x}
render_medium_{page:04x}:
LDA ${page+3:04X},X
SEC
SBC #$01
STA $0200,Y
STA $0204,Y
CLC
ADC #$08
CMP #$F0
BCC render_medium_y_ok_{page:04x}
SEC
SBC #$F0
render_medium_y_ok_{page:04x}:
STA $0208,Y
STA $020C,Y
LDA #$17
STA $0201,Y
LDA #$18
STA $0205,Y
LDA #$19
STA $0209,Y
LDA #$1A
STA $020D,Y
render_big_common_{page:04x}:
LDA #$01
STA $0202,Y
STA $0206,Y
STA $020A,Y
STA $020E,Y
LDA ${page+1:04X},X
STA $0203,Y
STA $020B,Y
CLC
ADC #$08
STA $0207,Y
STA $020F,Y
TYA
CLC
ADC #$10
TAY
JMP render_rock_next_{page:04x}
render_small_{page:04x}:
LDA ${page+3:04X},X
SEC
SBC #$01
STA $0200,Y
LDA #$12
STA $0201,Y
LDA #$01
STA $0202,Y
LDA ${page+1:04X},X
STA $0203,Y
TYA
CLC
ADC #$04
TAY
render_rock_next_{page:04x}:
TXA
CLC
ADC #$10
TAX
BNE render_rocks_continue_{page:04x}
JMP render_rocks_done_{page:04x}
render_rocks_continue_{page:04x}:
JMP render_rocks_{page:04x}
render_rocks_done_{page:04x}:''')
emit('''RTS
render_title:
LDX #$00
LDY #$00
render_title_asteroid:
LDA $0303,X
SEC
SBC #$01
STA $0200,Y
LDA #$12
STA $0201,Y
LDA #$01
STA $0202,Y
LDA $0301,X
STA $0203,Y
INY
INY
INY
INY
TXA
CLC
ADC #$10
TAX
CPX #$80
BNE render_title_asteroid
RTS
''')
data={}
# Background palettes: white text, then the four-color title logo. Sprite palettes retain P1 and asteroid colors.
data['palette']=[0x0f,0x30,0x0f,0x0f, 0x0f,0x16,0x28,0x08, 0x0f,0x0f,0x0f,0x0f, 0x0f,0x0f,0x0f,0x0f,
                 0x0f,0x30,0x24,0x0f, 0x0f,0x37,0x27,0x17, 0x0f,0x30,0x16,0x2a, 0x0f,0x30,0x16,0x2a]
data['drawing']=[((h+1)//3)%16+1 for h in range(48)]
data['rainbow_offsets']=[6,2,46,42]
# Four root records, eight medium records, sixteen UNIQUE small records.
# Medium indices 4..11 map to $03C0,$03E0,$0400,...,$04A0.
# Explicit page/offset tables avoid losing the carry when doubling an offset.
data['small_child_low']=[0]*4+[0xC0,0xE0,0,0x20,0x40,0x60,0x80,0xA0]+[0]*4
data['small_child_page']=[0]*4+[3,3,4,4,4,4,4,4]+[0]*4
data['explosion_drawing']=[0x1F,0x1F,0x1F,0x1E,0x1E,0x1E,0x1D,0x1D,0x1D,0x1C,0x1C,0x1C,0x1B,0x1B,0x1B]
# One title nametable: centered 192x32 logo and the initial Arcade-mode prompt.
title_nt=bytearray(1024)
def title_palette(tx,ty,palette):
 i=960+(ty//4)*8+(tx//4)
 shift=((ty//2)%2)*4+((tx//2)%2)*2
 title_nt[i] |= palette << shift
for block in range(6):
 for ty in range(4):
  for tx in range(4):
   x,y=4+block*4+tx,5+ty
   title_nt[y*32+x]=1+block*16+ty*4+tx
   title_palette(x,y,1)
def title_glyph(ch):
 if ch==' ': return 0
 if ch==':': return 0x8A
 if ch=='©': return 0x89
 if '0'<=ch<='9': return 0x7B+ord(ch)-ord('0')
 return 0x61+ord(ch)-ord('A')
def title_text(row,text):
 x=(32-len(text))//2
 for ch in text:
  title_nt[row*32+x]=title_glyph(ch)
  x+=1
title_text(11,'PRESS SELECT TO')
title_text(13,'CHOOSE GAME MODE:')
title_text(15,'ARCADE')
title_text(18,'PRESS START TO BEGIN')
title_text(25,'©2026 ANTHONY VOLPE')
data['title_nt0']=title_nt[:256]
data['title_nt1']=title_nt[256:512]
data['title_nt2']=title_nt[512:768]
data['title_nt3']=title_nt[768:]
hud_line=bytearray(32)
for x,ch in enumerate('SCORE:000000   SUPER:5   LIVES:3'):
 hud_line[x]=title_glyph(ch)
data['hud_line']=hud_line
# Forty-eight reserved asteroid records: sixteen directions, three per direction.
asteroid_records=[]
for i in range(48):
 h=(i//3)*3
 vx=round(128*math.sin(h*math.tau/48)) & 65535
 vy=round(-128*math.cos(h*math.tau/48)) & 65535
 x=(19+i*73)%256
 y=(11+i*47)%240
 asteroid_records += [0,x,0,y,vx&255,vx>>8,vy&255,vy>>8]+[0]*8
# Title-mode positions for the eight visible rocks: safely around, not through, the logo.
for i,(x,y) in enumerate([(15,14),(225,24),(10,105),(240,125),(25,205),(220,210),(76,184),(175,174)]):
 asteroid_records[i*16+1]=x
 asteroid_records[i*16+3]=y
# Gameplay begins with only these four active large rocks.  The remaining
# records are reserved for their medium/small descendants and later waves.
for i in range(4):
 asteroid_records[i*16+8]=1
data['asteroid_init0']=asteroid_records[:256]
data['asteroid_init1']=asteroid_records[256:]
data['asteroid_init2']=asteroid_records[512:]
for prefix,scale in [('a',12),('b',768)]:
 for axis,fn in [('x',lambda a:math.sin(a)),('y',lambda a:-math.cos(a))]:
  vals=[round(scale*fn(h*math.tau/48))&65535 for h in range(48)]
  data[prefix+axis+'lo']=[x&255 for x in vals];data[prefix+axis+'hi']=[x>>8 for x in vals]
# Level 1 asteroid speeds: large 1.00x, medium 1.25x, small 1.50x.
# $3E starts at 16 (1.00x) and is reserved for the +1/16 per-level multiplier.
for prefix,scale in [('l',128),('m',160),('s',192)]:
 for axis,fn in [('x',lambda a:math.sin(a)),('y',lambda a:-math.cos(a))]:
  vals=[round(scale*fn(h*math.tau/48))&65535 for h in range(48)]
  data[prefix+axis+'lo']=[x&255 for x in vals];data[prefix+axis+'hi']=[x>>8 for x in vals]
# Initial split separation: eight pixels in each fragment's assigned direction.
for axis,fn in [('spawnxoff',lambda a:math.sin(a)),('spawnyoff',lambda a:-math.cos(a))]:
 data[axis]=[round(8*fn(h*math.tau/48))&255 for h in range(48)]
asm=Assembler(MPU()); labels={};pc=0x8000
branches={'BPL','BMI','BEQ','BNE','BCC','BCS','BVC','BVS'}
def resolve(line,first=False):
 def sub(m):
  s=m.group();return f'${labels.get(s,0x8000):04X}'
 op,_,arg=line.partition(' ')
 if arg and not arg.startswith(('#','$')) and arg!='A': arg=re.sub(r'^[a-z][a-z_0-9]*',sub,arg)
 if first and op in branches: arg=f'${pc+2:04X}'
 return op+(' '+arg if arg else '')
for line in lines:
 if line.endswith(':'):labels[line[:-1]]=pc
 else:pc+=len(asm.assemble(resolve(line,True),pc))
for k,v in data.items():labels[k]=pc;pc+=len(v)
assert pc<0xFFFA
rom=bytearray([0xea]*32768);pc=0x8000
for line in lines:
 if line.endswith(':'):continue
 resolved=resolve(line)
 if line.split()[0] in branches:
  target=int(resolved.split('$')[1],16);assert -128<=target-(pc+2)<=127,(line,pc,target)
 b=asm.assemble(resolved,pc);rom[pc-0x8000:pc-0x8000+len(b)]=b;pc+=len(b)
for k,v in data.items():rom[labels[k]-0x8000:labels[k]-0x8000+len(v)]=bytes(v)
for i,k in enumerate(['nmi','reset','irq']):rom[0x7ffa+i*2:0x7ffc+i*2]=labels[k].to_bytes(2,'little')
# Approved source pixels: 0 transparent, 1 white, 2 purple.
masters=[['00011000','00011000','00111100','00111100','01122110','01122110','11111111','10100101'],['00000100','00001100','00011100','00111100','01122110','11122110','10111110','00100101'],['00000011','00011111','11111110','01122110','11122110','10111110','00011100','00110100']]
masters=[[[int(c) for c in row] for row in a] for a in masters]
def rotate(a):return [list(r) for r in zip(*a[::-1])]
# 67.5 degrees = clockwise quarter turn of mirrored 22.5 degree master.
quadrant=masters+[rotate([row[::-1] for row in masters[1]])]
ships=[]
for q in range(4):
 for a in quadrant:
  for _ in range(q):a=rotate(a)
  ships.append(a)
chrdata=bytearray(8192)
def tile(index,a):
 chrdata[index*16:index*16+16]=bytes(sum(( ((a[y][x]>>bit)&1)<<(7-x) for x in range(8)),0) for bit in range(2) for y in range(8))
# Background table $0000: supplied six-part logo ($01-$60) and 44 supplied character tiles ($61-$8C).
logo_colors={(15,5,0):0,(199,0,1):1,(250,242,0):2,(127,139,0):3}
for block in range(6):
 im=Image.open(P.parent/'upload'/f'{block+1:02d}-Logo-{block+1}.png').convert('RGB')
 for ty in range(4):
  for tx in range(4):
   pixels=[[logo_colors[im.getpixel((tx*8+x,ty*8+y))] for x in range(8)] for y in range(8)]
   tile(1+block*16+ty*4+tx,pixels)
# Supplied native character source: each PNG is an exact 9x enlargement of an
# 8x8 tile.  Sampling a pixel from each 9x9 cell restores the original glyph.
glyph_names=list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')+list('0123456789')+[
 'COMMA','PERIOD','QUESTION MARK','EXCLAMATION POINT','COPYRIGHT SYMBOL',
 'COLON','SEMICOLON','UNDERSCORE']
with zipfile.ZipFile(P.parent/'upload'/'01-Asteroids-Character-Set.zip') as z:
 for n,name in enumerate(glyph_names):
  with z.open(f'Asteroids Character_{name}.png') as f:
   im=Image.open(f).convert('RGB')
   assert im.size==(72,72), (name,im.size)
   pixels=[[1 if im.getpixel((x*9+4,y*9+4))[0]>127 else 0 for x in range(8)] for y in range(8)]
   tile(0x61+n,pixels)
# Sprite table $1000: ship, projectile, and asteroid graphics.
for i,a in enumerate(ships):tile(0x100+i+1,a)
shot=[[0]*8 for _ in range(8)]
for y,row in enumerate(['0220','2112','2112','0220']):
 for x,c in enumerate(row):shot[y+2][x+2]=int(c)
tile(0x100+17,shot)
# Approved small asteroid: 0 transparent; values 1/2/3 map to $37/$27/$17.
rock=['00000000','00111200','01122220','01222230','01222230','02222330','00333300','00000000']
tile(0x100+18,[[int(c) for c in row] for row in rock])
# Approved large asteroid, split into its four native 8x8 sprite tiles.
large=['0000011111100000','0001122222222000','0012222222222200','0012222222222200',
       '0122222222222220','1222222222222220','1222222222222220','0222222222222222',
       '2222222222222222','2222222222222222','0222222222222223','2222222222222230',
       '0022222222223300','0000222222230000','0000002222300000','0000000333000000']
for ty in range(2):
 for tx in range(2):
  tile(0x100+19+ty*2+tx,[[int(large[ty*8+y][tx*8+x]) for x in range(8)] for y in range(8)])
# Approved medium asteroid, centered in a 16x16 transparent sprite box.
medium_rows=['000001100000','000111222000','000122222200','001222222200',
             '012222222220','122222222222','222222222223','022222222230',
             '000222222300','000222223000','000022230000','000033300000']
medium=['0'*16,'0'*16]+['00'+r+'00' for r in medium_rows]+['0'*16,'0'*16]
for ty in range(2):
 for tx in range(2):
  tile(0x100+23+ty*2+tx,[[int(medium[ty*8+y][tx*8+x]) for x in range(8)] for y in range(8)])
# Five approved explosion frames.  Each is displayed for three refreshes.
explosions=[['00000000','00000000','00112100','00211100','00121200','00212100','00000000','00000000'],
 ['00000000','01020100','02112120','00211200','01212110','00121200','01121010','00000000'],
 ['10100101','01211210','11212110','11021200','00112101','12012100','01211210','10100101'],
 ['10200102','01212010','21020120','12001000','00210201','20010200','01021020','10200102'],
 ['20000200','02020020','02000200','20002000','00020002','00000000','02002000','20000200']]
for i,frame in enumerate(explosions):
 tile(0x100+27+i,[[int(c) for c in row] for row in frame])
output=P/'asteroids_nes_v15_wave_transition.nes'
output.write_bytes(b'NES\x1a'+bytes([2,1,0,0])+bytes(8)+rom+chrdata)
(P/'prototype_v15.asm').write_text('\n'.join(lines)+'\n\n'+'\n'.join(k+':\n.byte '+','.join(f'${n:02X}' for n in v) for k,v in data.items()))
(P/'symbols_v15.json').write_text(json.dumps(labels,indent=2))
print(output,output.stat().st_size,'bytes; code/tables end',hex(pc))
