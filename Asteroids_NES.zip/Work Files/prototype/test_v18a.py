"""Run the V18 regression suite with small-only drop expectations."""
from pathlib import Path
P = Path(__file__).parent
source = (P/'test_v18.py').read_text()
source = source.replace('symbols_v18.json', 'symbols_v18a.json').replace('asteroids_nes_v18_pickups.nes', 'asteroids_nes_v18a_small_asteroid_pickups.nes')
source = source.replace('kind=1+kill%3', 'kind=3')
# Interleave excluded kills both before and after every eligible small kill.
source = source.replace('    clear()\n    addr=', '''    for excluded in (1, 2):
        clear()
        m[0x300:0x310]=[0,60,0,70,0,0,0,0,excluded,12,0,0,0,0,0,0]
        m[0x600:0x640]=[0]*64
        m[0x600:0x610]=[47,0,64,0,74,0,0,0,0,0,12,0,0,0,0,0]
        parity,sequence=m[0x670],m[0x671]
        old=score()
        call('collisions')
        assert score()-old=={1:25,2:50}[excluded]
        assert (m[0x670],m[0x671])==(parity,sequence)
        assert not active()
    clear()
    addr=''')
source = source.replace("call('pickup_drop')", "m[0x26]=3\ncall('pickup_drop')")
source = source.replace('every-second kill across all sizes/pages', 'every-second small kill; large/medium excluded without changing parity')
exec(compile(source, str(P/'test_v18.py'), 'exec'))
