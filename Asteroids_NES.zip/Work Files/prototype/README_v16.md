# Asteroids NES V16 — bounded OAM and asteroid rotation

V15 is preserved as the source baseline. `build_v16.py` replaces only the renderer and adds its two pointer tables. No movement, collision, splitting, scoring, wave, or player-invincibility rules change.

## Display allocation

| OAM entries | Use |
|---|---|
| 0 | Player One ship |
| 1–4 | Player shots or their existing hit explosions |
| 5–9 | Hidden reserve: one 12x12 UFO (four tiles) and its projectile |
| 10–63 | 54-tile rotating asteroid pool; future pickups share this budget |

UFO and pickup gameplay are not added in V16. Their future render integration must preserve these bounds. A future separate explosion pool would also require an explicit budget; today's explosions reuse projectile slots.

The start record advances by five modulo 48 each rendered gameplay frame. Every record therefore becomes first once per 48 renders, independent of whether the pool is full. Each large/medium drawing requires four available slots before any of its tiles are written. Small drawings require one. Records skipped for capacity remain active in gameplay. No object records are rearranged.

The previous renderer could wrap its byte-sized OAM cursor into protected entries or write a multi-tile object's tail into the asteroid record page. V16's remaining-slot counter prevents both paths. It does not remove the NES eight-sprites-per-scanline limit: lower-priority asteroids may flicker or lose some scanline tiles in dense clusters. The ship and four shots precede all asteroid tiles. A future UFO could itself encounter scanline pressure from these higher-priority objects; OAM reservation alone cannot guarantee every protected object appears simultaneously on a crowded line.

## Build and tests

From the extracted package root:

    python3 -m pip install py65 pillow
    python3 prototype/build_v16.py
    python3 prototype/test_v16.py
    python3 prototype/test_full_wave.py 16 100 4
    python3 prototype/test_full_wave.py 16 100 12

Passed: V15 actual NMI/main-loop transition regressions; 48 rotation starts in all-large, all-medium, all-small, mixed, and empty scenes; unchanged gameplay-memory canaries and protected OAM entries; whole-object OAM admission; simplified eight-sprite scanline fairness; 100 four-root waves (2100 points) and 100 twelve-root waves (6300 points). Peak isolated renderer cost in these stress scenes: 10766 CPU cycles.

Tests execute assembled 6502 code but are not full PPU emulation or hardware timing certification. Play-test level 6 and beyond in OpenEMU: expected result is asteroid flicker under crowding, with no corrupted positions or disappearing ship/shots. Start from a fresh ROM boot, not a V15 save state.
