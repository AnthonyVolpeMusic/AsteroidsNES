from pathlib import Path
source=(Path(__file__).parent/'test_full_wave.py').read_text()
source=source.replace("VERSION=sys.argv[1] if len(sys.argv)>1 else '13d'", "VERSION='18b'")
source=source.replace("ROOTS=int(sys.argv[3]) if len(sys.argv)>3 else 4", "ROOTS=int(sys.argv[2]) if len(sys.argv)>2 else 4")
source=source.replace("n=int(sys.argv[2]) if len(sys.argv)>2 else 100", "n=int(sys.argv[1]) if len(sys.argv)>1 else 100")
exec(compile(source, str(Path(__file__).parent/'test_full_wave.py'), 'exec'))
