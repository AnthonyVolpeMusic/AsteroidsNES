"""V35: progressive lives, static stars, unconditional slower retreat."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v34.py').read_text(),str(P/'build_v34.py'),'exec'))
marker='asm=Assembler(MPU()); labels={};pc=0x8000'
assert source.count(marker)==1
source=source.replace(marker,"exec(compile((P/'patch_v35.py').read_text(),str(P/'patch_v35.py'),'exec'))\n"+marker)
art='''
# Ten one-pixel stars. Background-only CHR, after the supplied font.
for n,(x,y,color) in enumerate([(1,2,1),(6,5,2),(3,7,3),(7,1,2),(2,4,3),(5,0,1),(0,6,2),(4,3,3),(6,7,2),(3,1,3)]):
 pixels=[[0]*8 for _ in range(8)]
 pixels[y][x]=color
 tile(0x90+n,pixels)
'''
source=source.replace("output=P/'asteroids_nes_v34_adaptive_fps.nes'",art+"\noutput=P/'asteroids_nes_v35_starfield.nes'")
source=source.replace('symbols_v34.json','symbols_v35.json').replace('prototype_v34.asm','prototype_v35.asm')
exec(compile(source,str(P/'build_v15.py'),'exec'))
