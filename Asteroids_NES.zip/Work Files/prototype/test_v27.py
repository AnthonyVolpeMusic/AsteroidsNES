"""Execute real ROM instructions; no synthesized audio or listening claim."""
from pathlib import Path
P=Path(__file__).parent
previous=(P/'test_v26.py').read_text().replace('v26','v27').replace('event_sfx','ship_sfx')
exec(compile(previous,str(P/'test_v26.py'),'exec'))

for effect,duration in ((7,25),(8,10)):
    fresh26();call('pulse2_start26',effect)
    values=[sample()]
    for _ in range(duration-1):
        call('pulse2_tick26');values.append(sample())
        assert m[0x87]==effect
    call('pulse2_tick26');assert not m[0x87] and not m.enabled&2
    if effect==7:
        assert values==[(timer(n),v) for n in range(65,70) for v in (15,15,15,0,0)]
    else:
        assert values[0]==(timer(84),15) and values[-1]==(timer(72),15)
        assert all(a[0]<b[0] for a,b in zip(values,values[1:]))
for active in range(1,9):
    for requested in (7,8):
        fresh26();call('pulse2_start26',active);call('pulse2_tick26')
        before=m[0x87:0x8b];call('pulse2_start26',requested)
        assert m[0x87:0x8b]==before
for active in (7,8):
    for requested in range(1,7):
        fresh26();call('pulse2_start26',active);call('pulse2_start26',requested)
        assert m[0x87]==requested
print('PASS shield 25 frames, flip 10 frames, all idle-only and interruption combinations')
fresh26();m[0x8c]=1
call('sfx_shot_start25');call('pulse2_start26',7);call('asteroid_pulse24')
call('thrust_audio27')
assert m.enabled==15 and m.length[3] and m[0x400c]==0x33 and m[0x400e]==11
for period in (12,13,14,15):
    call('sfx_noise_start25',period)
    for _ in range(29):
        call('sfx_tick25');before=(m[0x400c],m[0x400e],m.enabled)
        call('thrust_audio27');assert before==(m[0x400c],m[0x400e],m.enabled)
    call('sfx_tick25');call('thrust_audio27')
    assert m[0x400c]==0x33 and m[0x400e]==11 and m.length[3]
m[0x8c]=0;call('thrust_audio27');assert not m.enabled&8
for state in (1,2,3):
    m[0x8c]=1;m[0x677]=state;call('thrust_audio27');assert not m.enabled&8
m[0x677]=0;m[6]=0;call('thrust_audio27');assert not m.enabled&8
print('PASS quiet thrust, explosion override/resumption, release, death and menu silence')

# Actual input handling and full NMI/main updates, avoiding hand-called hooks.
S=json.loads((P/'symbols_v27.json').read_text())
m=FrameBus();m[0x8000:]=(P/'asteroids_nes_v27_ship_sfx.nes').read_bytes()[16:32784]
c=MPU(memory=m,pc=S['reset'])
for _ in range(100000):
    c.step()
    if c.pc==S['main']:break
else:raise AssertionError('boot timeout')
frame(0x10)
m[0x300:0x600]=[0]*0x300
frame(0x08);assert m[0x8c]==1 and m[0x400e]==11 and m.enabled&8
frame();assert not m[0x8c] and not m.enabled&8
frame(0x04);assert m[3]==24 and m[0x87]==8
frame(0x04);assert m[3]==24 and m[0x89]==9 # held Down never retriggers
for _ in range(9):frame()
assert not m[0x87]
frame(0x40);assert m[7]==4 and m[8] and m[0x87]==7
frame();remaining=m[0x89]
frame(0x40);assert m[7]==4 and m[0x89]==remaining-1 # active shield: no restart
for _ in range(25):frame()
frame(0x44);assert m[7]==3 and not m[0x87] and not m[0x8c] # B+Down stop
frame()
frame(0x48);assert m[7]==2 and not m[0x8c] # rainbow skips acceleration
assert not m.ignored
fresh26();m[0x3d]=3;m[0x677]=1;m[0x678]=1
call('death_tick21');assert m[0x677]==0 and m[8]==180 and m[0x87]==7
call('audio_reset25a');assert not any(m[0x82:0x8d])
print('PASS real thrust/release, flip edge, shield activation/rejection, stop/rainbow exclusion, respawn and reset')
