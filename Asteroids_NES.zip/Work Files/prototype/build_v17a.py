"""V17a: two UFO shots, 60-frame attempts, equal UFO movement speed.
Second enemy shot record $0660-$0669; OAM slot 10. Pool starts at 11.
Preserves the complete V17 builder and assembler source.
"""
from pathlib import Path
import re
P=Path(__file__).parent
base=(P/'build_v17.py').read_text()
exec(base[:base.rindex('exec(compile(source,')])
change('STA $0650\nSTA $41','STA $0650\nSTA $0660\nSTA $41')
change('JSR ufo_shot_tick\n','JSR ufo_shot_tick\nJSR ufo_shot_tick2\n')
source=source.replace('LDA #$5A\nSTA $0646','LDA #$3C\nSTA $0646')
change('LDA $0640\nCMP #$02\nBEQ ufo_step_x\n','LDA $0645\nAND #$01\nBNE ufo_fire_timer\n')
change('LDA $0650\nBNE ufo_move_done\nJSR ufo_fire', '''LDA $0650
BEQ ufo_fire_first
LDA $0660
BNE ufo_move_done
JSR ufo_fire2
RTS
ufo_fire_first:
JSR ufo_fire''')
# Duplicate the proven firing/aiming/physics routines with independent state.
start=source.index('ufo_fire:\n')
end=source.index('ufo_collisions:\n',start)
second=source[start:end]
labels=re.findall(r'^([A-Za-z_][A-Za-z_0-9]*):',second,re.M)
second=re.sub(r'\b('+'|'.join(sorted(labels,key=len,reverse=True))+r')\b',lambda m:m[0]+'2',second)
second=second.replace('$065','$066')
change('ufo_collisions:\n',second+'ufo_collisions:\n')
change('render_ufo_body:\n', '''render_ufo_body:
LDA $0660
BEQ render_ufo_body_after_shots
LDA $0664
SEC
SBC #$01
STA $0228
LDA #$25
STA $0229
LDA #$00
STA $022A
LDA $0662
STA $022B
render_ufo_body_after_shots:
''')
change('render_asteroids:\nLDA #$28\nSTA $4C\nLDA #$36',
       'render_asteroids:\nLDA #$2C\nSTA $4C\nLDA #$35')
source=source.replace('asteroids_nes_v17_ufos.nes','asteroids_nes_v17a_two_ufo_shots.nes').replace('prototype_v17.asm','prototype_v17a.asm').replace('symbols_v17.json','symbols_v17a.json')
exec(compile(source,str(P/'build_v15.py'),'exec'))
