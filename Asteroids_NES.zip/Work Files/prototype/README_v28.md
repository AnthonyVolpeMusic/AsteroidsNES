# V28 respawn and shield tweaks

Branches from confirmed V27.

- Player respawn waits until no UFO body remains onscreen, in addition to the
  existing 120-update delay and any required Murderoid departure. UFO movement
  and destruction continue while dead. UFO projectiles do not gate respawn.
- Sprite palette 3: transparent, purple/magenta $24, yellow $37, green $2A.
- Active shield alternates sprite palettes 0 and 3, four rendered game frames
  per palette, starting with 0; default palette 0 returns on expiration.
  Applies to both manual shields and free respawn shields.

Zero-page $8D is newly reserved for the shield render counter. It resets on
shield activation and normal ship rendering. No new object scans.

Build: `python3 prototype/build_v28.py` (Python 3, Pillow, py65).
Test: `python3 prototype/test_v28.py`.

Assembled-ROM tests pass: large/small UFO wait, UFO movement/exit release,
minimum death delay, Murderoid gate, no final-life respawn, exact palette bytes,
four-frame alternation for 60/180-frame shields and return to normal. Existing
V27 control/audio tests also pass. Visual OpenEMU playtesting remains pending.
Timing uses existing game updates/rendering; slowdown can stretch wall time.

Historical build scripts and input assets are retained for reproducibility.
The included V25 ROM is for a known-bug test only; play the V28 ROM.
