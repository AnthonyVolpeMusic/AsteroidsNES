"""Rank/results screen and replay/menu transitions."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v22a.py').read_text(),str(P/'build_v22a.py'),'exec'))
def change23(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)
change23('CMP #$03\nBEQ main_render21\nJSR controls','CMP #$03\nBNE main_play23\nJSR controls\nJMP main_render21\nmain_play23:\nJSR controls')
change23('gameover_hold22:\nLDA #$03\nSTA $0677','gameover_hold22:\nJSR results_enter23')
change23('game_controls:\n','game_controls:\nLDA $0677\nCMP #$03\nBNE ordinary_controls23\nJMP results_controls23\nordinary_controls23:\n')
change23('LDA $06\nBEQ nmi_hud_done','LDA $0677\nCMP #$03\nBEQ nmi_hud_done\nLDA $06\nBEQ nmi_hud_done')
change23('render_game:\n','render_game:\nLDA $0677\nCMP #$03\nBNE render_world23\nRTS\nrender_world23:\n')
# Do not start a fresh wave behind the final-death display.
change23('JSR enemy_rocks21\nJSR murder_spawn_check\nJSR wave_tick\nJSR gameover_tick22','JSR enemy_rocks21\nJSR murder_spawn_check\nJSR gameover_tick22')
ranks=['GARBAGE SCOW CAPTAIN','GALACTIC COOK','ROOKIE','ENSIGN','PILOT','ACE','LIEUTENANT','WARRIOR','CAPTAIN','COMMANDER','SPACE LORD']
thresholds=[0,2500,5000,10000,15000,20000,30000,40000,60000,80000,100000]
def glyph(c):return 0 if c==' ' else 0x8a if c==':' else 0x61+ord(c)-65
def row(s):
    a=[0]*32;start=(32-len(s))//2;a[start:start+len(s)]=map(glyph,s);return a
nt=[0]*1024
for y,s in [(5,'FINAL SCORE:'),(10,'YOUR RANK:'),(18,'PRESS START TO REPLAY'),(22,'PRESS SELECT TO GO'),(23,'TO THE MAIN MENU')]:nt[y*32:y*32+32]=row(s)
tables={f'results_nt{i}23':nt[i*256:(i+1)*256] for i in range(4)}
for i,s in enumerate(ranks):tables[f'rank_{i}_23']=row(s)
for i in range(3):tables[f'rank_limit{i}23']=[(n>>(8*i))&255 for n in thresholds]
code=(P/'results_v23.asm').read_text()
load=''
for i in range(4):load+=f'LDX #$00\nresults_page{i}23:\nLDA results_nt{i}23,X\nSTA $2007\nINX\nBNE results_page{i}23\n'
code=code.replace('LOAD_RESULTS_PAGES',load)
dispatch=''
for i in range(11):
    dispatch+=f'CMP #${i:02X}\nBNE rank_skip{i}23\nJMP rank_draw{i}23\nrank_skip{i}23:\n'
dispatch+='RTS\n'
for i in range(11):dispatch+=f'rank_draw{i}23:\nLDX #$00\nrank_chars{i}23:\nLDA rank_{i}_23,X\nSTA $2007\nINX\nCPX #$20\nBNE rank_chars{i}23\nRTS\n'
code=code.replace('DRAW_RANK_DISPATCH',dispatch)
code='\n'.join(l for l in code.splitlines() if not l.lstrip().startswith(';'))
change23('shield_tick:\n',code+'\nshield_tick:\n')
change23('asm=Assembler(MPU());','data.update('+repr(tables)+')\nasm=Assembler(MPU());')
for a,b in [('asteroids_nes_v22a_explosion_fix.nes','asteroids_nes_v23_rank_screen.nes'),('symbols_v22a.json','symbols_v23.json'),('prototype_v22a.asm','prototype_v23.asm')]:change23(a,b)
exec(compile(source,str(P/'build_v15.py'),'exec'))
