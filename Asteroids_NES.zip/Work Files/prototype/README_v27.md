# V27 ship sound effects

Built from user-confirmed V26. Build: `python3 prototype/build_v27.py`.
Test: `python3 prototype/test_v27.py`. Dependencies: Python 3, Pillow, py65.

- Thrust: noise period 11, volume 3/15, while the living ship actually accelerates.
  Explosions fully override thrust until their 30-update fade finishes. Thrust
  resumes if still accelerating. Up used for rainbow fire does not trigger it.
- Shield: Pulse 2, F4/F#4/G4/G#4/A4, each 3 updates audible and 2 silent;
  25 updates total. Triggers for a successful manual shield or free respawn shield.
- Flip: Pulse 2, C6 to C5 glide over 10 updates. Down edge only; holding Down
  does not retrigger. B+Down stop does not play the flip sound.

Shield and flip start only when Pulse 2 is idle, are never queued, and cannot
interrupt each other. Any existing V26 Pulse 2 effect can interrupt them.
Both use the existing 50% duty/full-volume Pulse 2 settings.

New RAM reservation: zero-page $8C, actual-thrust flag, cleared every main-loop
update and at audio reset. New Pulse 2 effects use a separate 35-entry table
bank to avoid overflowing V26's existing 242-entry bank and 8-bit index.
Existing sequences and priorities remain intact. No object scans added.

Validation: V26 and earlier audio regression tests pass on the V27 ROM.
New tests cover exact notes and durations, idle-only rejection, interruption,
all explosion periods overriding and releasing thrust, death/menu silence,
actual NMI/main-loop thrust/release and button edges, shield rejection without
charge, stop/rainbow exclusion, free respawn shield, and audio-state reset.
The test bus checks APU register and length-enable semantics; it does not
synthesize sound. Listening and high-level performance playtesting remain
for OpenEMU/RetroArch. Sound timing follows game updates, as in V26.

Historical builders and input assets are included for reproducibility. The V25
ROM is included solely for a known-bug regression; play the V27 ROM.
