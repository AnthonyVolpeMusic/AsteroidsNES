"""V20 assembled CPU regressions and pickup attraction tests."""
from pathlib import Path
import math,random,ast
from collections import Counter
P=Path(__file__).parent
base=(P/'test_v15.py').read_text().replace('symbols_v15.json','symbols_v20.json').replace('asteroids_nes_v15_wave_transition.nes','asteroids_nes_v20_magnet.nes')
exec(compile(base,str(P/'test_v15.py'),'exec'))
pickups=list(range(0x700,0x800,16))
def reset():
    clear();m[6]=1;m[0x600:0x700]=[0]*256;m[0x30:0x3a]=[0]*10
    m[0x3a:0x3e]=[0x20,0x4e,0,3]
    m[0x11]=128;m[0x13]=120;m[0x2f]=165;m[0x40]=0
    call('pickups_init')
def pset(a,kind,x,y,life=420):m[a:a+16]=[0,x,0,y,0,0,0,0,kind,life&255,life>>8,10,0,0,0,0]
def score():return sum(m[0x30+i]<<(8*i) for i in range(3))
def active():return {a:m[a+8] for a in pickups if m[a+8]}
def signed(a):
    n=m[a]|m[a+1]<<8
    return n-65536 if n&32768 else n
def settle(limit=120):
    for i in range(limit):
        call('pickups_tick');call('pickups_collect')
        if not active():return i+1
    raise AssertionError(('pickup failed to arrive',active()))

order=[1,2,1,3,1,2,1,4,5,6,2,10,3,2,4,7,2,3,6,4,7,4,8,9]
reset()
for n in range(48):
    clear();m[0x308]=3;m[0x301]=60;m[0x303]=70
    m[0x600:0x640]=[0]*64
    m[0x600:0x610]=[47,0,64,0,74,0,0,0,0,0,12,0,0,0,0,0]
    call('collisions')
    if n%2:assert active()=={0x700:order[n//2]};m[0x708]=0
    else:assert not active()
assert m[0x671]==0 and score()==4800
print('PASS actual-hit 24-item order: 500 at slot 11 and magnet at slot 12')

# Capture is rectangle overlap; collection requires real ship contact.
for tier in range(4):
    bound=15+4*tier
    for sx,sy in [(100,100),(0,0),(255,239)]:
        for dx,dy,want in [(bound,0,True),(-bound,bound,True),(bound+1,0,False),(0,-bound-1,False)]:
            reset();m[0x676]=tier;m[0x11]=sx;m[0x13]=sy
            pset(0x700,1,(sx+dx)%256,(sy+dy)%240,life=1)
            call('pickups_collect')
            assert bool(m[0x70d])==want,(tier,sx,sy,dx,dy)
            assert score()==0 and m[0x708]==1
            if want:
                oldpos=m[0x700:0x704];call('pickups_tick')
                assert m[0x700:0x704]!=oldpos and m[0x709]==1
                call('pickups_collect');settle()
                assert score()==250
            else:
                call('pickups_tick');assert not active() and score()==0
print('PASS 24/32/40/48 boxes, wrap capture, visible flight, frozen expiry and contact-only awards')

# Chase must outrun the fastest diagonal ship, stay latched outside the zone,
# and work across all wrap directions.
for vx,vy in [(512,512),(-512,512),(512,-512),(-512,-512),(512,0),(0,-512)]:
    reset();m[0x11]=250;m[0x13]=235
    pset(0x700,1,(250-(15 if vx>=0 else -15))%256,(235-(15 if vy>=0 else -15))%240,life=1)
    call('pickups_collect');assert m[0x70d]==1
    for i in range(120):
        m[0x11]=(m[0x11]+vx//256)%256;m[0x13]=(m[0x13]+vy//256)%240
        call('pickups_tick');call('pickups_collect')
        if not active():break
    assert score()==250 and not active(),(vx,vy,i)
for h in range(48):
    vals=[]
    for axis in 'xy':
        n=m[S['attract_'+axis+'lo']+h]|m[S['attract_'+axis+'hi']+h]<<8
        vals.append(n-65536 if n&32768 else n)
    assert math.hypot(*vals)/256>=math.sqrt(8)+1
print('PASS maximum-speed diagonal pursuit and latched attraction')

reset()
for tier in (1,2,3):
    pset(0x700,10,128,120);call('pickups_collect');settle()
    assert m[0x676]==tier and score()==0
pset(0x700,10,128,120);call('pickups_collect');settle()
assert m[0x676]==3 and score()==1000
# At the third upgrade, other live magnet sprites turn into 1000-point items.
reset();m[0x676]=2
pset(0x700,10,128,120);pset(0x710,10,20,20)
call('pickups_collect');call('pickups_tick');call('pickups_collect')
assert m[0x676]==3 and m[0x718]==4
# Future magnet drops are genuinely type 4 (1000 artwork), not capped magnets.
m[0x671]=11;m[0x670]=1;m[0x26]=3;m[0x45]=0;m[0x46]=3
m[0x301]=60;m[0x303]=70;call('pickup_drop')
assert m[0x708]==4 and m[0x70d]==0
call('next_wave');assert m[0x676]==3 and m[0x671]==m[0x670]==0
call('pickup_player_death');assert m[0x676]==0
print('PASS three magnet upgrades, cap replacement, level persistence, future death reset')

reset()
for a in pickups:pset(a,1,128,120,life=1);m[a+13]=1
snapshot=m[0x700:0x800]
m[0x670]=1;m[0x26]=3;m[0x45]=0;m[0x46]=3
call('pickup_drop')
assert m[0x700:0x800]==snapshot and m[0x671]==0
print('PASS full pool cannot evict pickups already flying toward the ship')

# All awards remain exactly-once, including simultaneous arrivals.
reset();m[7]=3
for i,kind in enumerate([1,2,3,4,5,6,7,8,9,10]):pset(0x700+i*16,kind,128,120)
call('pickups_collect');assert score()==0 and len(active())==10
cycle_start=c.processorCycles
settle();assert score()==12500 and m[7]==4 and m[0x672]==1 and m[0x676]==1
assert c.processorCycles-cycle_start<20000,'simultaneous arrivals must not stall multiple frames'
assert int(''.join(str(v) for v in m[0x33:0x39]))==12500
call('pickups_collect');assert score()==12500
# Drifting lifetime and animation stay unchanged.
reset();pset(0x700,10,40,40)
for age in range(420):
    assert m[0x709]+256*m[0x70a]==420-age and m[0x70c]==(age//10)%2
    call('pickups_tick')
assert not active()
rom=(P/'asteroids_nes_v20_magnet.nes').read_bytes();chrdata=rom[32784:]
expected=['00333300','03333330','33300333','33000033','33000033','33000033','11000011','11000011']
for frame_index in range(2):
    raw=chrdata[(0x141+frame_index)*16:(0x142+frame_index)*16]
    decoded=[''.join(str(((raw[y]>>(7-x))&1)+2*((raw[y+8]>>(7-x))&1)) for x in range(8)) for y in range(8)]
    assert decoded==[r.replace('3','2') if frame_index else r for r in expected]
print('PASS every pickup award, 420-update drift lifetime, 10-update animation and magnet artwork')

# Decimal carries and binary score must agree, including extra-life thresholds.
for total in [0,9,99,999,9999,19999,39999,99999,999999]:
    for award in [1,25,50,100,200,250]:
        reset()
        for j in range(3):m[0x30+j]=(total>>(8*j))&255
        m[0x33:0x39]=[int(d) for d in f'{total:06d}']
        threshold=((total//20000)+1)*20000
        for j in range(3):m[0x3a+j]=(threshold>>(8*j))&255
        c.a=award;call('score_add')
        assert score()==total+award
        assert int(''.join(str(d) for d in m[0x33:0x39]))==(total+award)%1000000
        assert m[0x3d]==3+int(total+award>=threshold)
print('PASS bounded score-update cost, decimal carries and extra-life thresholds')

# Reuse the hunter-focused regression section without obsolete instantaneous
# pickup-collection expectations. Update only the requested level threshold.
hunter=(P/'test_v19.py').read_text().split('mr=list',1)[1]
hunter='mr=list'+hunter
hunter=hunter.replace('roots>=7','roots>=6').replace('level-4 threshold','level-3 threshold').replace('asteroids_nes_v19_murderoids.nes','asteroids_nes_v20_magnet.nes')
exec(compile(hunter,str(P/'test_v19.py'),'exec'))
timer_tests=(P/'test_v19b.py').read_text().split('def timer():',1)[1]
exec(compile('def timer():'+timer_tests,str(P/'test_v19b.py'),'exec'))
