"""V31c assembled-ROM selection, Bouncy bounds, and object counter tests."""
from pathlib import Path
import json
from py65.devices.mpu6502 import MPU
P=Path(__file__).parent
S=json.loads((P/'symbols_v31c.json').read_text())
class Memory(list):
    def __init__(self):
        super().__init__([0]*65536);self.pad=self.index=0
        self.ppu_addr=0;self.ppu_high=True;self.ppu_writes=[]
    def __getitem__(self,k):
        if k==0x2002:
            self.ppu_high=True
            return 0x80
        if k==0x4016:
            v=(self.pad>>(7-self.index))&1 if self.index<8 else 1
            self.index+=1;return v
        return super().__getitem__(k)
    def __setitem__(self,k,v):
        if k==0x4016:self.index=0
        if k==0x2006:
            self.ppu_addr=(v<<8) if self.ppu_high else ((self.ppu_addr&0xFF00)|v)
            self.ppu_high=not self.ppu_high
        if k==0x2007:
            self.ppu_writes.append((self.ppu_addr,v))
            self.ppu_addr=(self.ppu_addr+(32 if super().__getitem__(0x2000)&4 else 1))&0x3FFF
        super().__setitem__(k,v)
def fresh():
    global m,c
    m=Memory();m[0x8000:]=(P/'asteroids_nes_v31c_bouncy_debug.nes').read_bytes()[16:32784]
    c=MPU(memory=m,pc=S['reset'])
    for _ in range(100000):
        c.step()
        if c.pc==S['main']:return
    raise AssertionError('boot timeout')
def call(name):
    c.pc=S[name];c.sp=255;c.stPushWord(0x7ffe)
    for _ in range(100000):
        c.step()
        if c.pc==0x7fff:return
    raise AssertionError(name+' timeout')
def frame(pad=0):
    m.pad=pad;c.nmi()
    for _ in range(100000):
        c.step()
        if c.pc==S['main'] and m[0]==1:return
    raise AssertionError('frame timeout')
def bouncy_game():
    fresh();frame(0x20);assert m[0x8e]==1 and m[0x9a]==1
    frame();assert m[0x9a]==0
    frame(0x10);assert m[6]==1 and m[0x8e]==1

bouncy_game()
# Ship: right edge and upper HUD edge.  Bouncy's bottom is raised to $DE.
m[0x11]=250;m[0x10]=0;m[0x14]=0;m[0x15]=1;m[0x13]=0x0f;m[0x12]=0;m[0x16]=0;m[0x17]=0xff
call('physics');assert (m[0x11],m[0x15])==(248,255);assert (m[0x13],m[0x17])==(16,1)
m[0x13]=222;m[0x12]=0;m[0x17]=1;m[0x16]=0
call('physics');assert (m[0x13],m[0x17])==(222,255)
# Small rock right: position, velocity and 48-way heading reflect together.
m[0x308]=3;m[0x301]=250;m[0x300]=0;m[0x303]=100;m[0x302]=0;m[0x304]=0;m[0x305]=1;m[0x306]=0;m[0x307]=0;m[0x309]=12
call('asteroids');assert (m[0x301],m[0x305],m[0x309])==(248,255,36)
# Medium uses its actual 12px extent rather than the large-rock bound.
m[0x318]=2;m[0x311]=250;m[0x310]=0;m[0x313]=100;m[0x312]=0;m[0x314]=0;m[0x315]=1;m[0x316]=0;m[0x317]=0;m[0x319]=12
call('asteroids');assert (m[0x311],m[0x315],m[0x319])==(244,255,36)
# Player bullet and both UFO bullet slots bounce. UFO body itself is excluded.
for base,tick,heading in ((0x601,'bullets',9),(0x651,'ufo_shot_tick',8),(0x661,'ufo_shot_tick2',8)):
    if base==0x601:m[0x600]=5
    else:m[base-1]=5
    m[base]=0;m[base+1]=253;m[base+2]=0;m[base+3]=100;m[base+4]=0;m[base+5]=1;m[base+6]=0;m[base+7]=0;m[base+heading]=12
    call(tick);assert (m[base+1],m[base+5],m[base+heading])==(252,255,36),(hex(base),m[base+1],m[base+5],m[base+heading])
# Pickup and active Murderoid rebound. Large Murderoid has a 16px right bound.
m[0x708]=1;m[0x701]=250;m[0x700]=0;m[0x703]=100;m[0x702]=0;m[0x704]=0;m[0x705]=1;m[0x706]=0;m[0x707]=0;m[0x709]=1;m[0x70A]=1;m[0x70B]=10
call('pickups_tick');assert (m[0x701],m[0x705])==(248,255)
m[0x688]=1;m[0x681]=250;m[0x680]=0;m[0x683]=100;m[0x682]=0;m[0x684]=0;m[0x685]=1;m[0x686]=0;m[0x687]=0;m[0x689]=12;m[0x68B]=9
call('murder_tick');assert (m[0x681],m[0x685],m[0x689])==(240,255,36)
# Debris uses 8px edge logic too.
m[0x67D]=25;m[0x6E1]=253;m[0x6E0]=0;m[0x6E3]=100;m[0x6E2]=0;m[0x6E5]=1;m[0x6E4]=0;m[0x6E7]=0;m[0x6E6]=0
call('death_explosion_tick22');assert (m[0x6E1],m[0x6E5])==(248,255)
# UFO body exits normally even in Bouncy Mode.
m[0x640]=1;m[0x641]=244;m[0x642]=80;m[0x643]=0;m[0x644]=1;m[0x645]=1;m[0x646]=60
call('ufo_tick');assert m[0x640]==0
# Counter counts active objects only, updates once per 15 frames, and is two digits.
m[0x9D]=0;m[0x9E]=0;m[0x9F]=0
m[0x600]=1;m[0x610]=1;m[0x308]=3;m[0x318]=2;m[0x688]=1;m[0x708]=1;m[0x640]=1;m[0x650]=1;m[0x660]=1;m[0x67D]=5
for _ in range(14): call('debug_objects31a')
assert m[0x9E]==0 and m[0x9F]==0
call('debug_objects31a');assert m[0x9E]==15 and m[0x9F]==1
frame();assert m[0x9F]==0
# Arcade remains byte-for-byte conventional wrap for a ship and a rock.
fresh();m[6]=1;m[0x8e]=0;m[0x11]=255;m[0x10]=0;m[0x14]=0;m[0x15]=1;m[0x13]=100;m[0x17]=0
call('physics');assert m[0x11]==0 and m[0x15]==1
m[0x308]=3;m[0x301]=255;m[0x300]=0;m[0x303]=100;m[0x302]=0;m[0x304]=0;m[0x305]=1;m[0x306]=0;m[0x307]=0;m[0x309]=12
call('asteroids');assert m[0x301]==0 and m[0x305]==1 and m[0x309]==12
print('PASS title mode selection, Bouncy rebound/entity exceptions, headings, HUD edge and Arcade wrapping')

# Isolated fixtures avoid hidden objects left by prior gameplay tests.
def clear_objects():
    for page in (0x300,0x400,0x500,0x700):
        for offset in range(0,256,16):m[page+offset+8]=0
    for offset in range(0,96,16):m[0x688+offset]=0
    for offset in range(0,64,16):m[0x600+offset]=0
    for addr in (0x640,0x647,0x650,0x660,0x67D,0x9D,0x9E,0x9F):m[addr]=0

def check_count(expected):
    m[0x9D]=14
    call('debug_objects31a')
    assert m[0x9E]==expected,(expected,m[0x9E])
    m[0]=1;m.ppu_writes=[]
    c.pc=0x7FFF;c.sp=255;c.nmi()
    for _ in range(10000):
        c.step()
        if c.pc==0x7FFF:break
    else:raise AssertionError('NMI timeout')
    digits=[(a,v) for a,v in m.ppu_writes if 0x238F<=a<=0x2390]
    assert digits==[(0x238F,0x7B+expected//10),(0x2390,0x7B+expected%10)],digits
    assert not any(0x23C0<=a<=0x23FF for a,v in m.ppu_writes)
    assert m[0x9F]==0

for mode in (0,1):
    fresh();m[6]=1;m[0x8E]=mode;clear_objects()
    assert dict(m.ppu_writes)[0x3F01]==0x30
    m.ppu_writes=[];call('blank_title')
    vram=dict(m.ppu_writes)
    assert vram[0x23FB]==vram[0x23FC]==vram[0x23C0]==0
    chr_data=(P/'asteroids_nes_v31c_bouncy_debug.nes').read_bytes()[32784:]
    # The score and counter share digit tiles and nonzero white pixels.
    for digit in range(10):
        tile=chr_data[(0x7B+digit)*16:(0x7C+digit)*16]
        assert any(tile[:8]) and not any(tile[8:]),(digit,list(tile))
    # Counter y=224..231 survives an eight-scanline bottom crop.
    assert ((0x238F-0x2000)//32)*8+7 < 232
    check_count(0)
    for page in (0x300,0x400,0x500):m[page+8]=3
    check_count(3)  # Same record offset in three separate banks.
    for page in (0x300,0x400,0x500):
        for offset in range(0,256,16):m[page+offset+8]=3
    check_count(48)
    for offset in range(0,256,16):m[0x708+offset]=1
    for offset in range(0,96,16):m[0x688+offset]=1
    for offset in range(0,64,16):m[0x600+offset]=15
    m[0x647]=15;m[0x650]=60;m[0x660]=60;m[0x67D]=25
    check_count(81)  # 48 rocks + 16 pickups + 6 murderoids + 4 shots + UFO effect + 2 shots + 4 debris.
    m[0x9D]=0;m[0x9F]=0
    for i in range(14):
        call('debug_objects31a');assert m[0x9F]==0
    call('debug_objects31a');assert m[0x9F]==1
    m[0x0677]=3
    call('debug_objects31a');assert m[0x9F]==0
    m[6]=0;m[0x9F]=1
    call('debug_objects31a');assert m[0x9F]==0
print('PASS both modes: exact visible PPU digit addresses, untouched attributes, 0/3/48/81 counts, 15-frame cadence, title/results suppression')
