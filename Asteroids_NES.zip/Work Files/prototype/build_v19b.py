"""V19b: repeat Murderoid families after a ten-second delay."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v19a.py').read_text(),str(P/'build_v19a.py'),'exec'))
old='murder_init:\nLDA #$00\nSTA $0673'
assert source.count(old)==1
source=source.replace(old,old+'\nSTA $0674\nSTA $0675')
old='murder_spawn_check:\n'
assert source.count(old)==1
handler='''murder_spawn_check:
LDA $06
BEQ murder_retry_return
LDA $3F
CMP #$07
BCC murder_retry_return
LDA $0673
BEQ murder_retry_first
CMP #$01
BEQ murder_retry_watch_family
CMP #$02
BEQ murder_retry_tick
murder_retry_return:
RTS
murder_retry_first:
JMP murder_first_spawn_check
murder_retry_watch_family:
JSR murder_count
BNE murder_retry_return
LDA #$02
STA $0673
STA $0675
LDA #$58
STA $0674
RTS
murder_retry_tick:
LDA $0674
BNE murder_retry_low
DEC $0675
murder_retry_low:
DEC $0674
LDA $0674
ORA $0675
BNE murder_retry_return
; Expired: regular asteroids alone decide whether to spawn another family.
LDX #$00
murder_retry_scan:
LDA $0308,X
ORA $0408,X
ORA $0508,X
BNE murder_retry_spawn
TXA
CLC
ADC #$10
TAX
BNE murder_retry_scan
LDA #$03
STA $0673
RTS
murder_retry_spawn:
JMP murder_spawn_count_ready
murder_first_spawn_check:
'''
source=source.replace(old,handler)
source='\n'.join(line for line in source.splitlines() if not line.lstrip().startswith(';'))+'\n'
source=source.replace('asteroids_nes_v19a_edge_murderoids.nes','asteroids_nes_v19b_murderoid_respawn.nes').replace('symbols_v19a.json','symbols_v19b.json').replace('prototype_v19a.asm','prototype_v19b.asm')
exec(compile(source,str(P/'build_v15.py'),'exec'))
