# Asteroids NES V15 — wave transition

Branches from playtest-confirmed V14. No player collision added.

- Final asteroid/enemy removal arms a 240-update countdown (about four seconds at 60 Hz).
- Ship controls remain available during the delay; score/lives are retained.
- Next wave resets ship to the existing center coordinates, heading up, all fractional positions and velocities zero, shield off, SUPER 5, all four projectile/explosion records cleared.
- Roots increase from 4 by one each wave, capped at 12. Existing asteroid speeds are unchanged.
- Per-wave small-destruction count resets. Extra-life threshold is preserved.
- ZP $40: countdown; $41: reserved active-enemy count, currently zero. Future UFO code must maintain $41. Any active enemy/asteroid cancels a pending countdown.
- Wave check runs after collision processing, so grace-protected fragments count as active immediately.

Build from the extracted package root:

    python3 -m pip install py65 pillow
    python3 prototype/build_v15.py
    python3 prototype/test_v15.py
    python3 prototype/test_full_wave.py 15 100 4
    python3 prototype/test_full_wave.py 15 100 12

Tests execute the assembled 6502 instructions. V15 tests include a real final-hit main-loop/NMI sequence, exact timer expiry, reset, all-page/enemy gates, and repeated capped waves. Full-wave tests use controlled single-hit inputs with randomized destruction order and track every type change and score. These tests are not a full graphical emulator or hardware timing certification; OpenEMU playtesting remains useful.
