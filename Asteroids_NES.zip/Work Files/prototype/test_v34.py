"""Fixed-substep timing, real NMI scheduling and regressions for V34."""
import json
from pathlib import Path
from py65.devices.mpu6502 import MPU
P=Path(__file__).parent
S=json.loads((P/'symbols_v34.json').read_text())
ROM=(P/'asteroids_nes_v34_adaptive_fps.nes').read_bytes()[16:32784]

class Memory(list):
    def __init__(self):
        super().__init__([0]*65536)
        self.pad=self.index=0;self.dmas=[];self.apu=[];self.cpu=None
    def __getitem__(self,key):
        if key==0x2002:return 0x80
        if key==0x4016:
            value=(self.pad>>(7-self.index))&1 if self.index<8 else 1
            self.index+=1;return value
        return super().__getitem__(key)
    def __setitem__(self,key,value):
        if key==0x4016:self.index=0
        if key==0x4014 and self.cpu:
            self.dmas.append(self.cpu.processorCycles)
            self.cpu.processorCycles+=513
        if isinstance(key,int) and 0x4000<=key<=0x4015:
            self.apu.append((key,value))
        super().__setitem__(key,value)

def fresh():
    m=Memory();m[0x8000:]=ROM;c=MPU(memory=m,pc=S['reset']);m.cpu=c
    for _ in range(100000):
        c.step()
        if c.pc==S['main']:return m,c
    raise AssertionError('boot timeout')

def call(m,c,name):
    c.pc=S[name];c.sp=255;c.stPushWord(0x7FFE)
    start=c.processorCycles
    for _ in range(200000):
        c.step()
        if c.pc==0x7FFF:return c.processorCycles-start
    raise AssertionError(name+' timeout')

def batch(m,c):
    # Start after a presentation NMI and execute one entire work batch.
    c.pc=S['main'];c.sp=255;m[0]=0
    start=c.processorCycles;steps=0;draws=0
    for _ in range(200000):
        steps+=c.pc==S['simulation_step34'];draws+=c.pc==S['render']
        c.step()
        if c.pc==S['main'] and m[0]==1:return steps,draws,c.processorCycles-start
    raise AssertionError('batch timeout')

def blank_game(mode=0):
    m,c=fresh();m[6]=1;m[0x8E]=mode;m[0x3F]=4
    m[0x300:0x800]=[0]*0x500
    m[0x11]=128;m[0x13]=120;m[0x2F]=165
    return m,c

# Inclusive entry, separate return threshold, no mode chatter in the gap.
for mode in range(4):
    m,c=blank_game(mode);entry=22 if mode==0 else 15;exit_load=19 if mode==0 else 12
    m[0x9E]=entry-1;call(m,c,'frame_begin34');assert m[0xA1]==1
    m[0x9E]=entry;call(m,c,'frame_begin34');assert m[0xA1:0xA4]==[2,2,2]
    for load in range(entry-1,exit_load,-1):
        m[0x9E]=load;call(m,c,'frame_begin34');assert m[0xA1]==2
    m[0x9E]=exit_load;call(m,c,'frame_begin34');assert m[0xA1]==1
    m[6]=0;m[0x9E]=99;call(m,c,'frame_begin34');assert m[0xA1]==1
    m[6]=1;m[0x677]=3;call(m,c,'frame_begin34');assert m[0xA1]==1
print('PASS thresholds 22/15; return thresholds 19/12; title/results 60 Hz')

# Same two logical ticks: exact movement, projectile life, shield, pickup timers,
# sound envelopes, and collision state; paired mode rebuilds sprites only once.
for mode in range(4):
    def fixture():
        m,c=blank_game(mode)
        m[0x10:0x18]=[0,100,0,100,64,1,128,0]
        m[8]=60;m[7]=5
        m[0x300:0x310]=[0,30,0,30,64,0,32,0,3,6,0,5,3,1,0,0]
        m[0x600:0x610]=[40,0,150,0,170,0,2,0,0,0,12,0,0,0,0,0]
        m[0x700:0x710]=[0,10,0,190,32,0,32,0,1,164,1,10,0,0,0,0]
        call(m,c,'sfx_shot_start25');c.a=13;call(m,c,'sfx_noise_start25')
        c.a=9;call(m,c,'pulse2_start26')
        m.apu=[]
        return m,c
    m1,c1=fixture();m2,c2=fixture()
    m1[0x9E]=0;m2[0x9E]=99
    assert batch(m1,c1)[:2]==(1,1)
    assert batch(m1,c1)[:2]==(1,1)
    assert batch(m2,c2)[:2]==(2,1)
    for a,b in ((0x03,0x18),(0x30,0x42),(0x67,0x8E),(0x300,0x800)):
        assert m1[a:b]==m2[a:b],(mode,hex(a),[(hex(i),m1[i],m2[i]) for i in range(a,b) if m1[i]!=m2[i]])
    assert m1.apu==m2.apu,(mode,'sound events changed')
print('PASS paired substeps preserve exact movement, timers, shield palette timing and sound event sequence in all modes')

# Every simulation substep still checks collision: hit in first half produces
# exactly one score event; grace protects the newly allocated pair in half two.
m,c=blank_game();m[0x9E]=99
m[0x300:0x310]=[0,60,0,80,0,0,0,0,1,0,0,0,0,0,0,0]
m[0x600:0x610]=[40,0,64,0,84,0,0,0,0,0,12,0,0,0,0,0]
assert batch(m,c)[:2]==(2,1)
assert m[0x30]==25
assert sum(m[a+8]==2 for a in range(0x300,0x600,16))==2
assert m[0x609]!=0
print('PASS collision in first substep, score once, both fragments survive second substep')

# NMI must hold the previous OAM if only half of a 30 Hz interval elapsed,
# and must never publish an unfinished buffer when work crosses vblank.
def interrupt(m,c):
    c.pc=0x7FFF;c.sp=255;c.nmi()
    for _ in range(10000):
        c.step()
        if c.pc==0x7FFF:return
    raise AssertionError('NMI timeout')
m,c=blank_game();m[0]=1;m[0xA2]=2;m.dmas=[]
interrupt(m,c);assert m[0]==1 and m[0xA2]==1 and len(m.dmas)==0
interrupt(m,c);assert m[0]==0 and m[0xA2]==0 and len(m.dmas)==1
m[0]=0;m[0xA2]=1
interrupt(m,c);assert len(m.dmas)==1
m[0]=1
interrupt(m,c);assert len(m.dmas)==2
print('PASS 30 Hz publication cadence and protection against incomplete OAM DMA')

# Measure a repeatable busy scene. Include four player shots, a UFO, and its
# two projectiles; collision scans deliberately run to the end without hits.
def busy(mode,count=20):
    m,c=blank_game(mode);m[0x9E]=99
    for i in range(count):
        a=0x300+i*16
        m[a:a+16]=[0,(i*43)%240,0,190,40,0,20,0,3,6,0,5,12,1,0,0]
    m[0x640]=1;m[0x641]=100;m[0x642]=40;m[0x645]=240;m[0x646]=240
    for a in (0x650,0x660):m[a]=96;m[a+2]=50;m[a+4]=40
    for a in range(0x600,0x640,16):m[a]=47;m[a+2]=50;m[a+4]=220
    return m,c
for mode in range(4):
    m,c=busy(mode)
    steps,draws,cycles=batch(m,c)
    assert steps==2 and draws==1
    print(f'PROFILE mode={mode}: paired work {cycles} CPU cycles (two-refresh budget ~59,560 before interrupts)')
    assert cycles<57500,(mode,cycles)

# Real periodic interrupts, including DMA cycle stalls, rather than pretending
# that every amount of work fits one hardware frame.
for mode in range(4):
    m,c=busy(mode);m[0]=1;m[0xA2]=0;c.pc=S['main'];c.sp=255
    m.dmas=[];start=c.processorCycles;next_nmi=start;steps=0
    target=start+30*29781
    while c.processorCycles<target:
        if c.processorCycles>=next_nmi:
            c.nmi();next_nmi+=29781
        if c.pc==S['simulation_step34']:steps+=1
        c.step()
    assert 29<=steps<=30,(mode,steps)
    assert 15<=len(m.dmas)<=16,(mode,len(m.dmas))
    print(f'PASS mode {mode}: {steps} simulation steps / {len(m.dmas)} presentations in 30 hardware refreshes')

# Exact regression of the Bouncy interior shortcut against V33, including
# boundary crossings, every size, fractional positions and all 48 headings.
import random
old_symbols=json.loads((P/'symbols_v33.json').read_text())
old_rom=(P/'asteroids_nes_v33_evil.nes').read_bytes()[16:32784]
rng=random.Random(34)
old=[0]*65536;old[0x8000:]=old_rom;old_cpu=MPU(memory=old)
new=[0]*65536;new[0x8000:]=ROM;new_cpu=MPU(memory=new)
def direct(cpu,symbols,name):
    cpu.pc=symbols[name];cpu.sp=255;cpu.stPushWord(0x7FFE)
    for _ in range(100000):
        cpu.step()
        if cpu.pc==0x7FFF:return
    raise AssertionError(name)
for i in range(240):
    page=(0x300,0x400,0x500)[i%3];kind=1+i%3;prefix=('l','m','s')[kind-1]
    heading=i%48
    x=rng.choice((0,15,16,223,224,239,240,244,248,255,rng.randrange(256)))
    y=rng.choice((0,15,16,31,32,197,198,213,214,222,230,239,rng.randrange(240)))
    record=[rng.randrange(256),x,rng.randrange(256),y]
    record+=[old[old_symbols[prefix+s]+heading] for s in ('xlo','xhi','ylo','yhi')]
    record += [kind,heading,0,0,0,0,0,0]
    for mem in (old,new):
        mem[0x300:0x600]=[0]*0x300;mem[6]=1;mem[0x8E]=1;mem[page:page+16]=record
    direct(old_cpu,old_symbols,'asteroids');direct(new_cpu,S,'asteroids')
    assert new[page:page+16]==old[page:page+16],(i,record)
print('PASS 240 Bouncy movement comparisons against V33 at edges/interior/fractional positions')

# Switching back to 60 Hz during actual interrupts keeps a complete image at
# each publication; confirm both one-refresh and two-refresh display intervals.
m,c=busy(0);m[0]=1;m[0xA2]=0;c.pc=S['main'];c.sp=255
m.dmas=[];next_nmi=c.processorCycles;refresh=0
while refresh<60:
    if c.processorCycles>=next_nmi:
        refresh+=1
        if refresh==25:
            for a in range(0x300,0x600,16):m[a+8]=0
            m[0x640]=m[0x650]=m[0x660]=0
            for a in range(0x600,0x640,16):m[a]=0
        c.nmi();next_nmi+=29781
    c.step()
gaps=[round((b-a)/29781) for a,b in zip(m.dmas,m.dmas[1:])]
assert 2 in gaps and gaps[-5:]==[1]*5,gaps
assert m[0xA1]==1
print('PASS real-interrupt transition from 30 to 60 FPS after load falls')

# Execute established control/audio and four-mode/counter suites against V34.
for file in ('test_v33.py','test_v30.py'):
    suite=(P/file).read_text()
    suite=suite.replace('symbols_v33.json','symbols_v34.json').replace('asteroids_nes_v33_evil.nes','asteroids_nes_v34_adaptive_fps.nes')
    suite=suite.replace("load('v30','asteroids_nes_v30_silent_flip.nes')", "load('v34','asteroids_nes_v34_adaptive_fps.nes')")
    exec(compile(suite,str(P/file),'exec'),{'__file__':str(P/file)})
