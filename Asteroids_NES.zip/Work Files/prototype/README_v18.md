# Asteroids NES V18 — pickups

Based on the working V17a UFO build. Player One remains invincible.

## Gameplay

- Every second regular asteroid destroyed (large, medium or small) drops a pickup. UFO kills do not count.
- Per-wave repeating order: 250, 500, 250, 750, 250, 500, 250, 1000, shot speed. Both order and destruction parity reset with the next wave.
- Pickups drift in a random one of 48 directions at approximately 0.15 pixels/update (20% of the current small-asteroid speed), wrapping at the edges.
- Two artwork frames alternate every 10 updates. Items last 420 updates: 300 steady, then 120 blinking. At nominal 60 Hz this is five seconds plus two seconds.
- A separate centered 24x24 ship collection rectangle overlaps each pickup's 8x8 rectangle. Collection also works across wrap boundaries. This does not enlarge any enemy/damage collision region.
- Point pickups award their printed value once. Shot speed adds 25% of the base projectile speed per pickup, capped at +50%. Only newly fired shots change, including rainbow shots; inherited ship velocity is unchanged.
- Speed upgrades persist between waves and reset on a new game. Future player-death behavior is not implemented.
- Existing pickups retain their remaining lifetime across wave transitions and do not prevent the four-second wave countdown.

## Capacity and rendering

16 independent pickup records use $0700–$07FF. A full pool replaces its oldest item on the next drop. All 48 asteroid records remain available for splitting. Pickups join the asteroid OAM rotation, behind the protected ship, player projectiles, UFO and its two projectiles. They consume one hardware sprite each; NES per-scanline limits still apply.

State: $0670 destruction parity, $0671 sequence index, $0672 speed upgrade. Scratch $56–$5B. Each pickup record contains fractional position, velocity, type, a 16-bit lifetime and animation state. Sprite tiles $26–$2F reuse the existing ship/asteroid palettes. The short row in the second 1000-point frame has one transparent pixel appended.

## Build and test

Requires Python 3, Pillow and py65. Keep the prototype and upload directories next to each other.

```sh
python -m pip install pillow py65
python prototype/build_v18.py
python prototype/test_v18.py
python prototype/test_full_wave.py 18 100 4
python prototype/test_full_wave.py 18 100 12
```

The builder composes the preserved V15/V16/V17/V17a sources plus the V18 changes. Generated assembly and symbols are included.

Validation passed on the assembled 6502 code: exact sequence/parity, pickup lifespan and blinking, wrap-aware collection boundaries, simultaneous point awards, speed cap and all 48 launch headings, rainbow boost, full-pool replacement, rendering rotation and protected memory, wave reset behavior, and 900 integrated main-loop/NMI updates. Full-wave accounting passed 100 seeds each at four roots (4/8/16 destructions, 2,100 points) and twelve roots (12/24/48, 6,300 points), excluding collected pickup bonuses.

These are CPU-level automated tests, not a visual OpenEmu playtest or a cycle-accurate PPU simulation. Open the V18 ROM fresh rather than loading an older-version save state. Check pickup readability, collection feel, upgrades and late-wave rendering on your emulator.
