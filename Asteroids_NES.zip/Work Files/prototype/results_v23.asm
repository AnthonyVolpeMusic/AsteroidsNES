results_off23:
LDA #$00
STA $2000
STA $2001
BIT $2002
RTS
results_on23:
BIT $2002
results_vblank23:
BIT $2002
BPL results_vblank23
LDA #$00
STA $2005
STA $2005
LDA #$88
STA $2000
LDA #$1E
STA $2001
RTS
results_rank23:
LDX #$0A
results_compare23:
LDA $32
CMP rank_limit223,X
BCC results_lower23
BNE results_rank_done23
LDA $31
CMP rank_limit123,X
BCC results_lower23
BNE results_rank_done23
LDA $30
CMP rank_limit023,X
BCS results_rank_done23
results_lower23:
DEX
BPL results_compare23
results_rank_done23:
TXA
RTS
results_enter23:
JSR results_off23
LDA #$03
STA $0677
LDA #$00
STA $067C
LDA #$20
STA $2006
LDA #$00
STA $2006
LOAD_RESULTS_PAGES
; Score row 7, columns 13..18.
LDA #$20
STA $2006
LDA #$ED
STA $2006
LDX #$00
results_score23:
LDA $33,X
CLC
ADC #$7B
STA $2007
INX
CPX #$06
BNE results_score23
; Full centered rank row 12.
LDA #$21
STA $2006
LDA #$80
STA $2006
JSR results_rank23
JSR results_draw_rank23
JSR render
LDA #$00
STA $2003
LDA #$02
STA $4014
; Capture held buttons so entering the screen cannot immediately replay.
JSR results_readpad23
JMP results_on23
results_controls23:
LDA $02
EOR #$FF
AND $01
AND #$30
BEQ results_control_done23
AND #$10
BNE results_replay23
JMP reset
results_control_done23:
RTS
results_readpad23:
LDA #$01
STA $4016
LDA #$00
STA $4016
STA $01
LDX #$08
results_pad_loop23:
LDA $4016
LSR A
ROL $01
DEX
BNE results_pad_loop23
LDA $01
STA $02
RTS
results_replay23:
JSR results_off23
LDA #$00
LDX #$7F
results_clear_zp23:
STA $00,X
DEX
CPX #$02
BNE results_clear_zp23
LDX #$00
results_clear_pools23:
STA $0300,X
STA $0400,X
STA $0500,X
STA $0600,X
STA $0700,X
INX
BNE results_clear_pools23
LDA #$03
STA $3D
LDA #$04
STA $3F
LDA #$05
STA $07
LDA #$80
STA $11
LDA #$78
STA $13
LDA #$20
STA $3A
LDA #$4E
STA $3B
LDA #$10
STA $3E
LDA #$A5
STA $2F
JSR murder_init
JSR pickups_init
JSR ufo_init
JSR set_game_rocks
; Blank the results and restore just the HUD while rendering is disabled.
LDA #$20
STA $2006
LDA #$00
STA $2006
LDY #$04
LDX #$00
LDA #$00
results_blank23:
STA $2007
INX
BNE results_blank23
DEY
BNE results_blank23
JSR load_hud
LDA #$01
STA $06
JSR render
LDA #$00
STA $2003
LDA #$02
STA $4014
JMP results_on23
results_draw_rank23:
DRAW_RANK_DISPATCH
