"""The weighted object tally remains as the adaptive-FPS load input ($9E),
but is no longer presented in the bottom row. B+Up shares the B+Down brake.
"""
code='\n'.join(lines)
# Remove the bottom-row PPU write path. $9E continues to drive V34's adaptive
# 30/60 Hz scheduler; removing the visual does not change its thresholds.
start=code.index('nmi_mode_done31:\n')+len('nmi_mode_done31:\n')
end=code.index('nmi_debug_done31a:\n',start)
code=code[:start]+code[end:]
# Both D-pad directions with B brake. B+Down retains its original behavior;
# B+Up now reaches the exact same cost, velocity reset, and brake sound.
assert code.count('BNE special_rainbow')==1
code=code.replace('BNE special_rainbow','BNE special_stop',1)
# Stop setting a stale display-dirty flag, then finish the retained load tally.
assert code.count('LDA #$01\nSTA $9F\ndebug_objects_done31a:')==1
code=code.replace('LDA #$01\nSTA $9F\ndebug_objects_done31a:','debug_objects_done31a:',1)
lines=[s.strip() for s in code.splitlines() if s.strip()]
