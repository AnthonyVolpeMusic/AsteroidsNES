"""Run actual V21 6502 code for mortality and enemy collision regressions."""
from pathlib import Path
import random, math
P=Path(__file__).parent
base=(P/'test_v15.py').read_text().split('clear()\nfor _ in range(250)')[0]
base=base.replace('symbols_v15.json','symbols_v22.json').replace('asteroids_nes_v15_wave_transition.nes','asteroids_nes_v22_gameover.nes')
exec(compile(base,str(P/'test_v15.py'),'exec'))
def reset():
    m[:0x800]=[0]*0x800;m[6]=1;m[0x3d]=3;m[0x3f]=4
    m[0x11]=128;m[0x13]=120;m[7]=5;m[0x2f]=165
    m[0x3a:0x3d]=[0x20,0x4e,0]
    m[0x64a:0x64c]=[0x58,2]
def rock(a,k,x=128,y=120):m[a:a+16]=[0,x,0,y,0,0,0,0,k,0,0,0,0,0,0,0]
def shot(a,x=128,y=120):m[a:a+16]=[90,0,x,0,y,0,0,0,0,12,0,0,0,0,0,0]
def score():return sum(m[0x30+i]<<(8*i) for i in range(3))
def runframe(pad=0):
    c.pc=S['main'];m[0]=1;frame(pad)

# AABB boundaries and wrap: compare assembly against interval geometry.
rng=random.Random(21)
for _ in range(2000):
    sx,tx=rng.randrange(256),rng.randrange(256)
    sy,ty=rng.randrange(240),rng.randrange(240)
    sw,tw=rng.choice([4,8,12,16]),rng.choice([8,12,16])
    m[0x70:0x76]=[sx,sy,sw,tx,ty,tw]
    call('overlap21')
    expected=any((sx+i)%256==(tx+j)%256 for i in range(sw) for j in range(tw)) and any((sy+i)%240==(ty+j)%240 for i in range(sw) for j in range(tw))
    assert bool(c.p&1)==expected,(sx,sy,sw,tx,ty,tw)
print('PASS 2000 wrap-aware overlap comparisons')

for family in ('regular','murder','ufo','shot'):
    for k in range(1,4 if family in ('regular','murder') else 3):
        for shield in (0,1,180):
            reset();m[8]=shield
            if family=='regular':rock(0x300,k)
            elif family=='murder':rock(0x680,k)
            elif family=='ufo':m[0x640:0x643]=[k,128,120]
            else:shot(0x650+(k-1)*16)
            call('player_hits21')
            assert m[0x3d]==(3 if shield else 2),(family,k,shield)
            assert m[0x679]==int(family=='murder' and not shield)
            call('player_hits21');assert m[0x3d]==(3 if shield else 2)
print('PASS every hazard size, both UFO shots, shield protection and one life per death')

reset();m[0x670:0x673]=[1,17,2];m[0x676]=3
m[0x39]=13;m[3]=22;m[7]=1;m[0x14:0x18]=[12,2,44,1]
shot(0x600);call('player_kill21')
assert not any(m[0x600:0x640])
for i in range(119):call('death_tick21');assert m[0x677]==1
call('death_tick21')
assert m[0x677]==0 and m[8]==180 and m[7]==5 and m[3]==0
assert m[0x10:0x18]==[0,128,0,120,0,0,0,0]
assert m[0x670:0x673]==[1,17,2] and m[0x676]==3 and m[0x39]==13
rock(0x300,1)
for i in range(179):call('shield_tick');call('player_hits21');assert m[0x3d]==2
call('shield_tick');call('player_hits21');assert m[0x3d]==1
print('PASS 120-update respawn, 180-update free shield, counters and upgrades retained')

reset();m[0x3f]=6;m[0x673]=1
for i,k in enumerate((1,2,3,1,2,3)):rock(0x680+i*16,k,x=i*30,y=120)
m[0x11]=0;call('player_hits21');assert m[0x679]==1
for i in range(120):call('murder_depart_or_tick21');call('death_tick21')
assert m[0x677]==1 and m[0x678]==0
for i in range(8):call('murder_depart_or_tick21');call('death_tick21')
assert m[0x677]==0 and not any(m[a+8] for a in range(0x680,0x6e0,16))
assert score()==0 and m[0x670]==0
# Rightmost metasprite quarter must not wrap to the left during evacuation.
reset();rock(0x680,1,x=252,y=100);m[0x679]=1
m[0x43:0x45]=[0x80,6];m[0x4c]=44;m[0x4e]=53
m[0x200:0x300]=[248]*256;call('render_murder')
assert m[0x4c]==52 and m[0x22f]==252 and m[0x233]==252
print('PASS six-object evacuation, respawn gate, no wrap or evacuation score')

for source_kind in ('big','small','shot1','shot2'):
    for k in (1,2,3):
        reset();rock(0x300,k);rock(0x310,k)
        m[0x670:0x673]=[1,11,2];m[0x39]=7
        if source_kind in ('big','small'):m[0x640:0x644]=[1 if source_kind=='big' else 2,128,120,0]
        else:shot(0x650 if source_kind=='shot1' else 0x660)
        call('enemy_rocks21')
        expected=sorted([k]+([] if k==3 else [k+1,k+1]))
        assert sorted(kinds())==expected,(source_kind,k,kinds())
        assert score()==0 and m[0x670:0x673]==[1,11,2] and m[0x39]==7
        call('enemy_rocks21');assert sorted(kinds())==expected
reset();rock(0x300,2,x=40);rock(0x310,2,x=170)
shot(0x650,x=40);shot(0x660,x=170);call('enemy_rocks21')
assert kinds()==[3]*4 and score()==0 and not m[0x650] and not m[0x660]
print('PASS UFO bodies and both shots consume once, split correctly, award no points/drops')

# Actual NMI/main-loop lifecycle; controls cannot move/fire while dead.
reset();rock(0x300,3);runframe();assert m[0x677]==1 and m[0x3d]==2
for i in range(119):runframe(0xc4);assert m[0x677]==1
runframe();assert m[0x677]==0 and m[8]==180
assert m[0x11]==128 and m[0x13]==120 and not any(m[0x600:0x640])
for i in range(179):
    m[0x301]=128;m[0x303]=120;m[0x304:0x308]=[0]*4;m[0x308]=3
    runframe();assert m[0x3d]==2
m[0x301]=128;m[0x303]=120;m[0x304:0x308]=[0]*4;m[0x308]=3
runframe();assert m[0x3d]==1,(m[0x3d],m[8],m[0x677],m[0x301:0x309])
reset();m[0x3d]=1;rock(0x300,3);runframe()
assert m[0x677]==2 and m[0x3d]==0 and m[0x67a]==0x2c and m[0x67e]==1 and m[0x67c]==1
# The final-death world continues, including regular movement, while control/player
# collision paths remain disabled. The five-second count is exactly 300 updates.
m[0x301]=80;m[0x304]=0;m[0x305]=1
before=m[0x301]
for i in range(299):
    runframe(0xff);assert m[0x677]==2,(i,m[0x677],m[0x67a],m[0x67e])
assert m[0x301]!=before and not any(m[0x600:0x640])
runframe(0xff);assert m[0x677]==3 and m[0x67a]==m[0x67e]==0
before=m[0x300:0x800]
for i in range(60):runframe(0xff)
assert m[0x300:0x800]==before
print('PASS actual main-loop mortality/respawn, live five-second GAME OVER and final hold')

# Representative busy frame: 48 small rocks plus UFO and both enemy shots.
# Include a DMA allowance because py65 does not model the hardware DMA stall.
reset()
for i in range(48):rock(0x300+i*16,3,x=(i*37)%256,y=30+(i*17)%180)
m[0x640:0x647]=[1,20,220,0,0,30,30]
shot(0x650,x=50,y=220);shot(0x660,x=80,y=220)
start=c.processorCycles;runframe();cycles=c.processorCycles-start+514
assert cycles<29780,cycles
print('PASS representative 48-rock/UFO/two-shot frame:',cycles,'cycles including DMA allowance')

# Replay established pickup, scoring and magnet checks on this new ROM.
pickup_tests=(P/'test_v20.py').read_text().split('pickups=list',1)[1].split('# Reuse the hunter-focused',1)[0]
pickup_tests='pickups=list'+pickup_tests
pickup_tests=pickup_tests.replace('asteroids_nes_v20_magnet.nes','asteroids_nes_v22_gameover.nes')
pickup_tests=pickup_tests.replace("call('pickup_player_death');assert m[0x676]==0", "call('pickup_player_death');assert m[0x676]==3")
pickup_tests=pickup_tests.replace('future death reset','death persistence')
exec(compile(pickup_tests,str(P/'test_v20.py'),'exec'))

# Four OAM-reserved death pieces begin at the ship and animate five updates per
# frame while travelling from that point. The renderer uses the supplied tiles.
reset();m[0x10:0x14]=[0,100,0,110];m[0x2f]=165
call('death_burst_start22');assert m[0x67d]==25
m[0x677]=1
starts=[tuple(m[0x6e0+i*8:0x6e4+i*8]) for i in range(4)]
assert starts==[(0,100,0,110)]*4
call('render')
assert [m[0x201+i*4] for i in range(4)]==[0x1f]*4,([m[0x201+i*4] for i in range(4)],m[0x67d],m[0x677])
assert [m[0x202+i*4] for i in range(4)]==[0]*4
call('death_explosion_tick22')
assert any(tuple(m[0x6e0+i*8:0x6e4+i*8])!=starts[i] for i in range(4))
for _ in range(4):call('death_explosion_tick22')
call('render');assert [m[0x201+i*4] for i in range(4)]==[0x1e]*4
for _ in range(20):call('death_explosion_tick22')
assert m[0x67d]==0
assert [m[S['gameover_text22']+i] for i in range(9)]==[0x67,0x61,0x6d,0x65,0,0x6f,0x76,0x65,0x72]
print('PASS four-piece moving death burst, five-update frames and GAME OVER glyph data')
