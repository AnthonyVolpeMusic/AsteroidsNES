"""Retarget existing regressions, then verify exact respawn timing."""
from pathlib import Path
P=Path(__file__).parent
base=(P/'test_v19a.py').read_text().replace('symbols_v19a.json','symbols_v19b.json').replace('asteroids_nes_v19a_edge_murderoids.nes','asteroids_nes_v19b_murderoid_respawn.nes')
exec(compile(base,str(P/'test_v19a.py'),'exec'))
def timer():return m[0x674]+256*m[0x675]
def finish_last():
    for a in mr:m[a+8]=0
    m[0x688]=3;m[0x681]=60;m[0x683]=70;m[0x68a]=0
    m[0x600:0x640]=[0]*64
    shot(0x600,64,74);call('murder_collisions')
    assert not hunters()
    call('murder_spawn_check')
    assert timer()==600 and m[0x673]==2

mreset();m[0x308]=3;call('murder_spawn_check')
# No countdown until every family member is gone.
for _ in range(601):call('murder_spawn_check')
assert timer()==0 and hunters()=={0x680:1}
finish_last()
for elapsed in range(1,600):
    call('murder_spawn_check')
    assert not hunters() and timer()==600-elapsed
call('murder_spawn_check');assert hunters()=={0x680:1} and timer()==0 and m[0x673]==1
# Repeat a second and third family, keeping the same farthest-wall behavior.
for _ in range(2):
    finish_last()
    for frame_index in range(600):call('murder_spawn_check')
    assert hunters()=={0x680:1}
    assert m[0x681] in (0,240) or m[0x683] in (0,224)
assert (m[0x670],m[0x671])==(13,7)
# Even >3 regular fragments still allow replacement after the first family.
finish_last()
for a in list(records)[:8]:m[a+8]=3
for _ in range(600):call('murder_spawn_check')
assert hunters()=={0x680:1}
# UFOs alone cannot cause a replacement; an empty wave transitions in 240.
finish_last();clear();m[0x41]=1
for _ in range(601):call('murder_spawn_check');call('wave_tick')
assert not hunters() and timer()==0 and m[0x40]==0
m[0x41]=0;call('wave_tick');assert m[0x40]==240
for _ in range(240):call('wave_tick')
assert timer()==0 and m[0x673]==0
mreset();m[0x308]=3;call('murder_spawn_check');finish_last();clear()
for _ in range(240):call('murder_spawn_check');call('wave_tick')
assert m[0x40]==1 and not hunters()
call('murder_spawn_check');call('wave_tick')
assert m[0x3f]==8 and timer()==0 and m[0x673]==0
# No old timer can leak into the fresh level while >3 roots remain.
for _ in range(601):call('murder_spawn_check')
assert not hunters() and timer()==0
print('PASS 600-update respawn, repeated families, remaining-rock check, UFO-only exclusion, normal wave transition and timer reset')
