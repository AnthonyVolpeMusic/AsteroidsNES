"""Murderoids on the confirmed V18b program. No baseline files are edited."""
from pathlib import Path
import math
P=Path(__file__).parent
exec(compile((P/'build_v18b.py').read_text(), str(P/'build_v18b.py'), 'exec'))

def replace_once(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)

replace_once('JSR blank_title\nJSR pickups_init','JSR blank_title\nJSR murder_init\nJSR pickups_init')
replace_once('next_wave:\nJSR pickup_reset_counter','next_wave:\nJSR murder_init\nJSR pickup_reset_counter')
replace_once('JSR asteroids\nJSR pickups_tick','JSR asteroids\nJSR murder_tick\nJSR pickups_tick')
replace_once('JSR collisions\nJSR ufo_tick','JSR collisions\nJSR murder_collisions\nJSR ufo_tick')
replace_once('JSR pickups_collect\nJSR wave_tick','JSR pickups_collect\nJSR murder_spawn_check\nJSR wave_tick')
replace_once('wave_tick:\nLDA $06','wave_tick:\nJSR murder_count\nBEQ murder_wave_clear\nJMP wave_cancel\nmurder_wave_clear:\nLDA $06')

aim=(P/'ufo_v17.asm').read_text().split('ufo_aim_heading:\n',1)[1].split('ufo_shot_tick:',1)[0]
aim='murder_aim:\n'+aim.replace('ufo_','murder_')
aim=aim.replace('$0652','$0681,X').replace('$0654','$0683,X').replace('LDA murder_aim,X','LDA ufo_aim,X')
velocity='murder_velocity:\nLDY $0689,X\nLDA $0688,X\nCMP #$01\nBEQ murder_vel_l\nCMP #$02\nBEQ murder_vel_m\nJMP murder_vel_s\n'
tables={'murder_width':[0,16,12,8]}
for kind,speed in [('l',128),('m',240),('s',384)]:
    velocity+='murder_vel_'+kind+':\n'
    for axis,fn,start in [('x',math.sin,4),('y',lambda a:-math.cos(a),6)]:
        vals=[round(speed*fn(h*math.tau/48))&65535 for h in range(48)]
        for j,part in enumerate(['lo','hi']):
            name='murder_'+kind+axis+part
            tables[name]=[(v>>(j*8))&255 for v in vals]
            velocity+=f'LDA {name},Y\nSTA $068{start+j},X\n'
    velocity+='RTS\n'
murder_code='\n'.join(line for line in (P/'murderoids_v19.asm').read_text().splitlines() if not line.lstrip().startswith(';'))
replace_once('wave_tick:\n',murder_code+'\n'+aim+velocity+'\nwave_tick:\n')

# Shared render traversal: 48 asteroids, 16 pickups, 6 Murderoids.
tables['render_record_low']=[(n*16)&255 for n in range(64)]+[0x80+n*16 for n in range(6)]
tables['render_record_high']=[3+n//16 for n in range(48)]+[7]*16+[6]*6
replace_once('asm=Assembler(MPU());', 'data.update('+repr(tables)+')\nasm=Assembler(MPU());')
rs=source.index('render_asteroids:\n');re=source.index('render_title:\n',rs)
pool=source[rs:re].replace('#$40','#$46').replace('ADC #$05','ADC #$09')
pool=pool.replace('render_pool_active:\nLDA $44','render_pool_active:\nLDA $44\nCMP #$06\nBNE render_not_murder\nJSR render_murder\nJMP render_pool_next\nrender_not_murder:\nLDA $44')
source=source[:rs]+pool+source[re:]

# Exact user pixels: 0 transparent, 2 blue $12, 3 green $2A.
small=['00333300','03222230','32322323','32233223','32233223','32322323','03222230','00333300']
medium=['003333000000','032222300000','323223230000','322332230000','322332333300','323223232230','032222322323','003333233223','000032233223','000032322323','000003222230','000000333300']
left=['00333300','03222230','32322323','32233223','32233223','32322323','03222232','00333323','00333323','03222232','32322323','32233223','32233223','32322323','03222230','00333300']
large=[row+row[::-1] for row in left]
art="\nmurder_small="+repr(small)+"\nmurder_medium="+repr(medium)+"\nmurder_large="+repr(large)+"\n"
art+='''
assert len(murder_small)==8 and all(len(r)==8 for r in murder_small)
assert len(murder_medium)==12 and all(len(r)==12 for r in murder_medium)
assert len(murder_large)==16 and all(len(r)==16 for r in murder_large)
tile(0x138,[[int(c) for c in row] for row in murder_small])
for base,rows in [(0x139,[r+'0000' for r in murder_medium]+['0'*16]*4),(0x13d,murder_large)]:
 for ty in range(2):
  for tx in range(2):
   tile(base+ty*2+tx,[[int(rows[ty*8+y][tx*8+x]) for x in range(8)] for y in range(8)])
'''
replace_once("output=P/'asteroids_nes_v18b_finalized_pickups.nes'",art+"\noutput=P/'asteroids_nes_v19_murderoids.nes'")
source=source.replace('prototype_v18b.asm','prototype_v19.asm').replace('symbols_v18b.json','symbols_v19.json')
exec(compile(source,str(P/'build_v15.py'),'exec'))
