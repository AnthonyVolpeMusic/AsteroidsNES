"""Triangle C2/C#2 asteroid pulse."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v23.py').read_text(),str(P/'build_v23.py'),'exec'))
def change24(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)
change24('''JSR asteroids
JSR murder_tick''','''JSR asteroids
JSR asteroid_pulse24
JSR murder_tick''')
change24('''main_dead21:
JSR asteroids
JSR death_explosion_tick22''','''main_dead21:
JSR asteroids
JSR asteroid_pulse24
JSR death_explosion_tick22''')
change24('''main_gameover22:
JSR death_explosion_tick22
JSR asteroids''','''main_gameover22:
JSR death_explosion_tick22
JSR asteroids
JSR asteroid_pulse24''')
change24('''main_title21:
JSR asteroids''','''main_title21:
JSR asteroid_pulse_off24
JSR asteroids''')
change24('results_enter23:\n','results_enter23:\nJSR asteroid_pulse_off24\n')
code='\n'.join(l for l in (P/'triangle_v24.asm').read_text().splitlines() if not l.lstrip().startswith(';'))
change24('shield_tick:\n',code+'\nshield_tick:\n')
change24("data.update({'hazard_width21':[0,16,12,8]", "data.update({'pulse_timer24':[0x26,0x56], 'pulse_high24':[0x03,0x03]} )\ndata.update({'hazard_width21':[0,16,12,8]")
for a,b in [('asteroids_nes_v23_rank_screen.nes','asteroids_nes_v24_triangle_pulse.nes'),('symbols_v23.json','symbols_v24.json'),('prototype_v23.asm','prototype_v24.asm')]:change24(a,b)
exec(compile(source,str(P/'build_v15.py'),'exec'))
