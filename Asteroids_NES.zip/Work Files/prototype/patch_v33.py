"""V33: Evil Mode and weighted performance counter.

Mode 3 makes medium and small regular asteroids use Murderoid-style heading
steering every four updates, while loading the normal medium/small velocity
tables. The counter is now a CPU-load score: UFO body 4, Murderoid 5,
every other active item 1, capped at 99 for its two tiles.
"""
import re

patch31('''LDA $8E
CLC
ADC #$01
CMP #$03
BCC mode_ready32''','''LDA $8E
CLC
ADC #$01
CMP #$04
BCC mode_ready32''')
data['mode_text31']=sum((glyphs31(s.ljust(12)) for s in ('ARCADE MODE','BOUNCY MODE','DRUNK MODE','EVIL MODE')),[])

# Counter weights: each regular rock still adds one; Murderoids add five.
patch31('''LDA $0688,X
BEQ debug_murder_next31a
INC $9E''','''LDA $0688,X
BEQ debug_murder_next31a
LDA $9E
CLC
ADC #$05
STA $9E''')
# A live UFO costs four; its brief death animation costs one rendering point.
patch31('''LDA $0640
ORA $0647
BEQ debug_no_ufo31a
INC $9E
debug_no_ufo31a:''','''LDA $0640
BEQ debug_no_live_ufo33
LDA $9E
CLC
ADC #$04
STA $9E
debug_no_live_ufo33:
LDA $0647
BEQ debug_no_ufo31a
INC $9E
debug_no_ufo31a:''')
patch31('''debug_no_debris31a:
LDA #$01
STA $9F''','''debug_no_debris31a:
LDA $9E
CMP #$64
BCC debug_counter_ready33
LDA #$63
STA $9E
debug_counter_ready33:
LDA #$01
STA $9F''')

# Run Evil steering before normal wrapping movement. Bouncy remains exclusively
# mode 1; Drunk remains exclusively mode 2.
for page in (0x300,0x400,0x500):
    tag=f'{page:04x}'
    patch31(f'rock{tag}_arcade31:\n',f'''rock{tag}_arcade31:
LDA $8E
CMP #$03
BNE evil_skip{tag}
LDA $06
BEQ evil_skip{tag}
JSR evil_tick{tag}
evil_skip{tag}:
''')
    def a(off): return f'${page+off:04X},X'
    routine=f'''evil_tick{tag}:
LDA {a(8)}
CMP #$02
BCS evil_active{tag}
RTS
evil_active{tag}:
LDA {a(11)}
BNE evil_wait{tag}
LDA #$04
STA {a(11)}
JMP evil_steer{tag}
evil_wait{tag}:
DEC {a(11)}
BEQ evil_reload{tag}
RTS
evil_reload{tag}:
LDA #$04
STA {a(11)}
evil_steer{tag}:
STX $60
LDA #${page&255:02X}
CLC
ADC $60
STA $43
LDA #${page>>8:02X}
ADC #$00
STA $44
JSR evil_aim33
LDX $60
SEC
SBC {a(9)}
BCS evil_delta{tag}
CLC
ADC #$30
evil_delta{tag}:
BEQ evil_velocity{tag}
CMP #$18
BCS evil_left{tag}
INC {a(9)}
LDA {a(9)}
CMP #$30
BCC evil_velocity{tag}
LDA #$00
STA {a(9)}
JMP evil_velocity{tag}
evil_left{tag}:
LDA {a(9)}
BNE evil_decrement{tag}
LDA #$30
STA {a(9)}
evil_decrement{tag}:
DEC {a(9)}
evil_velocity{tag}:
LDY {a(9)}
LDA {a(8)}
CMP #$02
BEQ evil_medium{tag}
LDA sxlo,Y
STA {a(4)}
LDA sxhi,Y
STA {a(5)}
LDA sylo,Y
STA {a(6)}
LDA syhi,Y
STA {a(7)}
JMP evil_done{tag}
evil_medium{tag}:
LDA mxlo,Y
STA {a(4)}
LDA mxhi,Y
STA {a(5)}
LDA mylo,Y
STA {a(6)}
LDA myhi,Y
STA {a(7)}
evil_done{tag}:
RTS
'''
    code+='\n'+routine

# Generic heading target for a regular-asteroid pointer in $43/$44. Matches
# Murderoid shortest-path aiming, but does not touch its record array.
code+='''
evil_aim33:
LDA #$00
STA $54
STA $55
LDY #$01
LDA $11
SEC
SBC ($43),Y
BPL evil_dx_positive33
INC $54
EOR #$FF
CLC
ADC #$01
evil_dx_positive33:
STA $52
LDY #$03
LDA $13
SEC
SBC ($43),Y
BCS evil_dy_wrapped33
CLC
ADC #$F0
evil_dy_wrapped33:
CMP #$78
BCC evil_dy_positive33
SEC
SBC #$F0
BPL evil_dy_positive33
INC $55
EOR #$FF
CLC
ADC #$01
evil_dy_positive33:
STA $53
evil_aim_scale33:
LDA $52
ORA $53
CMP #$10
BCC evil_aim_lookup33
LSR $52
LSR $53
JMP evil_aim_scale33
evil_aim_lookup33:
LDA $53
ASL A
ASL A
ASL A
ASL A
ORA $52
TAX
LDA ufo_aim,X
LDX $55
BEQ evil_aim_x_sign33
STA $52
LDA #$18
SEC
SBC $52
evil_aim_x_sign33:
LDX $54
BEQ evil_aim_normalize33
STA $52
LDA #$30
SEC
SBC $52
evil_aim_normalize33:
JMP normalize_heading
'''
lines=[s.strip() for s in code.splitlines() if s.strip()]
