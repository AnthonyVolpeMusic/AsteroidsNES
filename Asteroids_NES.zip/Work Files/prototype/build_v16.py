"""V16 rendering-only patch over the preserved V15 builder.

OAM 0: ship; 1..4: shots/hit explosions; 5..9: future UFO+shot;
10..63: rotating asteroid/pickup render pool (54 hardware sprites).
ZP $42: persistent round-robin cursor; $43/$44: record pointer;
$4B: current record, $4C: OAM offset, $4D: tile, $4E: free sprites,
$4F/$50: coordinates, $51: records left. All scratch is main-only.
"""
from pathlib import Path
P = Path(__file__).parent
source = (P/'build_v15.py').read_text()
start = source.index('render_asteroids:\n')
end = source.index('render_title:\n', start)
assembly = '''render_asteroids:
LDA #$28
STA $4C
LDA #$36
STA $4E
LDA #$30
STA $51
LDA $42
STA $4B
CLC
ADC #$05
CMP #$30
BCC rotation_ready
SEC
SBC #$30
rotation_ready:
STA $42
render_pool_loop:
LDX $4B
LDA render_record_low,X
STA $43
LDA render_record_high,X
STA $44
LDY #$08
LDA ($43),Y
BNE render_pool_active
JMP render_pool_next
render_pool_active:
CMP #$03
BEQ render_pool_small
LDA $4E
CMP #$04
BCS render_pool_big_fits
JMP render_pool_next
render_pool_big_fits:
LDA ($43),Y
CMP #$01
BEQ render_pool_large
LDA #$17
JMP render_pool_big
render_pool_large:
LDA #$13
render_pool_big:
STA $4D
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
STA $50
JSR render_pool_tile
INC $4D
LDA $4F
CLC
ADC #$08
STA $4F
JSR render_pool_tile
INC $4D
LDA $4F
SEC
SBC #$08
STA $4F
LDA $50
CLC
ADC #$08
CMP #$F0
BCC render_pool_bottom_ready
SEC
SBC #$F0
render_pool_bottom_ready:
STA $50
JSR render_pool_tile
INC $4D
LDA $4F
CLC
ADC #$08
STA $4F
JSR render_pool_tile
JMP render_pool_next
render_pool_small:
LDA $4E
BEQ render_pool_next
LDA #$12
STA $4D
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
STA $50
JSR render_pool_tile
render_pool_next:
INC $4B
LDA $4B
CMP #$30
BCC render_pool_no_wrap
LDA #$00
STA $4B
render_pool_no_wrap:
DEC $51
BEQ render_pool_done
JMP render_pool_loop
render_pool_done:
RTS
render_pool_tile:
LDY $4C
LDA $50
SEC
SBC #$01
STA $0200,Y
LDA $4D
STA $0201,Y
LDA #$01
STA $0202,Y
LDA $4F
STA $0203,Y
TYA
CLC
ADC #$04
STA $4C
DEC $4E
RTS
'''
source = source[:start] + assembly + source[end:]
source = source.replace("data={}\n", "data={}\ndata['render_record_low']=[(n*16)&255 for n in range(48)]\ndata['render_record_high']=[3+n//16 for n in range(48)]\n")
source = source.replace('asteroids_nes_v15_wave_transition.nes', 'asteroids_nes_v16_oam_rotation.nes')
source = source.replace('prototype_v15.asm', 'prototype_v16.asm').replace('symbols_v15.json', 'symbols_v16.json')
exec(compile(source, str(P/'build_v15.py'), 'exec'))
