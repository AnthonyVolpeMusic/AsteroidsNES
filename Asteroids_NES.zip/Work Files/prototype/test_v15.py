"""V15 tests execute the assembled 6502 ROM, including NMI/main frames."""
from pathlib import Path
import json
from py65.devices.mpu6502 import MPU

P = Path(__file__).parent
S = json.loads((P/'symbols_v15.json').read_text())
class Memory(list):
    def __init__(self):
        super().__init__([0]*65536)
        self.pad = self.index = 0
    def __getitem__(self, k):
        if k == 0x2002: return 0x80
        if k == 0x4016:
            v = (self.pad >> (7-self.index)) & 1 if self.index < 8 else 1
            self.index += 1
            return v
        return super().__getitem__(k)
    def __setitem__(self, k, v):
        if k == 0x4016: self.index = 0
        super().__setitem__(k, v)
m = Memory()
m[0x8000:] = (P/'asteroids_nes_v15_wave_transition.nes').read_bytes()[16:32784]
c = MPU(memory=m, pc=S['reset'])
for _ in range(100000):
    c.step()
    if c.pc == S['main']: break
else: raise AssertionError('boot timeout')
def frame(pad=0):
    m.pad = pad
    c.nmi()
    for _ in range(100000):
        c.step()
        if c.pc == S['main'] and m[0] == 1: return
    raise AssertionError('frame timeout')
def call(name):
    c.pc = S[name]
    c.sp = 0xff
    c.stPushWord(0x7ffe)
    for _ in range(100000):
        c.step()
        if c.pc == 0x7fff: return
    raise AssertionError(name+' timeout')
records = range(0x300, 0x600, 16)
def clear():
    for a in records: m[a:a+16] = [0]*16
def kinds(): return [m[a+8] for a in records if m[a+8]]
clear()
for _ in range(250): frame()
assert m[0x40] == 0 and m[6] == 0, 'title must not advance waves'
frame(0x10)
assert kinds() == [1]*4 and m[0x3f] == 4
frame()
# The actual final collision arms the countdown on that same main-loop frame.
clear()
m[0x5f8] = 3
m[0x5f1] = m[0x5f3] = 100
m[0x600:0x610] = [47,0,104,0,104,0,0,0,0,0,12,0,0,0,0,0]
frame()
assert not kinds() and m[0x40] == 240 and m[0x30] == 100
score = m[0x30:0x39]
for _ in range(239): frame()
assert m[0x40] == 1 and not kinds() and m[0x3f] == 4
m[3] = 20
m[7] = 1
m[0x14:0x18] = [32,1,32,1]
m[0x600:0x610] = [15,0,20,0,20,0,0,0,0,1,0,0,0,0,0,0]
frame()
assert kinds() == [1]*5 and m[0x3f] == 5
assert m[3] == 0 and m[0x10:0x18] == [0,128,0,120,0,0,0,0]
assert m[7] == 5 and m[8] == 0 and not any(m[0x600:0x640])
assert m[0x30:0x39] == score and m[0x39] == 0 and m[0x3d] == 3
# All three asteroid pages, grace-protected children, and future enemies block.
for addr in (0x300,0x400,0x5f0):
    clear()
    m[addr+8] = 2
    m[addr+10] = 3
    m[0x40] = 5
    call('wave_tick')
    assert m[0x40] == 0
clear()
m[0x41] = 1
call('wave_tick')
assert m[0x40] == 0
m[0x41] = 0
# Full countdown on each successive wave, including repeated capped waves.
for expected in (6,7,8,9,10,11,12,12,12):
    clear()
    call('wave_tick')
    assert m[0x40] == 240
    for _ in range(239): call('wave_tick')
    assert not kinds()
    call('wave_tick')
    assert kinds() == [1]*expected and m[0x3f] == expected
print('PASS V15: final-hit trigger; exactly 240 subsequent frames; ship/projectile/SUPER reset; score/lives preserved; all pages and enemies gate; waves 4 through 12 and cap.')
