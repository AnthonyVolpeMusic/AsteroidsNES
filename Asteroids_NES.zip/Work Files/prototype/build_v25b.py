"""V25b: transition-only triangle shutdown; SFX keep their own lifetime.

This is a candidate mitigation for reported inter-wave silence in OpenEMU.
The original symptom has not reproduced in the CPU/APU-register harness.
"""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v25a.py').read_text(),str(P/'build_v25a.py'),'exec'))
def change25b(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)

change25b('''asteroid_pulse_off24:
LDA #$00
STA $067F
LDA $86
AND #$0B
STA $86
STA $4015
RTS''','''asteroid_pulse_off24:
LDA #$00
STA $067F
LDA $86
AND #$04
BEQ triangle_already_off25b
LDA $86
AND #$0B
STA $86
STA $4015
triangle_already_off25b:
RTS''')
for old,new in [('asteroids_nes_v25a_audio_fix.nes','asteroids_nes_v25b_wave_audio.nes'),('symbols_v25a.json','symbols_v25b.json'),('prototype_v25a.asm','prototype_v25b.asm')]:
    change25b(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
