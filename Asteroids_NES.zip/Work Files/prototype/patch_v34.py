"""Adaptive presentation with two ordinary simulation steps per 30 Hz image.

ZP $A0 refresh serial, $A1 batch interval (1/2), $A2 NMI countdown,
$A3 simulation steps remaining. These bytes are outside all previous allocations.
No velocity doubling or collision-skipping: each substep uses the existing engine.
NMI holds the old display until BOTH the deadline and complete OAM buffer are ready.
"""
patch31('''main:
LDA $00
BNE main
JSR sfx_tick25''','''main:
LDA $00
BNE main
JSR frame_begin34
simulation_step34:
JSR sfx_tick25''')
patch31('''JSR pulse_gate24c
JSR render
LDA #$01
STA $00
JMP main''','''JSR pulse_gate24c
JSR shield_phase34
DEC $A3
BEQ frame_render34
LDA $06
BEQ frame_render34
LDA $0677
CMP #$03
BEQ frame_render34
JMP simulation_step34
frame_render34:
JSR render
LDA #$01
STA $00
JMP main''')
# Count hardware refreshes even while simulation/rendering is busy. No DMA or
# PPU writes until the batch is complete and its one/two-refresh deadline arrives.
patch31('''TYA
PHA
LDA $00
BNE nmi_active31''','''TYA
PHA
INC $A0
LDA $A2
BEQ nmi_deadline34
DEC $A2
BEQ nmi_deadline34
JMP nmi_done
nmi_deadline34:
LDA $00
BNE nmi_active31''')

# Palette animation must advance with simulation ticks, not render frequency.
patch31('LDA $8D\nINC $8D\nLSR A','LDA $8D\nSEC\nSBC #$01\nLSR A')

# Hidden OAM entries need only a hidden Y. All visible render paths write their
# own four bytes. Unrolling avoids a full 256-byte clear every rendered frame.
patch31('''LDX #$00
LDA #$F8
hide:
STA $0200,X
INX
BNE hide''','LDA #$F8\nhide:\n'+'\n'.join(f'STA ${0x200+i:04X}' for i in range(0,256,4)))

# Inactive regular records were still being moved. Title rocks deliberately
# have no activity flags, so only gameplay uses this fast skip.
for page in (0x300,0x400,0x500):
    tag=f'{page:04x}'
    patch31(f'BNE asteroid_loop{tag}',f'''BEQ asteroid_page_done34_{tag}
JMP asteroid_loop{tag}
asteroid_page_done34_{tag}:''')
    # Regular asteroid velocity tables are all below one pixel per tick. In a
    # conservative interior rectangle, normal fixed-point addition is exactly
    # the same result as the general wall solver. Near every edge keep that solver.
    patch31(f'JSR rock{tag}_bounce31\n',f'''LDA ${page+1:04X},X
CMP #$10
BCC rock_wall34_{tag}
CMP #$E0
BCS rock_wall34_{tag}
LDA ${page+3:04X},X
CMP #$20
BCC rock_wall34_{tag}
CMP #$C6
BCS rock_wall34_{tag}
JMP rock{tag}_arcade31
rock_wall34_{tag}:
JSR rock{tag}_bounce31
''')
    patch31(f'asteroid_loop{tag}:\n',f'''asteroid_loop{tag}:
LDA $06
BEQ asteroid_live34_{tag}
LDA ${page+8:04X},X
BNE asteroid_live34_{tag}
JMP rock{tag}_moved31
asteroid_live34_{tag}:
''')
    # Same hitbox dimensions, fewer branches per tested live asteroid.
    old=f'''LDA $26
CMP #$01
BEQ collision_width_large_{tag}
CMP #$02
BEQ collision_width_medium_{tag}
LDA #$08
JMP collision_width_ready_{tag}
collision_width_large_{tag}:
LDA #$10
JMP collision_width_ready_{tag}
collision_width_medium_{tag}:
LDA #$0C
collision_width_ready_{tag}:
STA $2B'''
    patch31(old,f'''LDY $26
LDA hazard_width21,Y
STA $2B''')

for prefix in ('l','m','s'):
    for axis in ('x','y'):
        for lo,hi in zip(data[prefix+axis+'lo'],data[prefix+axis+'hi']):
            velocity=lo+(hi<<8)
            if velocity>=32768:velocity-=65536
            assert abs(velocity)<256,'Interior shortcut requires subpixel asteroid speeds'

# Replay initializes a new level; discard the previous game's cached load.
patch31('set_game_rocks:\n','''set_game_rocks:
LDA #$00
STA $9D
STA $9E
''')

code+='''
frame_begin34:
LDA $06
BEQ frame_force60_34
LDA $0677
CMP #$03
BEQ frame_force60_34
LDA $8E
BEQ frame_arcade34
LDX #$0F
LDY #$0D
BNE frame_compare34
frame_arcade34:
LDX #$16
LDY #$14
frame_compare34:
LDA $A1
CMP #$02
BNE frame_entry34
TYA
CMP $9E
BCS frame_test_exit34
LDA #$02
BNE frame_commit34
frame_test_exit34:
BEQ frame_stay30_34
JMP frame_force60_34
frame_stay30_34:
LDA #$02
BNE frame_commit34
frame_entry34:
TXA
CMP $9E
BCC frame_stay30_34
BEQ frame_stay30_34
frame_force60_34:
LDA #$01
frame_commit34:
STA $A1
STA $A2
STA $A3
RTS
shield_phase34:
LDA $08
BEQ shield_phase_off34
INC $8D
RTS
shield_phase_off34:
LDA #$00
STA $8D
RTS
'''
lines=[s.strip() for s in code.splitlines() if s.strip()]
