"""V19a: existing hunter regression plus exhaustive nonzero random seeds."""
from pathlib import Path
P=Path(__file__).parent
base=(P/'test_v19.py').read_text().replace('symbols_v19.json','symbols_v19a.json').replace('asteroids_nes_v19_murderoids.nes','asteroids_nes_v19a_edge_murderoids.nes')
exec(compile(base,str(P/'test_v19.py'),'exec'))
walls=set();along_x=set();along_y=set()
for sx,sy in [(0,0),(248,0),(0,232),(248,232),(123,115),(124,116),(125,117),(128,120),(255,239)]:
    for seed in range(1,256):
        mreset();m[0x11]=sx;m[0x13]=sy;m[0x2f]=seed
        call('random');vertical=bool(c.a&1)
        m[0x2f]=seed
        call('murder_spawn_check')
        assert hunters()=={0x680:1}
        x,y=m[0x681],m[0x683]
        assert 0<=x<=240 and 0<=y<=224,(sx,sy,seed,x,y)
        if vertical:
            assert x==(240 if sx<124 else 0),(sx,sy,x,y)
            walls.add('right' if x else 'left');along_y.add(y)
        else:
            assert y==(224 if sy<116 else 0),(sx,sy,x,y)
            walls.add('bottom' if y else 'top');along_x.add(x)
assert walls=={'left','right','top','bottom'}
assert len(along_x)>90 and len(along_y)>90
print('PASS 2295 spawn cases: farthest wall, both axis choices, random along-wall positions, full 16x16 bounds')
