reset:
SEI
CLD
LDX #$40
STX $4017
LDX #$FF
TXS
INX
STX $2000
STX $2001
STX $4010
STX $4015
BIT $2002
warm1:
BIT $2002
BPL warm1
LDA #$00
clear:
STA $0000,X
STA $0100,X
STA $0200,X
STA $0300,X
STA $0400,X
STA $0600,X
STA $0600,X
STA $0700,X
INX
BNE clear
warm2:
BIT $2002
BPL warm2
LDA #$20
STA $2006
LDA #$00
STA $2006
LDY #$10
LDX #$00
blank:
STA $2007
INX
BNE blank
DEY
BNE blank
LDA #$3F
STA $2006
LDA #$00
STA $2006
LDX #$00
pal:
LDA palette,X
STA $2007
INX
CPX #$20
BNE pal
LDX #$00
load_asteroids:
LDA asteroid_init0,X
STA $0300,X
LDA asteroid_init1,X
STA $0400,X
LDA asteroid_init2,X
STA $0500,X
INX
BNE load_asteroids
JSR load_title
LDA #$80
STA $11
LDA #$78
STA $13
LDA #$01
STA $00
LDA #$05
STA $07
LDA #$03
STA $3D
LDA #$04
STA $3F
LDA #$20
STA $3A
LDA #$4E
STA $3B
LDA #$A5
STA $2F
LDA #$10
STA $3E
LDA #$88
STA $2000
LDA #$1E
STA $2001
main:
LDA $00
BNE main
JSR controls
JSR shield_tick
JSR physics
JSR bullets
JSR asteroids
JSR collisions
JSR ufo_tick
JSR ufo_collisions
JSR wave_tick
JSR render
LDA #$01
STA $00
JMP main
nmi:
PHA
TXA
PHA
TYA
PHA
LDA $00
BEQ nmi_done
LDA #$00
STA $2003
LDA #$02
STA $4014
LDA $06
BEQ nmi_hud_done
LDA #$20
STA $2006
LDA #$26
STA $2006
LDX #$00
nmi_score:
LDA $33,X
CLC
ADC #$7B
STA $2007
INX
CPX #$06
BNE nmi_score
LDA #$20
STA $2006
LDA #$35
STA $2006
LDA $07
CLC
ADC #$7B
STA $2007
LDA #$20
STA $2006
LDA #$3F
STA $2006
LDA $3D
CLC
ADC #$7B
STA $2007
nmi_hud_done:
LDA #$00
STA $2005
STA $2005
STA $00
nmi_done:
PLA
TAY
PLA
TAX
PLA
RTI
irq:
RTI
load_title:
LDA #$20
STA $2006
LDA #$00
STA $2006
LDX #$00
load_title_page0:
LDA title_nt0,X
STA $2007
INX
BNE load_title_page0
LDX #$00
load_title_page1:
LDA title_nt1,X
STA $2007
INX
BNE load_title_page1
LDX #$00
load_title_page2:
LDA title_nt2,X
STA $2007
INX
BNE load_title_page2
LDX #$00
load_title_page3:
LDA title_nt3,X
STA $2007
INX
BNE load_title_page3
RTS
blank_title:
LDA #$00
STA $2001
LDA #$20
STA $2006
LDA #$00
STA $2006
LDY #$04
LDX #$00
blank_title_loop:
LDA #$00
STA $2007
INX
BNE blank_title_loop
DEY
BNE blank_title_loop
JSR load_hud
LDA #$1E
STA $2001
RTS
load_hud:
LDA #$20
STA $2006
LDA #$20
STA $2006
LDX #$00
load_hud_loop:
LDA hud_line,X
STA $2007
INX
CPX #$20
BNE load_hud_loop
RTS
controls:
LDA $01
STA $02
LDA #$01
STA $4016
LDA #$00
STA $4016
STA $01
LDX #$08
readpad:
LDA $4016
LSR A
ROL $01
DEX
BNE readpad
LDA $06
BNE game_controls
LDA $02
EOR #$FF
AND $01
AND #$10
BEQ title_controls_done
JSR blank_title
JSR ufo_init
JSR set_game_rocks
LDA #$01
STA $06
title_controls_done:
RTS
game_controls:
LDA $02
EOR #$FF
AND $01
AND #$40
BNE special_pressed
JMP game_normal
special_pressed:
LDA $07
BNE special_has_power
JMP game_normal
special_has_power:
LDA $01
AND #$04
BNE special_stop
LDA $01
AND #$08
BNE special_rainbow
LDA $08
BEQ shield_available
JMP game_normal
shield_available:
DEC $07
LDA #$3C
STA $08
JMP game_normal
special_stop:
DEC $07
LDA #$00
STA $14
STA $15
STA $16
STA $17
RTS
special_rainbow:
LDX #$00
rainbow_check:
LDA $0600,X
BEQ rainbow_slot_clear
RTS
rainbow_slot_clear:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE rainbow_check
DEC $07
LDX #$00
LDA #$00
STA $21
rainbow_loop:
LDY $21
LDA $03
CLC
ADC rainbow_offsets,Y
CMP #$30
BCC rainbow_heading_ok
SBC #$30
rainbow_heading_ok:
TAY
LDA #$30
STA $0600,X
LDA $10
STA $0601,X
LDA $11
STA $0602,X
LDA $12
STA $0603,X
LDA $13
STA $0604,X
CLC
LDA $14
ADC bxlo,Y
STA $0605,X
LDA $15
ADC bxhi,Y
STA $0606,X
CLC
LDA $16
ADC bylo,Y
STA $0607,X
LDA $17
ADC byhi,Y
STA $0608,X
TYA
STA $060A,X
INC $21
TXA
CLC
ADC #$10
TAX
LDA $21
CMP #$04
BNE rainbow_loop
RTS
game_normal:
LDA $04
BEQ rot_ready
DEC $04
JMP flip
rot_ready:
LDA $01
AND #$03
CMP #$01
BEQ right
CMP #$02
BNE flip
LDA $03
BNE left_nonzero
LDA #$30
left_nonzero:
SEC
SBC #$01
STA $03
JMP rot_delay
right:
INC $03
LDA $03
CMP #$30
BCC rot_delay
LDA #$00
STA $03
rot_delay:
LDA #$01
STA $04
flip:
LDA $02
EOR #$FF
AND $01
AND #$04
BEQ thrust
LDA $03
CLC
ADC #$18
CMP #$30
BCC flip_save
SBC #$30
flip_save:
STA $03
thrust:
LDA $01
AND #$08
BEQ shoot
LDX $03
CLC
LDA $14
ADC axlo,X
STA $14
LDA $15
ADC axhi,X
STA $15
BPL positive20
CMP #$FE
BCS capped20
LDA #$FE
STA $15
LDA #$00
STA $14
JMP capped20
positive20:
CMP #$02
BCC capped20
LDA #$02
STA $15
LDA #$00
STA $14
capped20:
CLC
LDA $16
ADC aylo,X
STA $16
LDA $17
ADC ayhi,X
STA $17
BPL positive22
CMP #$FE
BCS capped22
LDA #$FE
STA $17
LDA #$00
STA $16
JMP capped22
positive22:
CMP #$02
BCC capped22
LDA #$02
STA $17
LDA #$00
STA $16
capped22:
shoot:
LDA $05
BEQ can_shoot
DEC $05
RTS
can_shoot:
LDA $01
AND #$80
BEQ controls_done
LDX #$00
find_slot:
LDA $0600,X
BEQ spawn
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE find_slot
RTS
spawn:
LDA #$30
STA $0600,X
LDA #$08
STA $05
LDY $03
LDA $10
STA $0601,X
LDA $11
STA $0602,X
LDA $12
STA $0603,X
LDA $13
STA $0604,X
CLC
LDA $14
ADC bxlo,Y
STA $0605,X
LDA $15
ADC bxhi,Y
STA $0606,X
CLC
LDA $16
ADC bylo,Y
STA $0607,X
LDA $17
ADC byhi,Y
STA $0608,X
TYA
STA $060A,X
controls_done:
RTS
shield_tick:
LDA $08
BEQ shield_done
DEC $08
shield_done:
RTS
physics:
CLC
LDA $10
ADC $14
STA $10
LDA $11
ADC $15
STA $11
CLC
LDA $12
ADC $16
STA $12
LDA $13
ADC $17
CMP #$F0
BCC ship_y_ok
LDX $17
BMI ship_y_negative
SEC
SBC #$F0
JMP ship_y_ok
ship_y_negative:
CLC
ADC #$F0
ship_y_ok:
STA $13
RTS
bullets:
LDX #$00
bullet_loop:
LDA $0600,X
BNE bullet_active
JMP bullet_next
bullet_active:
LDA $0609,X
BEQ bullet_flying
DEC $0600,X
BNE bullet_next
LDA #$00
STA $0609,X
JMP bullet_next
bullet_flying:
DEC $0600,X
CLC
LDA $0601,X
ADC $0605,X
STA $0601,X
LDA $0602,X
ADC $0606,X
STA $0602,X
CLC
LDA $0603,X
ADC $0607,X
STA $0603,X
LDA $0604,X
ADC $0608,X
CMP #$F0
BCC bullet_y_ok
LDY $0608,X
BMI bullet_y_negative
SEC
SBC #$F0
JMP bullet_y_ok
bullet_y_negative:
CLC
ADC #$F0
bullet_y_ok:
STA $0604,X
bullet_next:
TXA
CLC
ADC #$10
TAX
CPX #$40
BEQ bullets_done
JMP bullet_loop
bullets_done:
RTS
asteroids:
LDX #$00
asteroid_loop0300:
LDA $030A,X
BEQ asteroid_grace_done0300
DEC $030A,X
asteroid_grace_done0300:
CLC
LDA $0300,X
ADC $0304,X
STA $0300,X
LDA $0301,X
ADC $0305,X
STA $0301,X
CLC
LDA $0302,X
ADC $0306,X
STA $0302,X
LDA $0303,X
ADC $0307,X
CMP #$F0
BCC asteroid_y_ok0300
LDY $0307,X
BMI asteroid_y_negative0300
SEC
SBC #$F0
JMP asteroid_y_ok0300
asteroid_y_negative0300:
CLC
ADC #$F0
asteroid_y_ok0300:
STA $0303,X
TXA
CLC
ADC #$10
TAX
BNE asteroid_loop0300
LDX #$00
asteroid_loop0400:
LDA $040A,X
BEQ asteroid_grace_done0400
DEC $040A,X
asteroid_grace_done0400:
CLC
LDA $0400,X
ADC $0404,X
STA $0400,X
LDA $0401,X
ADC $0405,X
STA $0401,X
CLC
LDA $0402,X
ADC $0406,X
STA $0402,X
LDA $0403,X
ADC $0407,X
CMP #$F0
BCC asteroid_y_ok0400
LDY $0407,X
BMI asteroid_y_negative0400
SEC
SBC #$F0
JMP asteroid_y_ok0400
asteroid_y_negative0400:
CLC
ADC #$F0
asteroid_y_ok0400:
STA $0403,X
TXA
CLC
ADC #$10
TAX
BNE asteroid_loop0400
LDX #$00
asteroid_loop0500:
LDA $050A,X
BEQ asteroid_grace_done0500
DEC $050A,X
asteroid_grace_done0500:
CLC
LDA $0500,X
ADC $0504,X
STA $0500,X
LDA $0501,X
ADC $0505,X
STA $0501,X
CLC
LDA $0502,X
ADC $0506,X
STA $0502,X
LDA $0503,X
ADC $0507,X
CMP #$F0
BCC asteroid_y_ok0500
LDY $0507,X
BMI asteroid_y_negative0500
SEC
SBC #$F0
JMP asteroid_y_ok0500
asteroid_y_negative0500:
CLC
ADC #$F0
asteroid_y_ok0500:
STA $0503,X
TXA
CLC
ADC #$10
TAX
BNE asteroid_loop0500
RTS
collisions:
LDX #$00
collision_bullet:
LDA $0600,X
BEQ collision_bullet_inactive
LDA $0609,X
BEQ collision_bullet_live
collision_bullet_inactive:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE collision_bullet_continue_inactive
JMP collision_done
collision_bullet_continue_inactive:
JMP collision_bullet
collision_bullet_live:
STX $22
LDA $0602,X
STA $23
LDA $0604,X
STA $24
LDA $060A,X
STA $27
LDX #$00
collision_rocks_0300:
LDA $0308,X
BNE collision_rock_active_0300
JMP collision_rock_next_0300
collision_rock_active_0300:
STA $26
LDA $030A,X
BEQ collision_rock_ready_0300
JMP collision_rock_next_0300
collision_rock_ready_0300:
LDA $26
CMP #$01
BEQ collision_width_large_0300
CMP #$02
BEQ collision_width_medium_0300
LDA #$08
JMP collision_width_ready_0300
collision_width_large_0300:
LDA #$10
JMP collision_width_ready_0300
collision_width_medium_0300:
LDA #$0C
collision_width_ready_0300:
STA $2B
LDA $23
SEC
SBC $0301,X
CMP $2B
BCC collision_x_ok_0300
CMP #$FD
BCS collision_x_ok_0300
JMP collision_rock_next_0300
collision_x_ok_0300:
LDA $24
SEC
SBC $0303,X
BCS collision_y_delta_0300
SEC
SBC #$10
collision_y_delta_0300:
CMP $2B
BCC collision_y_ok_0300
CMP #$ED
BCS collision_y_ok_0300
JMP collision_rock_next_0300
collision_y_ok_0300:
JSR collision_explode
TXA
STA $45
LDA #$03
STA $46
LDA $26
CMP #$01
BEQ collision_large_0300
CMP #$02
BEQ collision_medium_0300
LDY #$08
LDA #$00
STA ($45),Y
INC $39
LDA #$64
JSR score_add
JMP collision_next_bullet
collision_large_0300:
JSR spawn_mediums_generic
LDA #$19
JSR score_add
JMP collision_next_bullet
collision_medium_0300:
JSR spawn_smalls_generic
LDA #$32
JSR score_add
JMP collision_next_bullet
collision_rock_next_0300:
TXA
CLC
ADC #$10
TAX
BNE collision_rocks_continue_0300
JMP collision_rocks_done_0300
collision_rocks_continue_0300:
JMP collision_rocks_0300
collision_rocks_done_0300:
LDX #$00
collision_rocks_0400:
LDA $0408,X
BNE collision_rock_active_0400
JMP collision_rock_next_0400
collision_rock_active_0400:
STA $26
LDA $040A,X
BEQ collision_rock_ready_0400
JMP collision_rock_next_0400
collision_rock_ready_0400:
LDA $26
CMP #$01
BEQ collision_width_large_0400
CMP #$02
BEQ collision_width_medium_0400
LDA #$08
JMP collision_width_ready_0400
collision_width_large_0400:
LDA #$10
JMP collision_width_ready_0400
collision_width_medium_0400:
LDA #$0C
collision_width_ready_0400:
STA $2B
LDA $23
SEC
SBC $0401,X
CMP $2B
BCC collision_x_ok_0400
CMP #$FD
BCS collision_x_ok_0400
JMP collision_rock_next_0400
collision_x_ok_0400:
LDA $24
SEC
SBC $0403,X
BCS collision_y_delta_0400
SEC
SBC #$10
collision_y_delta_0400:
CMP $2B
BCC collision_y_ok_0400
CMP #$ED
BCS collision_y_ok_0400
JMP collision_rock_next_0400
collision_y_ok_0400:
JSR collision_explode
TXA
STA $45
LDA #$04
STA $46
LDA $26
CMP #$01
BEQ collision_large_0400
CMP #$02
BEQ collision_medium_0400
LDY #$08
LDA #$00
STA ($45),Y
INC $39
LDA #$64
JSR score_add
JMP collision_next_bullet
collision_large_0400:
JSR spawn_mediums_generic
LDA #$19
JSR score_add
JMP collision_next_bullet
collision_medium_0400:
JSR spawn_smalls_generic
LDA #$32
JSR score_add
JMP collision_next_bullet
collision_rock_next_0400:
TXA
CLC
ADC #$10
TAX
BNE collision_rocks_continue_0400
JMP collision_rocks_done_0400
collision_rocks_continue_0400:
JMP collision_rocks_0400
collision_rocks_done_0400:
LDX #$00
collision_rocks_0500:
LDA $0508,X
BNE collision_rock_active_0500
JMP collision_rock_next_0500
collision_rock_active_0500:
STA $26
LDA $050A,X
BEQ collision_rock_ready_0500
JMP collision_rock_next_0500
collision_rock_ready_0500:
LDA $26
CMP #$01
BEQ collision_width_large_0500
CMP #$02
BEQ collision_width_medium_0500
LDA #$08
JMP collision_width_ready_0500
collision_width_large_0500:
LDA #$10
JMP collision_width_ready_0500
collision_width_medium_0500:
LDA #$0C
collision_width_ready_0500:
STA $2B
LDA $23
SEC
SBC $0501,X
CMP $2B
BCC collision_x_ok_0500
CMP #$FD
BCS collision_x_ok_0500
JMP collision_rock_next_0500
collision_x_ok_0500:
LDA $24
SEC
SBC $0503,X
BCS collision_y_delta_0500
SEC
SBC #$10
collision_y_delta_0500:
CMP $2B
BCC collision_y_ok_0500
CMP #$ED
BCS collision_y_ok_0500
JMP collision_rock_next_0500
collision_y_ok_0500:
JSR collision_explode
TXA
STA $45
LDA #$05
STA $46
LDA $26
CMP #$01
BEQ collision_large_0500
CMP #$02
BEQ collision_medium_0500
LDY #$08
LDA #$00
STA ($45),Y
INC $39
LDA #$64
JSR score_add
JMP collision_next_bullet
collision_large_0500:
JSR spawn_mediums_generic
LDA #$19
JSR score_add
JMP collision_next_bullet
collision_medium_0500:
JSR spawn_smalls_generic
LDA #$32
JSR score_add
JMP collision_next_bullet
collision_rock_next_0500:
TXA
CLC
ADC #$10
TAX
BNE collision_rocks_continue_0500
JMP collision_rocks_done_0500
collision_rocks_continue_0500:
JMP collision_rocks_0500
collision_rocks_done_0500:
collision_next_bullet:
LDX $22
TXA
CLC
ADC #$10
TAX
CPX #$40
BEQ collision_done
JMP collision_bullet
collision_done:
RTS
collision_explode:
LDY $22
LDA #$0F
STA $0600,Y
LDA #$01
STA $0609,Y
LDA #$00
STA $0605,Y
STA $0606,Y
STA $0607,Y
STA $0608,Y
RTS
score_add:
STA $25
CLC
LDA $30
ADC $25
STA $30
LDA $31
ADC #$00
STA $31
LDA $32
ADC #$00
STA $32
score_add_loop:
JSR score_increment
DEC $25
BNE score_add_loop
LDA $32
CMP $3C
BCC score_check_done
BNE score_extra_life
LDA $31
CMP $3B
BCC score_check_done
BNE score_extra_life
LDA $30
CMP $3A
BCC score_check_done
score_extra_life:
INC $3D
CLC
LDA $3A
ADC #$20
STA $3A
LDA $3B
ADC #$4E
STA $3B
LDA $3C
ADC #$00
STA $3C
score_check_done:
RTS
score_increment:
INC $38
LDA $38
CMP #$0A
BCC score_inc_done
LDA #$00
STA $38
INC $37
LDA $37
CMP #$0A
BCC score_inc_done
LDA #$00
STA $37
INC $36
LDA $36
CMP #$0A
BCC score_inc_done
LDA #$00
STA $36
INC $35
LDA $35
CMP #$0A
BCC score_inc_done
LDA #$00
STA $35
INC $34
LDA $34
CMP #$0A
BCC score_inc_done
LDA #$00
STA $34
INC $33
LDA $33
CMP #$0A
BCC score_inc_done
LDA #$00
STA $33
score_inc_done:
RTS
spawn_mediums_generic:
LDA #$02
STA $2D
JMP spawn_children_generic
spawn_smalls_generic:
LDA #$03
STA $2D
spawn_children_generic:
LDY #$01
LDA ($45),Y
STA $47
LDY #$03
LDA ($45),Y
STA $48
JSR allocate_asteroid_record
LDA $43
STA $49
LDA $44
STA $4A
LDA $45
STA $43
LDA $46
STA $44
JSR fragment_clockwise
STA $2E
JSR write_fragment
LDA $49
STA $43
LDA $4A
STA $44
JSR fragment_counterclockwise
STA $2E
JSR write_fragment
RTS
allocate_asteroid_record:
LDX #$00
allocate_page3:
LDA $0308,X
BEQ allocate_found3
TXA
CLC
ADC #$10
TAX
BNE allocate_page3
LDX #$00
allocate_page4:
LDA $0408,X
BEQ allocate_found4
TXA
CLC
ADC #$10
TAX
BNE allocate_page4
LDX #$00
allocate_page5:
LDA $0508,X
BEQ allocate_found5
TXA
CLC
ADC #$10
TAX
BNE allocate_page5
RTS
allocate_found3:
STX $43
LDA #$03
STA $44
RTS
allocate_found4:
STX $43
LDA #$04
STA $44
RTS
allocate_found5:
STX $43
LDA #$05
STA $44
RTS
write_fragment:
LDY #$00
LDA #$00
STA ($43),Y
LDY #$01
LDX $2E
LDA $47
CLC
ADC spawnxoff,X
STA ($43),Y
LDY #$02
LDA #$00
STA ($43),Y
LDY #$03
LDA $48
CLC
ADC spawnyoff,X
CMP #$F0
BCC fragment_y_ok
SEC
SBC #$F0
fragment_y_ok:
STA ($43),Y
LDA $2D
CMP #$02
BEQ write_medium_velocity
LDX $2E
LDY #$04
LDA sxlo,X
STA ($43),Y
LDY #$05
LDA sxhi,X
STA ($43),Y
LDY #$06
LDA sylo,X
STA ($43),Y
LDY #$07
LDA syhi,X
STA ($43),Y
JMP write_fragment_finish
write_medium_velocity:
LDX $2E
LDY #$04
LDA mxlo,X
STA ($43),Y
LDY #$05
LDA mxhi,X
STA ($43),Y
LDY #$06
LDA mylo,X
STA ($43),Y
LDY #$07
LDA myhi,X
STA ($43),Y
write_fragment_finish:
LDY #$08
LDA $2D
STA ($43),Y
LDY #$09
LDA $2E
STA ($43),Y
LDY #$0A
LDA #$03
STA ($43),Y
RTS
random:
LDA $2F
ASL A
BCC random_no_xor
EOR #$1D
random_no_xor:
STA $2F
RTS
random_13:
JSR random
AND #$0F
CMP #$0D
BCC random_13_done
SEC
SBC #$0D
random_13_done:
RTS
normalize_heading:
BMI normalize_negative
CMP #$30
BCC normalize_done
SEC
SBC #$30
RTS
normalize_negative:
CLC
ADC #$30
normalize_done:
RTS
fragment_clockwise:
JSR random_13
CLC
ADC $27
JMP normalize_heading
fragment_counterclockwise:
JSR random_13
STA $28
LDA $27
SEC
SBC $28
JMP normalize_heading
large_velocity_page0:
STA $0309,X
TAY
LDA lxlo,Y
STA $0304,X
LDA lxhi,Y
STA $0305,X
LDA lylo,Y
STA $0306,X
LDA lyhi,Y
STA $0307,X
RTS
medium_velocity_page0:
STA $0309,Y
TAX
LDA mxlo,X
STA $0304,Y
LDA mxhi,X
STA $0305,Y
LDA mylo,X
STA $0306,Y
LDA myhi,X
STA $0307,Y
LDA $0301,Y
CLC
ADC spawnxoff,X
STA $0301,Y
LDA $0303,Y
CLC
ADC spawnyoff,X
CMP #$F0
BCC medium_spawn_y_ok
SEC
SBC #$F0
medium_spawn_y_ok:
STA $0303,Y
RTS
small_velocity_page0:
STA $0309,Y
TAX
LDA sxlo,X
STA $0304,Y
LDA sxhi,X
STA $0305,Y
LDA sylo,X
STA $0306,Y
LDA syhi,X
STA $0307,Y
LDA $0301,Y
CLC
ADC spawnxoff,X
STA $0301,Y
LDA $0303,Y
CLC
ADC spawnyoff,X
CMP #$F0
BCC small0_spawn_y_ok
SEC
SBC #$F0
small0_spawn_y_ok:
STA $0303,Y
RTS
small_velocity_page1:
STA $0409,Y
TAX
LDA sxlo,X
STA $0404,Y
LDA sxhi,X
STA $0405,Y
LDA sylo,X
STA $0406,Y
LDA syhi,X
STA $0407,Y
LDA $0401,Y
CLC
ADC spawnxoff,X
STA $0401,Y
LDA $0403,Y
CLC
ADC spawnyoff,X
CMP #$F0
BCC small1_spawn_y_ok
SEC
SBC #$F0
small1_spawn_y_ok:
STA $0403,Y
RTS
ufo_init:
LDA #$58
STA $064A
LDA #$02
STA $064B
ufo_wave_reset:
LDA #$00
STA $0640
STA $0647
STA $0650
STA $41
ufo_reload:
LDA $064A
STA $0648
LDA $064B
STA $0649
RTS
ufo_tick:
LDA $06
BNE ufo_game_tick
RTS
ufo_game_tick:
JSR ufo_shot_tick
LDA $0647
BEQ ufo_not_exploding
DEC $0647
RTS
ufo_not_exploding:
LDA $0640
BEQ ufo_idle
JMP ufo_move
ufo_idle:
LDA $40
BEQ ufo_check_rocks
RTS
ufo_check_rocks:
LDX #$00
ufo_rock_scan:
LDA $0308,X
ORA $0408,X
ORA $0508,X
BNE ufo_timer
TXA
CLC
ADC #$10
TAX
BNE ufo_rock_scan
RTS
ufo_timer:
LDA $0648
ORA $0649
BEQ ufo_spawn
LDA $0648
BNE ufo_timer_low
DEC $0649
ufo_timer_low:
DEC $0648
LDA $0648
ORA $0649
BEQ ufo_spawn
RTS
ufo_spawn:
LDA #$01
STA $0640
STA $41
LDA $3F
SEC
SBC #$04
TAX
JSR random
CMP ufo_small_chance,X
BCS ufo_size_ready
INC $0640
ufo_size_ready:
JSR random
AND #$01
STA $0643
BEQ ufo_from_left
LDA #$F4
JMP ufo_set_x
ufo_from_left:
LDA #$00
ufo_set_x:
STA $0641
JSR random
AND #$7F
CLC
ADC #$30
STA $0642
LDA #$00
STA $0644
LDA #$3C
STA $0645
LDA #$5A
STA $0646
LDA $064A
SEC
SBC #$18
STA $064A
LDA $064B
SBC #$00
STA $064B
BNE ufo_spawn_done
LDA $064A
CMP #$78
BCS ufo_spawn_done
LDA #$78
STA $064A
ufo_spawn_done:
RTS
ufo_move:
DEC $0645
BNE ufo_course_ready
LDA #$3C
STA $0645
JSR random
AND #$03
TAX
LDA #$00
CPX #$02
BCS ufo_set_course
LDA #$01
CPX #$00
BEQ ufo_set_course
LDA #$FF
ufo_set_course:
STA $0644
ufo_course_ready:
LDA $0645
AND #$01
BNE ufo_y_done
LDA $0642
CLC
ADC $0644
CMP #$20
BCC ufo_y_done
CMP #$D8
BCS ufo_y_done
STA $0642
ufo_y_done:
LDA $0640
CMP #$02
BEQ ufo_step_x
LDA $0645
AND #$01
BNE ufo_fire_timer
ufo_step_x:
LDA $0643
BNE ufo_leftward
INC $0641
LDA $0641
CMP #$F5
BCS ufo_exit
JMP ufo_fire_timer
ufo_leftward:
LDA $0641
BEQ ufo_exit
DEC $0641
ufo_fire_timer:
DEC $0646
BNE ufo_move_done
LDA #$5A
STA $0646
LDA $0650
BNE ufo_move_done
JSR ufo_fire
ufo_move_done:
RTS
ufo_exit:
LDA #$00
STA $0640
STA $41
JMP ufo_reload
ufo_fire:
LDA $0641
CLC
ADC #$02
STA $0652
LDA $0642
CLC
ADC #$02
STA $0654
LDA #$00
STA $0651
STA $0653
LDA #$60
STA $0650
LDA $0640
CMP #$02
BEQ ufo_aimed
JSR random
ufo_random_reduce:
CMP #$30
BCC ufo_heading_ready
SEC
SBC #$30
JMP ufo_random_reduce
ufo_aimed:
JSR ufo_aim_heading
ufo_heading_ready:
STA $0659
TAX
LDA ufo_xlo,X
STA $0655
LDA ufo_xhi,X
STA $0656
LDA ufo_ylo,X
STA $0657
LDA ufo_yhi,X
STA $0658
RTS
ufo_aim_heading:
LDA #$00
STA $54
STA $55
LDA $11
SEC
SBC $0652
BPL ufo_dx_positive
INC $54
EOR #$FF
CLC
ADC #$01
ufo_dx_positive:
STA $52
LDA $13
SEC
SBC $0654
BCS ufo_dy_wrapped
CLC
ADC #$F0
ufo_dy_wrapped:
CMP #$78
BCC ufo_dy_positive
SEC
SBC #$F0
BPL ufo_dy_positive
INC $55
EOR #$FF
CLC
ADC #$01
ufo_dy_positive:
STA $53
ufo_aim_scale:
LDA $52
ORA $53
CMP #$10
BCC ufo_aim_lookup
LSR $52
LSR $53
JMP ufo_aim_scale
ufo_aim_lookup:
LDA $53
ASL A
ASL A
ASL A
ASL A
ORA $52
TAX
LDA ufo_aim,X
LDX $55
BEQ ufo_aim_x_sign
STA $52
LDA #$18
SEC
SBC $52
ufo_aim_x_sign:
LDX $54
BEQ ufo_aim_normalize
STA $52
LDA #$30
SEC
SBC $52
ufo_aim_normalize:
JMP normalize_heading
ufo_shot_tick:
LDA $0650
BNE ufo_shot_live
RTS
ufo_shot_live:
DEC $0650
CLC
LDA $0651
ADC $0655
STA $0651
LDA $0652
ADC $0656
STA $0652
CLC
LDA $0653
ADC $0657
STA $0653
LDA $0654
ADC $0658
CMP #$F0
BCC ufo_shot_y_ready
LDX $0658
BMI ufo_shot_y_negative
SEC
SBC #$F0
JMP ufo_shot_y_ready
ufo_shot_y_negative:
CLC
ADC #$F0
ufo_shot_y_ready:
STA $0654
RTS
ufo_collisions:
LDA $06
BEQ ufo_collision_done
LDA $0640
BEQ ufo_collision_done
CMP #$01
BEQ ufo_hit_big
LDA #$08
JMP ufo_hit_width
ufo_hit_big:
LDA #$0C
ufo_hit_width:
STA $52
LDX #$00
ufo_hit_loop:
LDA $0600,X
BEQ ufo_hit_next
LDA $0609,X
BNE ufo_hit_next
LDA $0602,X
SEC
SBC $0641
CMP $52
BCC ufo_hit_x
CMP #$FD
BCC ufo_hit_next
ufo_hit_x:
LDA $0604,X
SEC
SBC $0642
CMP $52
BCC ufo_hit_confirm
CMP #$FD
BCC ufo_hit_next
ufo_hit_confirm:
STX $22
JSR collision_explode
LDA $0640
STA $53
LDA #$00
STA $0640
STA $41
LDA #$0F
STA $0647
JSR ufo_reload
LDA $53
CMP #$01
BEQ ufo_score_big
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
LDA #$C8
JSR score_add
ufo_score_big:
LDA #$C8
JSR score_add
RTS
ufo_hit_next:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE ufo_hit_loop
ufo_collision_done:
RTS
render_ufo:
LDA $0650
BEQ render_ufo_body
LDA $0654
SEC
SBC #$01
STA $0224
LDA #$25
STA $0225
LDA #$00
STA $0226
LDA $0652
STA $0227
render_ufo_body:
LDA $0647
BEQ render_ufo_alive
SEC
SBC #$01
TAX
LDA explosion_drawing,X
STA $0215
JMP render_ufo_single
render_ufo_alive:
LDA $0640
BNE render_ufo_exists
RTS
render_ufo_exists:
CMP #$01
BEQ render_ufo_big
LDA #$24
STA $0215
render_ufo_single:
LDA $0642
SEC
SBC #$01
STA $0214
LDA $0641
STA $0217
LDA #$00
STA $0216
RTS
render_ufo_big:
LDA $0642
SEC
SBC #$01
STA $0214
STA $0218
CLC
ADC #$08
STA $021C
STA $0220
LDA $0641
STA $0217
STA $021F
CLC
ADC #$08
STA $021B
STA $0223
LDA #$00
STA $0216
STA $021A
STA $021E
STA $0222
LDA #$20
STA $0215
LDA #$21
STA $0219
LDA #$22
STA $021D
LDA #$23
STA $0221
RTS
wave_tick:
LDA $06
BEQ wave_return
LDA $41
BNE wave_cancel
LDX #$00
wave_scan:
LDA $0308,X
ORA $0408,X
ORA $0508,X
BNE wave_cancel
TXA
CLC
ADC #$10
TAX
BNE wave_scan
LDA $40
BNE wave_countdown
LDA #$F0
STA $40
RTS
wave_countdown:
DEC $40
BNE wave_return
JSR next_wave
RTS
wave_cancel:
LDA #$00
STA $40
wave_return:
RTS
next_wave:
JSR ufo_wave_reset
LDA $3F
CMP #$0C
BCS wave_count_capped
INC $3F
wave_count_capped:
LDA #$00
STA $03
STA $04
STA $05
STA $08
STA $39
STA $40
LDX #$07
wave_reset_ship:
STA $10,X
DEX
BPL wave_reset_ship
LDX #$3F
wave_clear_projectiles:
STA $0600,X
DEX
BPL wave_clear_projectiles
LDA #$80
STA $11
LDA #$78
STA $13
LDA #$05
STA $07
JSR set_game_rocks
RTS
set_game_rocks:
LDA $3F
BNE set_game_count_ready
LDA #$04
STA $3F
set_game_count_ready:
ASL A
ASL A
ASL A
ASL A
STA $2C
LDA #$00
LDX #$00
set_game_clear_records:
STA $0300,X
STA $0400,X
STA $0500,X
INX
BNE set_game_clear_records
LDX #$00
set_game_rock_loop:
JSR random
AND #$03
BEQ spawn_left
CMP #$01
BEQ spawn_right
CMP #$02
BEQ spawn_top
spawn_bottom:
JSR random
AND #$DF
CLC
ADC #$10
STA $0301,X
LDA #$E0
STA $0303,X
LDA #$00
JMP spawn_large_heading
spawn_top:
JSR random
AND #$DF
CLC
ADC #$10
STA $0301,X
LDA #$20
STA $0303,X
LDA #$18
JMP spawn_large_heading
spawn_left:
LDA #$00
STA $0301,X
JSR random
AND #$BF
CLC
ADC #$20
STA $0303,X
LDA #$0C
JMP spawn_large_heading
spawn_right:
LDA #$F0
STA $0301,X
JSR random
AND #$BF
CLC
ADC #$20
STA $0303,X
LDA #$24
spawn_large_heading:
STA $28
JSR random_13
CLC
ADC $28
SEC
SBC #$06
JSR normalize_heading
STA $27
LDY #$08
LDA #$01
STA $0308,X
LDY #$0A
LDA #$00
STA $030A,X
LDA $27
JSR large_velocity_page0
TXA
CLC
ADC #$10
TAX
CPX $2C
BEQ set_game_rocks_done
JMP set_game_rock_loop
set_game_rocks_done:
RTS
render:
LDX #$00
LDA #$F8
hide:
STA $0200,X
INX
BNE hide
LDA $06
BNE render_game
JMP render_title
render_game:
LDA $13
SEC
SBC #$01
STA $0200
LDX $03
LDA drawing,X
STA $0201
LDA $08
BEQ ship_normal_palette
LSR A
LSR A
AND #$03
JMP ship_palette_done
ship_normal_palette:
LDA #$00
ship_palette_done:
STA $0202
LDA $11
STA $0203
LDX #$00
LDY #$04
render_bullet:
LDA $0600,X
BEQ hide_bullet
LDA $0609,X
BEQ render_normal_bullet
STX $20
LDA $0600,X
SEC
SBC #$01
TAX
LDA explosion_drawing,X
LDX $20
JMP render_bullet_tile_ready
render_normal_bullet:
LDA #$11
render_bullet_tile_ready:
STA $0201,Y
LDA $0604,X
SEC
SBC #$01
STA $0200,Y
LDA #$00
STA $0202,Y
LDA $0602,X
STA $0203,Y
JMP advance_bullet_oam
hide_bullet:
LDA #$F8
STA $0200,Y
advance_bullet_oam:
INY
INY
INY
INY
render_next:
TXA
CLC
ADC #$10
TAX
CPX #$40
BNE render_bullet
JSR render_ufo
JSR render_asteroids
RTS
render_asteroids:
LDA #$28
STA $4C
LDA #$36
STA $4E
LDA #$30
STA $51
LDA $42
STA $4B
CLC
ADC #$05
CMP #$30
BCC rotation_ready
SEC
SBC #$30
rotation_ready:
STA $42
render_pool_loop:
LDX $4B
LDA render_record_low,X
STA $43
LDA render_record_high,X
STA $44
LDY #$08
LDA ($43),Y
BNE render_pool_active
JMP render_pool_next
render_pool_active:
CMP #$03
BEQ render_pool_small
LDA $4E
CMP #$04
BCS render_pool_big_fits
JMP render_pool_next
render_pool_big_fits:
LDA ($43),Y
CMP #$01
BEQ render_pool_large
LDA #$17
JMP render_pool_big
render_pool_large:
LDA #$13
render_pool_big:
STA $4D
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
STA $50
JSR render_pool_tile
INC $4D
LDA $4F
CLC
ADC #$08
STA $4F
JSR render_pool_tile
INC $4D
LDA $4F
SEC
SBC #$08
STA $4F
LDA $50
CLC
ADC #$08
CMP #$F0
BCC render_pool_bottom_ready
SEC
SBC #$F0
render_pool_bottom_ready:
STA $50
JSR render_pool_tile
INC $4D
LDA $4F
CLC
ADC #$08
STA $4F
JSR render_pool_tile
JMP render_pool_next
render_pool_small:
LDA $4E
BEQ render_pool_next
LDA #$12
STA $4D
LDY #$01
LDA ($43),Y
STA $4F
LDY #$03
LDA ($43),Y
STA $50
JSR render_pool_tile
render_pool_next:
INC $4B
LDA $4B
CMP #$30
BCC render_pool_no_wrap
LDA #$00
STA $4B
render_pool_no_wrap:
DEC $51
BEQ render_pool_done
JMP render_pool_loop
render_pool_done:
RTS
render_pool_tile:
LDY $4C
LDA $50
SEC
SBC #$01
STA $0200,Y
LDA $4D
STA $0201,Y
LDA #$01
STA $0202,Y
LDA $4F
STA $0203,Y
TYA
CLC
ADC #$04
STA $4C
DEC $4E
RTS
render_title:
LDX #$00
LDY #$00
render_title_asteroid:
LDA $0303,X
SEC
SBC #$01
STA $0200,Y
LDA #$12
STA $0201,Y
LDA #$01
STA $0202,Y
LDA $0301,X
STA $0203,Y
INY
INY
INY
INY
TXA
CLC
ADC #$10
TAX
CPX #$80
BNE render_title_asteroid
RTS

ufo_xlo:
.byte $00,$54,$A6,$F5,$40,$86,$C5,$FC,$2A,$4F,$6A,$7B,$80,$7B,$6A,$4F,$2A,$FC,$C5,$86,$40,$F5,$A6,$54,$00,$AC,$5A,$0B,$C0,$7A,$3B,$04,$D6,$B1,$96,$85,$80,$85,$96,$B1,$D6,$04,$3B,$7A,$C0,$0B,$5A,$AC
ufo_xhi:
.byte $00,$00,$00,$00,$01,$01,$01,$01,$02,$02,$02,$02,$02,$02,$02,$02,$02,$01,$01,$01,$01,$00,$00,$00,$00,$FF,$FF,$FF,$FE,$FE,$FE,$FE,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FE,$FE,$FE,$FE,$FF,$FF,$FF
ufo_ylo:
.byte $80,$85,$96,$B1,$D6,$04,$3B,$7A,$C0,$0B,$5A,$AC,$00,$54,$A6,$F5,$40,$86,$C5,$FC,$2A,$4F,$6A,$7B,$80,$7B,$6A,$4F,$2A,$FC,$C5,$86,$40,$F5,$A6,$54,$00,$AC,$5A,$0B,$C0,$7A,$3B,$04,$D6,$B1,$96,$85
ufo_yhi:
.byte $FD,$FD,$FD,$FD,$FD,$FE,$FE,$FE,$FE,$FF,$FF,$FF,$00,$00,$00,$00,$01,$01,$01,$01,$02,$02,$02,$02,$02,$02,$02,$02,$02,$01,$01,$01,$01,$00,$00,$00,$00,$FF,$FF,$FF,$FE,$FE,$FE,$FE,$FD,$FD,$FD,$FD
ufo_aim:
.byte $00,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$0C,$18,$12,$10,$0E,$0E,$0E,$0D,$0D,$0D,$0D,$0D,$0D,$0D,$0D,$0D,$0D,$18,$14,$12,$10,$10,$0F,$0E,$0E,$0E,$0E,$0E,$0D,$0D,$0D,$0D,$0D,$18,$16,$14,$12,$11,$10,$10,$0F,$0F,$0E,$0E,$0E,$0E,$0E,$0E,$0E,$18,$16,$14,$13,$12,$11,$10,$10,$10,$0F,$0F,$0F,$0E,$0E,$0E,$0E,$18,$16,$15,$14,$13,$12,$11,$11,$10,$10,$10,$0F,$0F,$0F,$0F,$0E,$18,$17,$16,$14,$14,$13,$12,$11,$11,$10,$10,$10,$10,$0F,$0F,$0F,$18,$17,$16,$15,$14,$13,$13,$12,$11,$11,$11,$10,$10,$10,$10,$0F,$18,$17,$16,$15,$14,$14,$13,$13,$12,$12,$11,$11,$10,$10,$10,$10,$18,$17,$16,$16,$15,$14,$14,$13,$12,$12,$12,$11,$11,$11,$10,$10,$18,$17,$16,$16,$15,$14,$14,$13,$13,$12,$12,$12,$11,$11,$11,$10,$18,$17,$17,$16,$15,$15,$14,$14,$13,$13,$12,$12,$12,$11,$11,$11,$18,$17,$17,$16,$16,$15,$14,$14,$14,$13,$13,$12,$12,$12,$11,$11,$18,$17,$17,$16,$16,$15,$15,$14,$14,$13,$13,$13,$12,$12,$12,$11,$18,$17,$17,$16,$16,$15,$15,$14,$14,$14,$13,$13,$13,$12,$12,$12,$18,$17,$17,$16,$16,$16,$15,$15,$14,$14,$14,$13,$13,$13,$12,$12
ufo_small_chance:
.byte $00,$18,$30,$48,$60,$78,$90,$A8,$C0
render_record_low:
.byte $00,$10,$20,$30,$40,$50,$60,$70,$80,$90,$A0,$B0,$C0,$D0,$E0,$F0,$00,$10,$20,$30,$40,$50,$60,$70,$80,$90,$A0,$B0,$C0,$D0,$E0,$F0,$00,$10,$20,$30,$40,$50,$60,$70,$80,$90,$A0,$B0,$C0,$D0,$E0,$F0
render_record_high:
.byte $03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$03,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$04,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05,$05
palette:
.byte $0F,$30,$0F,$0F,$0F,$16,$28,$08,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$30,$24,$16,$0F,$37,$27,$17,$0F,$30,$16,$2A,$0F,$30,$16,$2A
drawing:
.byte $01,$01,$02,$02,$02,$03,$03,$03,$04,$04,$04,$05,$05,$05,$06,$06,$06,$07,$07,$07,$08,$08,$08,$09,$09,$09,$0A,$0A,$0A,$0B,$0B,$0B,$0C,$0C,$0C,$0D,$0D,$0D,$0E,$0E,$0E,$0F,$0F,$0F,$10,$10,$10,$01
rainbow_offsets:
.byte $06,$02,$2E,$2A
small_child_low:
.byte $00,$00,$00,$00,$C0,$E0,$00,$20,$40,$60,$80,$A0,$00,$00,$00,$00
small_child_page:
.byte $00,$00,$00,$00,$03,$03,$04,$04,$04,$04,$04,$04,$00,$00,$00,$00
explosion_drawing:
.byte $1F,$1F,$1F,$1E,$1E,$1E,$1D,$1D,$1D,$1C,$1C,$1C,$1B,$1B,$1B
title_nt0:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$01,$02,$03,$04,$11,$12,$13,$14,$21,$22,$23,$24,$31,$32,$33,$34,$41,$42,$43,$44,$51,$52,$53,$54,$00,$00,$00,$00,$00,$00,$00,$00,$05,$06,$07,$08,$15,$16,$17,$18,$25,$26,$27,$28,$35,$36,$37,$38,$45,$46,$47,$48,$55,$56,$57,$58,$00,$00,$00,$00,$00,$00,$00,$00,$09,$0A,$0B,$0C,$19,$1A,$1B,$1C,$29,$2A,$2B,$2C,$39,$3A,$3B,$3C,$49,$4A,$4B,$4C,$59,$5A,$5B,$5C,$00,$00,$00,$00
title_nt1:
.byte $00,$00,$00,$00,$0D,$0E,$0F,$10,$1D,$1E,$1F,$20,$2D,$2E,$2F,$30,$3D,$3E,$3F,$40,$4D,$4E,$4F,$50,$5D,$5E,$5F,$60,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$70,$72,$65,$73,$73,$00,$73,$65,$6C,$65,$63,$74,$00,$74,$6F,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$63,$68,$6F,$6F,$73,$65,$00,$67,$61,$6D,$65,$00,$6D,$6F,$64,$65,$8A,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$61,$72,$63,$61,$64,$65,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
title_nt2:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$70,$72,$65,$73,$73,$00,$73,$74,$61,$72,$74,$00,$74,$6F,$00,$62,$65,$67,$69,$6E,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
title_nt3:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$89,$7D,$7B,$7D,$81,$00,$61,$6E,$74,$68,$6F,$6E,$79,$00,$76,$6F,$6C,$70,$65,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$55,$55,$55,$55,$55,$55,$00,$00,$05,$05,$05,$05,$05,$05,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
hud_line:
.byte $73,$63,$6F,$72,$65,$8A,$7B,$7B,$7B,$7B,$7B,$7B,$00,$00,$00,$73,$75,$70,$65,$72,$8A,$80,$00,$00,$00,$6C,$69,$76,$65,$73,$8A,$7E
asteroid_init0:
.byte $00,$0F,$00,$0E,$00,$00,$80,$FF,$01,$00,$00,$00,$00,$00,$00,$00,$00,$E1,$00,$18,$00,$00,$80,$FF,$01,$00,$00,$00,$00,$00,$00,$00,$00,$0A,$00,$69,$00,$00,$80,$FF,$01,$00,$00,$00,$00,$00,$00,$00,$00,$F0,$00,$7D,$31,$00,$8A,$FF,$01,$00,$00,$00,$00,$00,$00,$00,$00,$19,$00,$CD,$31,$00,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$DC,$00,$D2,$31,$00,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$4C,$00,$B8,$5B,$00,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$AF,$00,$AE,$5B,$00,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$5B,$00,$93,$5B,$00,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$A4,$00,$C2,$76,$00,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$ED,$00,$01,$76,$00,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$36,$00,$30,$76,$00,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7F,$00,$5F,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C8,$00,$8E,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$11,$00,$BD,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$5A,$00,$EC,$76,$00,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00
asteroid_init1:
.byte $00,$A3,$00,$2B,$76,$00,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$EC,$00,$5A,$76,$00,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$35,$00,$89,$5B,$00,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7E,$00,$B8,$5B,$00,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C7,$00,$E7,$5B,$00,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$10,$00,$26,$31,$00,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$59,$00,$55,$31,$00,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$A2,$00,$84,$31,$00,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$EB,$00,$B3,$00,$00,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$34,$00,$E2,$00,$00,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7D,$00,$21,$00,$00,$80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C6,$00,$50,$CF,$FF,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0F,$00,$7F,$CF,$FF,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$58,$00,$AE,$CF,$FF,$76,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$A1,$00,$DD,$A5,$FF,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$EA,$00,$1C,$A5,$FF,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$33,$00,$4B,$A5,$FF,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7C,$00,$7A,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C5,$00,$A9,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0E,$00,$D8,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$57,$00,$17,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$A0,$00,$46,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$E9,$00,$75,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$32,$00,$A4,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7B,$00,$D3,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C4,$00,$12,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0D,$00,$41,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$56,$00,$70,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$9F,$00,$9F,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$E8,$00,$CE,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$31,$00,$0D,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7A,$00,$3C,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00
asteroid_init2:
.byte $00,$33,$00,$4B,$A5,$FF,$5B,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7C,$00,$7A,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C5,$00,$A9,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0E,$00,$D8,$8A,$FF,$31,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$57,$00,$17,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$A0,$00,$46,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$E9,$00,$75,$80,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$32,$00,$A4,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7B,$00,$D3,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$C4,$00,$12,$8A,$FF,$CF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0D,$00,$41,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$56,$00,$70,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$9F,$00,$9F,$A5,$FF,$A5,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$E8,$00,$CE,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$31,$00,$0D,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$7A,$00,$3C,$CF,$FF,$8A,$FF,$00,$00,$00,$00,$00,$00,$00,$00
axlo:
.byte $00,$02,$03,$05,$06,$07,$08,$0A,$0A,$0B,$0C,$0C,$0C,$0C,$0C,$0B,$0A,$0A,$08,$07,$06,$05,$03,$02,$00,$FE,$FD,$FB,$FA,$F9,$F8,$F6,$F6,$F5,$F4,$F4,$F4,$F4,$F4,$F5,$F6,$F6,$F8,$F9,$FA,$FB,$FD,$FE
axhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
aylo:
.byte $F4,$F4,$F4,$F5,$F6,$F6,$F8,$F9,$FA,$FB,$FD,$FE,$00,$02,$03,$05,$06,$07,$08,$0A,$0A,$0B,$0C,$0C,$0C,$0C,$0C,$0B,$0A,$0A,$08,$07,$06,$05,$03,$02,$00,$FE,$FD,$FB,$FA,$F9,$F8,$F6,$F6,$F5,$F4,$F4
ayhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
bxlo:
.byte $00,$64,$C7,$26,$80,$D4,$1F,$61,$99,$C6,$E6,$F9,$00,$F9,$E6,$C6,$99,$61,$1F,$D4,$80,$26,$C7,$64,$00,$9C,$39,$DA,$80,$2C,$E1,$9F,$67,$3A,$1A,$07,$00,$07,$1A,$3A,$67,$9F,$E1,$2C,$80,$DA,$39,$9C
bxhi:
.byte $00,$00,$00,$01,$01,$01,$02,$02,$02,$02,$02,$02,$03,$02,$02,$02,$02,$02,$02,$01,$01,$01,$00,$00,$00,$FF,$FF,$FE,$FE,$FE,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FD,$FE,$FE,$FE,$FF,$FF
bylo:
.byte $00,$07,$1A,$3A,$67,$9F,$E1,$2C,$80,$DA,$39,$9C,$00,$64,$C7,$26,$80,$D4,$1F,$61,$99,$C6,$E6,$F9,$00,$F9,$E6,$C6,$99,$61,$1F,$D4,$80,$26,$C7,$64,$00,$9C,$39,$DA,$80,$2C,$E1,$9F,$67,$3A,$1A,$07
byhi:
.byte $FD,$FD,$FD,$FD,$FD,$FD,$FD,$FE,$FE,$FE,$FF,$FF,$00,$00,$00,$01,$01,$01,$02,$02,$02,$02,$02,$02,$03,$02,$02,$02,$02,$02,$02,$01,$01,$01,$00,$00,$00,$FF,$FF,$FE,$FE,$FE,$FD,$FD,$FD,$FD,$FD,$FD
lxlo:
.byte $00,$11,$21,$31,$40,$4E,$5B,$66,$6F,$76,$7C,$7F,$80,$7F,$7C,$76,$6F,$66,$5B,$4E,$40,$31,$21,$11,$00,$EF,$DF,$CF,$C0,$B2,$A5,$9A,$91,$8A,$84,$81,$80,$81,$84,$8A,$91,$9A,$A5,$B2,$C0,$CF,$DF,$EF
lxhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
lylo:
.byte $80,$81,$84,$8A,$91,$9A,$A5,$B2,$C0,$CF,$DF,$EF,$00,$11,$21,$31,$40,$4E,$5B,$66,$6F,$76,$7C,$7F,$80,$7F,$7C,$76,$6F,$66,$5B,$4E,$40,$31,$21,$11,$00,$EF,$DF,$CF,$C0,$B2,$A5,$9A,$91,$8A,$84,$81
lyhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
mxlo:
.byte $00,$15,$29,$3D,$50,$61,$71,$7F,$8B,$94,$9B,$9F,$A0,$9F,$9B,$94,$8B,$7F,$71,$61,$50,$3D,$29,$15,$00,$EB,$D7,$C3,$B0,$9F,$8F,$81,$75,$6C,$65,$61,$60,$61,$65,$6C,$75,$81,$8F,$9F,$B0,$C3,$D7,$EB
mxhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
mylo:
.byte $60,$61,$65,$6C,$75,$81,$8F,$9F,$B0,$C3,$D7,$EB,$00,$15,$29,$3D,$50,$61,$71,$7F,$8B,$94,$9B,$9F,$A0,$9F,$9B,$94,$8B,$7F,$71,$61,$50,$3D,$29,$15,$00,$EB,$D7,$C3,$B0,$9F,$8F,$81,$75,$6C,$65,$61
myhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
sxlo:
.byte $00,$19,$32,$49,$60,$75,$88,$98,$A6,$B1,$B9,$BE,$C0,$BE,$B9,$B1,$A6,$98,$88,$75,$60,$49,$32,$19,$00,$E7,$CE,$B7,$A0,$8B,$78,$68,$5A,$4F,$47,$42,$40,$42,$47,$4F,$5A,$68,$78,$8B,$A0,$B7,$CE,$E7
sxhi:
.byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
sylo:
.byte $40,$42,$47,$4F,$5A,$68,$78,$8B,$A0,$B7,$CE,$E7,$00,$19,$32,$49,$60,$75,$88,$98,$A6,$B1,$B9,$BE,$C0,$BE,$B9,$B1,$A6,$98,$88,$75,$60,$49,$32,$19,$00,$E7,$CE,$B7,$A0,$8B,$78,$68,$5A,$4F,$47,$42
syhi:
.byte $FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF
spawnxoff:
.byte $00,$01,$02,$03,$04,$05,$06,$06,$07,$07,$08,$08,$08,$08,$08,$07,$07,$06,$06,$05,$04,$03,$02,$01,$00,$FF,$FE,$FD,$FC,$FB,$FA,$FA,$F9,$F9,$F8,$F8,$F8,$F8,$F8,$F9,$F9,$FA,$FA,$FB,$FC,$FD,$FE,$FF
spawnyoff:
.byte $F8,$F8,$F8,$F9,$F9,$FA,$FA,$FB,$FC,$FD,$FE,$FF,$00,$01,$02,$03,$04,$05,$06,$06,$07,$07,$08,$08,$08,$08,$08,$07,$07,$06,$06,$05,$04,$03,$02,$01,$00,$FF,$FE,$FD,$FC,$FB,$FA,$FA,$F9,$F9,$F8,$F8