; $067D: death-burst updates remaining; $067A/E: Game Over 300-update timer;
; $067C: GAME OVER text enabled. Four 8-byte fragments begin at $06E0.
death_burst_start22:
LDA #$19
STA $067D
LDX #$00
death_burst_make22:
LDA $10
STA $06E0,X
LDA $11
STA $06E1,X
LDA $12
STA $06E2,X
LDA $13
STA $06E3,X
JSR random
AND #$2F
TAY
LDA bxlo,Y
STA $06E4,X
LDA bxhi,Y
STA $06E5,X
LDA bylo,Y
STA $06E6,X
LDA byhi,Y
STA $06E7,X
TXA
CLC
ADC #$08
TAX
CPX #$20
BNE death_burst_make22
RTS
death_explosion_tick22:
LDA $067D
BEQ death_explosion_done22
LDX #$00
death_explosion_move22:
CLC
LDA $06E0,X
ADC $06E4,X
STA $06E0,X
LDA $06E1,X
ADC $06E5,X
STA $06E1,X
CLC
LDA $06E2,X
ADC $06E6,X
STA $06E2,X
LDA $06E3,X
ADC $06E7,X
STA $06E3,X
TXA
CLC
ADC #$08
TAX
CPX #$20
BNE death_explosion_move22
DEC $067D
death_explosion_done22:
RTS
render_death_burst22:
LDA #$19
SEC
SBC $067D
TAX
LDA death_explosion_tile22,X
STA $7A
LDX #$00
LDY #$00
render_death_piece22:
LDA $06E3,X
SEC
SBC #$01
STA $0200,Y
LDA $7A
STA $0201,Y
LDA #$00
STA $0202,Y
LDA $06E1,X
STA $0203,Y
TXA
CLC
ADC #$08
TAX
TYA
CLC
ADC #$04
TAY
CPY #$10
BNE render_death_piece22
RTS
gameover_tick22:
LDA $067A
ORA $067E
BEQ gameover_hold22
LDA $067A
BNE gameover_low22
DEC $067E
LDA #$FF
STA $067A
JMP gameover_return22
gameover_low22:
DEC $067A
LDA $067A
ORA $067E
BNE gameover_return22
gameover_hold22:
LDA #$03
STA $0677
gameover_return22:
RTS
