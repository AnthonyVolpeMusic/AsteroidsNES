"""Medium-progress tempo and destruction-path checks."""
from pathlib import Path
P=Path(__file__).parent
base=(P/'test_v24.py').read_text().split("for count,interval")[0]
base=base.replace('symbols_v24.json','symbols_v24a.json').replace('asteroids_nes_v24_triangle_pulse.nes','asteroids_nes_v24a_medium_progress.nes')
exec(compile(base,str(P/'test_v24.py'),'exec'))
def pulse(total,destroyed):
    clear();m[0x7f]=total;m[0x7e]=destroyed;m[0x67f]=0;writes.clear()
    call('asteroid_pulse24')
    return m[0x67f],writes[:]
for total in (8,24):
    for destroyed in range(total+1):
        want=48 if destroyed*4<total else 36 if destroyed*2<total else 25 if destroyed*4<total*3 else 16 if destroyed<total else 9
        got,w=pulse(total,destroyed)
        assert got==want,(total,destroyed,want,got)
        assert any(pair in w for pair in ((0x400a,0x56),(0x400a,0x26))),(total,destroyed,w)
print('PASS exact progress tiers for 4-large and 12-large waves, including every boundary')

# New wave totals are precisely twice the root count, and reset the progress.
for roots in range(4,13):
    clear();m[0x3f]=roots;m[0x7e]=99;call('set_game_rocks')
    assert m[0x7f]==roots*2 and m[0x7e]==0,(roots,m[0x7f],m[0x7e])
print('PASS medium total/reset at every legal wave size')

# Player and enemy regular-medium destruction both call the shared splitter.
def active():return {a:m[a+8] for a in records if m[a+8]}
clear();m[0x7e]=0;m[0x308]=2;m[0x301]=60;m[0x303]=70;m[0x600:0x610]=[47,0,64,0,74,0,0,0,0,0,12,0,0,0,0,0]
call('collisions');assert m[0x7e]==1 and list(active().values())==[3,3]
clear();m[0x7e]=0;m[0x308]=2;m[0x301]=60;m[0x303]=70;m[0x640:0x644]=[1,60,70,0]
call('enemy_rocks21');assert m[0x7e]==1 and list(active().values())==[3,3]
print('PASS player and UFO medium kills both advance progress exactly once')

# A live frame with four large rocks now begins in tier one, not the final tier.
clear();m[6]=1;m[0x3f]=4;call('set_game_rocks');m[0x67f]=0;writes.clear();call('asteroid_pulse24')
assert m[0x67f]==48 and any(pair in writes for pair in ((0x400a,0x56),(0x400a,0x26)))
print('PASS four-large opening starts at 48 updates')
