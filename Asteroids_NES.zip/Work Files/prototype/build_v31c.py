"""V31c: Bouncy boundary adjustment and active-object debug counter."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v30.py').read_text(),str(P/'build_v30.py'),'exec'))
marker='asm=Assembler(MPU()); labels={};pc=0x8000'
assert source.count(marker)==1
source=source.replace(marker,"exec(compile((P/'patch_v31.py').read_text(),str(P/'patch_v31.py'),'exec'))\nexec(compile((P/'patch_v31c.py').read_text(),str(P/'patch_v31c.py'),'exec'))\n"+marker)
for old,new in [('asteroids_nes_v30_silent_flip.nes','asteroids_nes_v31c_bouncy_debug.nes'),('symbols_v30.json','symbols_v31c.json'),('prototype_v30.asm','prototype_v31c.asm')]:
    assert source.count(old)==1
    source=source.replace(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
