"""Runs after V34 relocation patches. $A4-$A6: next life increment (24-bit).
Stars use palette zero's previously black color slots; text remains white.
No per-frame star work, RAM nametable or additional OAM entries.
"""
code='\n'.join(lines)
initial='LDA #$20\nSTA $3A\nLDA #$4E\nSTA $3B'
assert code.count(initial)==2
code=code.replace(initial,'JSR life_init35')
patch31('JSR score_decimal_add\nLDA $32','JSR score_decimal_add\nscore_threshold35:\nLDA $32')
patch31('''CLC
LDA $3A
ADC #$20
STA $3A
LDA $3B
ADC #$4E
STA $3B
LDA $3C
ADC #$00
STA $3C''','''JSR life_advance35
JMP score_threshold35''')
# Every death triggers retreat; repeated calls cannot reinitialize a death.
patch31('JSR death_burst_start22','LDA #$01\nSTA $0679\nJSR death_burst_start22')
# Keep rightward exit behavior, but advance with fractional, size-specific speed.
patch31('''LDA $0681,X
CLC
ADC #$02
STA $0681,X
BCC murder_depart_next21''','''TAY
LDA $0680,X
CLC
ADC depart_lo35,Y
STA $0680,X
LDA $0681,X
ADC depart_hi35,Y
STA $0681,X
BCC murder_depart_next21''')
data['depart_lo35']=[0,96,180,32]
data['depart_hi35']=[0,0,0,1]

# A repeatable sparse layout: 90 isolated pinpricks, clear HUD/counter rows.
# Separate PRNG at build time never perturbs gameplay's random number stream.
import random
stars35=[0]*1024
star_rng35=random.Random(3501979)
for n,pos in enumerate(star_rng35.sample(list(range(3*32,27*32)),90)):
    stars35[pos]=0x90+n%10
for n in range(4):data['stars35_'+str(n)]=stars35[n*256:(n+1)*256]
data['palette'][2:4]=[0x01,0x04]
patch31('''LDY #$04
LDX #$00
blank_title_loop:
LDA #$00
STA $2007
INX
BNE blank_title_loop
DEY
BNE blank_title_loop''','JSR load_stars35')
patch31('''LDY #$04
LDX #$00
LDA #$00
results_blank23:
STA $2007
INX
BNE results_blank23
DEY
BNE results_blank23''','JSR load_stars35')
code+='''
life_init35:
LDA #$10
STA $3A
STA $A4
LDA #$27
STA $3B
STA $A5
LDA #$00
STA $3C
STA $A6
RTS
life_advance35:
CLC
LDA $A4
ADC #$10
STA $A4
LDA $A5
ADC #$27
STA $A5
LDA $A6
ADC #$00
STA $A6
CLC
LDA $3A
ADC $A4
STA $3A
LDA $3B
ADC $A5
STA $3B
LDA $3C
ADC $A6
STA $3C
RTS
load_stars35:
'''
for n in range(4):
    code+=f'''LDX #$00
stars_page35_{n}:
LDA stars35_{n},X
STA $2007
INX
BNE stars_page35_{n}
'''
code+='RTS\n'
lines=[s.strip() for s in code.splitlines() if s.strip()]
