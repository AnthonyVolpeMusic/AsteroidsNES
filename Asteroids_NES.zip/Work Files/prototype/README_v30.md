# V30: silent 180-degree flip

Based on V29. Removes only the sound request from the flip action. The unused
sound table entry remains to avoid renumbering other effects. No other gameplay,
palette or audio behavior changed. This is a playtest candidate, not a claim
of final release status.

Build: `python3 prototype/build_v30.py` (Python 3, Pillow, py65).
Test: `python3 prototype/test_v30.py`.

Assembled-ROM tests pass: all 48 headings flip correctly; idle and busy Pulse 2
state/registers remain untouched; holding Down does not flip repeatedly. V29
brake sequence, priority, independent-channel, activation and reset tests pass.
User emulator playtesting remains pending. Historical tests apply to their
original versions; use test_v30.py for this candidate.
