# Asteroids V17 — UFOs

Builds on playtest-confirmed V16. The ship stays invincible. Asteroid splitting, scoring, OAM rotation and four-second wave transitions remain in place.

## Gameplay

- One UFO at a time, entering from either side, departing at the opposite side.
- Big UFO: 12x12, speed 0.5 horizontal pixels/update, random shots, 200 points.
- Small UFO: 8x8, speed 1 horizontal pixel/update, aimed shots using the existing 48-heading convention, 1000 points.
- Both choose upward, downward or level travel each second. Vertical speed is 0.5 pixels/update, limited to the play area below the HUD.
- First cooldown is 600 updates (about 10 seconds). Each appearance subtracts 24 updates from the next cooldown, with a floor of 120 (about 2 seconds). Cooldown resumes after departure, or after the 15-update destruction animation. At a new wave the current cooldown restarts, retaining the reduced interval.
- Wave 1 has only big UFOs. Small UFO chance increases by 24/256 per subsequent wave, capped at 192/256 (75%) from wave 9 onward.
- Firing attempts every 90 updates (about 1.5 seconds); an attempt is skipped if the one enemy projectile is still active. Projectiles live 96 updates, travel at 2.5 pixels/update, and wrap. They currently do not damage the invincible ship or asteroids.
- UFOs block wave completion. No new UFO spawns during the transition or on an asteroid-free field. Enemy projectiles are cleared with the other projectiles at the next-wave reset.
- Player projectiles consumed by an asteroid cannot also hit a UFO. UFO destruction consumes only the first successful player projectile and awards one score event. Both the projectile hit effect and UFO effect use the existing five-frame explosion artwork.

## Graphics and memory

Exact approved drawings are encoded in `build_v17.py`, with black transparent, white index 1, purple index 2 and red index 3. Shared sprite palette 0 is now $0F/$30/$24/$16. UFO tiles $20–$23, small UFO $24, enemy shot $25 in the sprite pattern table. UFO slots 5–8 and enemy shot slot 9 use V16's reservation. Asteroids/pickups retain the 54-slot pool.

RAM $0640–$064B contains UFO type, position, course, timers and cooldown. $0650–$0659 contains the enemy projectile and its heading. $41 remains the active-enemy count. ZP $52–$55 is main-loop scratch. Score, life threshold and asteroid records remain separate. UFO shot physics and collision routines run on the main thread; NMI does not use their scratch.

## Build / validation

    python3 -m pip install py65 pillow
    python3 prototype/build_v17.py
    python3 prototype/test_v17.py
    python3 prototype/test_full_wave.py 17 100 12

Builder uses preserved V16 and V15 builder sources included in this archive. Tests execute assembled 6502 instructions: prior wave-transition checks, cooldown and shot timing, both exits, all aim quadrants, single-hit scoring under four overlapping player shots, reserved OAM stress, exact small-UFO/shot CHR decoding and 1800 integrated gameplay updates. Full-wave scoring remains 6300 for twelve roots, excluding additional UFO points.

These CPU tests are not full PPU/hardware certification. Play-test using a fresh ROM boot, not an older save state. Observe the first big UFO after roughly ten seconds of uncleared-wave play; small UFOs become possible from wave 2. No sound effects have been added.
