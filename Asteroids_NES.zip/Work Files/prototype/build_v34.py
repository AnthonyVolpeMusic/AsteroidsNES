"""V34 adaptive 60/30 presentation with fixed-size simulation substeps."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v33.py').read_text(),str(P/'build_v33.py'),'exec'))
marker='asm=Assembler(MPU()); labels={};pc=0x8000'
assert source.count(marker)==1
source=source.replace(marker,"exec(compile((P/'patch_v34.py').read_text(),str(P/'patch_v34.py'),'exec'))\n"+marker)
for old,new in [('asteroids_nes_v33_evil.nes','asteroids_nes_v34_adaptive_fps.nes'),('symbols_v33.json','symbols_v34.json'),('prototype_v33.asm','prototype_v34.asm')]:
    assert source.count(old)==1
    source=source.replace(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
