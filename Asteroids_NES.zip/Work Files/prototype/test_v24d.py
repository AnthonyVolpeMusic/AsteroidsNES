"""Execute cached-tempo and collision-path tests on the assembled ROM."""
from pathlib import Path
P=Path(__file__).parent
base=(P/'test_v24.py').read_text().split('for count,interval')[0]
base=base.replace('symbols_v24.json','symbols_v24d.json').replace('asteroids_nes_v24_triangle_pulse.nes','asteroids_nes_v24d_cached_tempo.nes')
exec(compile(base,str(P/'test_v24.py'),'exec'))
def resetall():
    m[:0x800]=[0]*0x800
    m[6]=1;m[0x3d]=3;m[0x3f]=4;m[0x11]=128;m[0x13]=120;m[0x2f]=165
def expected(n,t):
    return 48 if 4*n<t else 36 if 2*n<t else 25 if 4*n<3*t else 16 if n<t else 9
for roots in range(4,13):
    resetall();m[0x3f]=roots;call('set_game_rocks')
    assert m[0x81]==48 and m[0x7f]==roots*2 and m[0x7e]==0
    for destroyed in range(roots*2+1):
        m[0x7e]=destroyed;m[0x67f]=7
        call('pulse_recalculate24d')
        assert m[0x81]==expected(destroyed,roots*2) and m[0x67f]==7
        writes.clear()
        for _ in range(7):call('asteroid_pulse24')
        assert not writes and m[0x67f]==0
        call('asteroid_pulse24');assert m[0x67f]==m[0x81]
print('PASS all progress boundaries for waves 4–12; reset; countdown finishes before new interval')
for enemy in (False,True):
    resetall();m[0x7f]=8;m[0x7e]=1;m[0x81]=48
    m[0x308]=2;m[0x301]=60;m[0x303]=70
    if enemy:
        m[0x640:0x644]=[1,60,70,0];call('enemy_rocks21')
    else:
        m[0x600:0x610]=[47,0,64,0,74,0,0,0,0,0,12,0,0,0,0,0];call('collisions')
    assert m[0x7e]==2 and m[0x81]==36 and kinds()==[3,3]
print('PASS player and UFO medium kills update cache and still produce two children')
resetall();call('set_game_rocks');call('pulse_gate24c');assert m[0x4015]&4
call('player_kill21');call('pulse_gate24c');assert not m[0x4015]&4
for _ in range(120):call('death_tick21')
call('pulse_gate24c');assert m[0x677]==0 and m[0x4015]&4
clear();call('wave_tick');call('pulse_gate24c');assert not m[0x4015]&4
call('next_wave');call('pulse_gate24c');assert m[0x4015]&4 and m[0x81]==48
print('PASS death, respawn, clear and next-wave audio gates')
for countdown in (10,0):
    m[0x67f]=countdown;t=c.processorCycles;call('pulse_gate24c')
    print('Audio service cycles', 'countdown' if countdown else 'note',c.processorCycles-t)
