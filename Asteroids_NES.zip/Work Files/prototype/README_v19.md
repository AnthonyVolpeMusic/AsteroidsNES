# V19 — Murderoids

Branches from Anthony's confirmed V18b pickup-system baseline. Player One remains invincible.

## Behavior

- One large Murderoid spawns once per wave, from level 4 onward, when three or fewer regular asteroids remain. The <=3 check handles several regular kills in the same refresh without missing the trigger. UFOs do not affect this trigger.
- It spawns half a screen away from the ship on both wrapping axes, then pursues the ship. All Murderoids wrap at the screen boundaries.
- Each updates its aim every four refreshes and turns at most one of the 48 heading steps (7.5 degrees) per update. This permits arcing pursuit instead of instant direction changes.
- One large splits into three medium; each medium splits into two small; small Murderoids disappear when hit. Children initially travel in different directions before steering toward Player One. New bodies receive three movement updates of collision grace.
- Large awards 100, medium 200, small 400. Total family score: 100 + 3*200 + 6*400 = 3,100.
- Speeds follow the approved comparison to corresponding regular sizes: large 0.5 pixels/frame, medium 0.9375, small 1.5. These equal 1x regular large, 1.5x regular medium, and 2x regular small. The current baseline's reserved level-speed multiplier remains unused; V19 does not add a new speed progression.
- Murderoids never drop pickups or increment either regular-small destruction statistics or pickup parity/order. Their remaining presence blocks wave completion.
- Ship, player projectiles, UFO and enemy shots retain their protected OAM positions. Murderoids share rotation with regular asteroids and pickups.

## Artwork

Exact supplied 8x8 small, 12x12 medium and 8x16 left-half large artwork. The right half is the horizontal mirror, producing a 16x16 large body. Medium artwork is padded at right/bottom to 16x16 so its visible 12x12 region matches its collision bounds. Sprite palette 2 uses blue $12 and green $2A. Nine tiles occupy sprite $38-$40.

## Memory and allocation

Six independent 16-byte records: $0680-$06DF. Record offsets: 0/1 X fractional/integer; 2/3 Y; 4-7 signed velocity; 8 type (0 inactive, 1 large, 2 medium, 3 small); 9 heading; A grace; B steering countdown. $0673 marks the family already spawned during this wave. New scratch $60-$68; aiming reuses existing $52-$55 between other routines.

The large root occupies slot 0. Medium children occupy slots 0, 2, 4. Their small pairs occupy 0/1, 2/3, 4/5 respectively. Thus six slots accommodate every split order without dynamic allocation or touching any of the 48 regular asteroid records or 16 pickup records. The display traversal expands from 64 to 70 records and advances nine positions per refresh, visiting all records. Large/medium bodies are only submitted when four sprite slots remain.

## Build and validation

Keep `prototype` and `upload` directories together. Requires Python 3, Pillow and py65.

```sh
python -m pip install pillow py65
python prototype/build_v19.py
python prototype/test_v19.py
python prototype/test_full_wave.py 19 100 4
python prototype/test_full_wave.py 19 100 12
```

The layered builder runs preserved ancestor builders in this working copy, then produces the V19 ROM, complete assembly and symbol map. The confirmed baseline deliverables are separate.

Automated assembled-6502 validation passed: 100 family destruction orders with all ten births/deaths and exactly 3,100 points; no pickup effects or adjacent-record writes; multi-projectile overlaps and split grace; regular/hunter collision-dispatch isolation; level and once-per-wave trigger gates; all 48 headings and speed magnitudes; wrap-aware aiming and gradual turn direction; wave blocking; 70-record render rotation with whole four-tile bodies; encoded artwork and mirroring; existing ship/pickup regressions; and 900 integrated main-loop/NMI updates with the hunter family, UFO and pickups. Regular-wave accounting also passed 100 four-root waves (2,100 points) and 100 twelve-root waves (6,300 points), excluding bonus items and Murderoids.

These CPU tests do not emulate the PPU scanline sprite limit or replace a visual OpenEmu playtest. Start fresh rather than loading an older build's save state. Check the first spawn on level 4, pursuit feel, child spread, complete split chain and rendering under load.
