"""Execute assembled ROM collision code; account for every birth/death and score.

Usage: python3 test_full_wave.py 14 [seed_count] [root_count]
Positions/shots are controlled inputs; types, allocation and scoring are ROM-owned.
"""
import json, random, sys
from pathlib import Path
from collections import Counter
from py65.devices.mpu6502 import MPU
P=Path(__file__).parent
VERSION=sys.argv[1] if len(sys.argv)>1 else '13d'
S=json.loads((P/f'symbols_v{VERSION}.json').read_text())
rom=next(P.glob(f'asteroids_nes_v{VERSION}_*.nes')).read_bytes()
records=list(range(0x300,0x600,16))
ROOTS=int(sys.argv[3]) if len(sys.argv)>3 else 4
def run(seed, verbose=False, roots=ROOTS):
 m=[0]*65536; m[0x8000:]=rom[16:32784]
 c=MPU(memory=m)
 def call(name):
  c.pc=S[name];c.sp=0xff;c.stPushWord(0x7ffe)
  start=c.processorCycles
  for _ in range(100000):
   c.step()
   if c.pc==0x7fff:return c.processorCycles-start
  raise AssertionError('routine timeout')
 def active():return {a:m[a+8] for a in records if m[a+8]}
 def score():return sum(m[0x30+i]<<(8*i) for i in range(3))
 rng=random.Random(seed);m[0x2f]=seed%255+1;m[0x3a]=0x20;m[0x3b]=0x4e;m[0x3d]=3
 m[0x3f]=roots
 call('set_game_rocks')
 if VERSION in ('13d','14'):
  m[0x30a]=3
  for b in range(0x600,0x640,16):
   m[b]=47;m[b+2]=m[0x301];m[b+4]=m[0x303]
  call('collisions')
  assert m[0x308]==1 and m[0x30a]==3, 'four checks must not consume grace'
  for b in range(0x600,0x640,16):m[b]=0
  call('asteroids')
  assert m[0x30a]==2, 'grace ticks even without a projectile'
  for a in records:m[a:a+16]=[0]*16
  m[0x3f]=roots
  for a in range(0x30,0x3a):m[a]=0
  call('set_game_rocks')
 born=Counter({1:roots});dead=Counter(); peak=0;trace=[]
 while active():
  before=active()
  targets=list(before)
  if seed==0:targets.sort(key=lambda a:(before[a],a))
  else:rng.shuffle(targets)
  # One programmed hit per dispatcher call makes a record's parent-to-child
  # replacement observable even when the replacement has the same type.
  targets=targets[:1]
  for a in before:
   m[a+1]=220;m[a+3]=200;m[a+10]=0
  for b in range(0x600,0x640,16):m[b:b+16]=[0]*16
  for i,a in enumerate(targets):
   x=32+i*48;y=80;m[a+1]=x;m[a+3]=y
   b=0x600+i*16;m[b]=47;m[b+2]=x+4;m[b+4]=y+4;m[b+10]=rng.randrange(48)
  oldscore=score();peak=max(peak,call('collisions'));after=active()
  expected=sum({1:25,2:50,3:100}[before[a]] for a in targets)
  removed={a:k for a,k in before.items() if after.get(a)!=k}
  added={a:k for a,k in after.items() if before.get(a)!=k}
  trace.append({'targets':[(hex(a),before[a]) for a in targets],
                'removed':[(hex(a),k) for a,k in removed.items()],
                'born':[(hex(a),k) for a,k in added.items()], 'score':score()})
  if set(removed)!=set(targets) or score()-oldscore!=expected:
   print(json.dumps(trace[-3:],indent=2))
   raise AssertionError(f'v{VERSION} seed {seed}: unaccounted removal/overwrite; score={score()}')
  expected_born=Counter()
  for a in targets:
   kind=before[a];dead[kind]+=1
   if kind<3:expected_born[kind+1]+=2
  assert Counter(added.values())==expected_born,(trace[-1],expected_born)
  born.update(added.values())
  assert score()+sum({1:525,2:250,3:100}[k] for k in after.values())==525*roots
 expected_counts=Counter({1:roots,2:2*roots,3:4*roots})
 assert born==dead==expected_counts,(born,dead)
 assert score()==525*roots and m[0x39]==4*roots
 if verbose: print(json.dumps(trace,indent=2))
 if seed==0 and VERSION=='13d':
  (P/'v13d_full_wave_trace.json').write_text(json.dumps(trace,indent=2)+'\n')
 return peak
if __name__=='__main__':
 n=int(sys.argv[2]) if len(sys.argv)>2 else 100
 peak=max(run(seed, '--trace' in sys.argv) for seed in range(n))
 print(f'PASS v{VERSION}: {n} full waves of {ROOTS} roots; births=deaths={ROOTS} large/{2*ROOTS} medium/{4*ROOTS} small; {525*ROOTS} points each. Peak collision cycles {peak}.')
