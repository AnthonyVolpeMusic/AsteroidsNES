# V31 — Arcade and Bouncy Mode

V31 branches from frozen, confirmed V30 Arcade. V30's ROM checksum remains
`ca00f3379b238ad79ebfcd4378a31e2175a7fb4176d1d68bc053d39eb98d5f88`.

On the title screen, SELECT toggles `ARCADE MODE` and `BOUNCY MODE`; START
launches the displayed choice. Arcade is unchanged from V30. Bouncy makes these
objects reflect at playfield edges instead of wrapping:

- Player One (horizontal bounds 0–248; vertical bounds 16–232, below the HUD)
- Player and UFO shots (4px)
- Large, medium and small regular asteroids (16/12/8px)
- Pickups (8px), including magnet-attracted pickups
- Active Murderoids (16/12/8px)
- Player-death debris (8px)

At each impact, the relevant velocity component reverses. Objects with a stored
48-way heading also have that component reflected so later splits and movement
remain coherent. UFO bodies retain their normal crossing/exit behavior, as do
departing Murderoids; UFO projectiles bounce. Bouncy is a separate selected
mode and does not alter the frozen V30 files.

New zero-page bytes: $8E mode, $8F–$99 bounce working state, $9A title redraw
flag, $9B saved index, $9C heading offset. Bouncy adds per-active-object edge
checks, so high-level performance playtesting is especially important.

Build: `python3 prototype/build_v31.py` (Python 3, Pillow, py65).
Test: `python3 prototype/test_v31.py`.

Assembled-ROM tests pass for title selection and Start, Arcade wrapping,
right/top/HUD bounce limits, all three regular asteroid sizes, player/UFO shots,
pickups, active Murderoids, debris, heading reflection, and UFO-body exit.
V30 brake and silent-flip regressions also pass on the V31 ROM. Tests model CPU
and memory behavior; OpenEMU/RetroArch playtesting is still required.
