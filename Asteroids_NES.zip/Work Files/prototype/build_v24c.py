"""Reduce music overhead, sharing the existing wave scan. $80 = wave has rocks."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v24b.py').read_text(),str(P/'build_v24b.py'),'exec'))
def change(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)
change('JSR asteroid_pulse_gate24b\n','')
change('main_render21:\nJSR render','main_render21:\nJSR pulse_gate24c\nJSR render')
a=source.index('asteroid_pulse_gate24b:\n'); b=source.index('asteroid_pulse24:\n',a)
source=source[:a]+'''pulse_gate24c:
LDA $06
BEQ pulse_mute24c
LDA $0677
BNE pulse_mute24c
LDA $80
BEQ pulse_mute24c
JMP asteroid_pulse24
pulse_mute24c:
JMP asteroid_pulse_off24
'''+source[b:]
change('asteroid_pulse24:\nLDA $7F','''asteroid_pulse24:
LDA $067F
BEQ pulse_due24c
DEC $067F
RTS
pulse_due24c:
LDA $7F''')
change('''STA $7D
LDA $067F
BEQ pulse_fire24
DEC $067F
RTS
pulse_fire24:
LDA $7D''','''pulse_fire24:''')
change('wave_tick:\nJSR murder_count','wave_tick:\nLDA #$01\nSTA $80\nJSR murder_count')
change('LDA $41\nBNE wave_cancel\nLDX #$00\nwave_scan:','LDX #$00\nwave_scan:')
change('BNE wave_scan\nLDA $40','BNE wave_scan\nLDA #$00\nSTA $80\nLDA $41\nBNE wave_cancel\nLDA $40')
change('set_game_rocks:\nLDA $3F','set_game_rocks:\nLDA #$01\nSTA $80\nLDA #$00\nSTA $067F\nLDA $3F')
# One central audio service, including same-frame death/clear, after gameplay.
source=source.replace('JSR asteroids\nJSR asteroid_pulse_off24\n','JSR asteroids\n')
change('LDA #$04\nSTA $4015\nRTS','LDA $4015\nAND #$0F\nORA #$04\nSTA $4015\nRTS')
change('AND #$FB\nSTA $4015','AND #$0B\nSTA $4015')
for old,new in [('asteroids_nes_v24b_pulse_gated.nes','asteroids_nes_v24c_audio_optimized.nes'),('symbols_v24b.json','symbols_v24c.json'),('prototype_v24b.asm','prototype_v24c.asm')]:change(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
