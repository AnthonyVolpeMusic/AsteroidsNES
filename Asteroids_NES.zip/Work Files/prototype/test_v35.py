"""Execute V35 machine code, then rerun adaptive FPS / gameplay regressions."""
from pathlib import Path
import json
from py65.devices.mpu6502 import MPU
P=Path(__file__).parent
S=json.loads((P/'symbols_v35.json').read_text())
ROM=(P/'asteroids_nes_v35_starfield.nes').read_bytes()
class Memory(list):
    def __init__(self):
        super().__init__([0]*65536)
        self.writes=[]
    def __getitem__(self,k):
        if k==0x2002:return 0x80
        return super().__getitem__(k)
    def __setitem__(self,k,v):
        if k==0x2007:self.writes.append(v)
        super().__setitem__(k,v)
def fresh():
    m=Memory();m[0x8000:]=ROM[16:32784];c=MPU(memory=m)
    return m,c
def call(m,c,name):
    c.pc=S[name];c.sp=255;c.stPushWord(0x7FFE)
    for _ in range(200000):
        c.step()
        if c.pc==0x7FFF:return
    raise AssertionError(name+' timeout')
def number(m,a):return sum(m[a+i]<<(8*i) for i in range(3))
def put(m,a,n):m[a:a+3]=list(n.to_bytes(3,'little'))
m,c=fresh();call(m,c,'life_init35');m[0x3D]=3
for n in range(1,15):
    target=10000*n*(n+1)//2
    assert number(m,0x3A)==target
    put(m,0x30,target-1);c.a=0;call(m,c,'score_add')
    assert m[0x3D]==n+2
    c.a=1;call(m,c,'score_add');assert m[0x3D]==n+3
    assert number(m,0x3A)==10000*(n+1)*(n+2)//2
    c.a=0;call(m,c,'score_add');assert m[0x3D]==n+3
call(m,c,'life_init35');m[0x3D]=3;put(m,0x30,100000)
c.a=0;call(m,c,'score_add');assert m[0x3D]==7 and number(m,0x3A)==150000
print('PASS progressive life thresholds, exact equality, catch-up and no duplicate awards')

for mode in range(4):
    for killer in ('regular','murder','ufo','shot'):
        m,c=fresh();m[6]=1;m[0x8E]=mode;m[0x11]=100;m[0x13]=100;m[0x3D]=3
        for i in range(6):
            a=0x680+16*i;m[a+1]=20+i*30;m[a+3]=180;m[a+8]=1+i%3
        if killer=='regular':m[0x301]=100;m[0x303]=100;m[0x308]=3
        if killer=='murder':m[0x681]=100;m[0x683]=100
        if killer=='ufo':m[0x640]=1;m[0x641]=100;m[0x642]=100
        if killer=='shot':m[0x650]=60;m[0x652]=100;m[0x654]=100
        call(m,c,'player_hits21')
        assert m[0x677]==1 and m[0x679]==1 and m[0x3D]==2,(mode,killer)
        m[0x678]=0;call(m,c,'death_tick21');assert m[0x677]==1
        # Clear UFO to isolate Murderoid gate. Their Y remains constant.
        m[0x640]=0
        ticks=0
        while any(m[a+8] for a in range(0x680,0x6E0,16)):
            call(m,c,'murder_depart_or_tick21');ticks+=1
            assert ticks<700
        call(m,c,'death_tick21')
        assert m[0x677]==0 and m[8]==180 and m[7]==5
        assert m[0x11]==128 and m[0x13]==120
print('PASS every death cause triggers retreat in all modes; respawn waits until clear')
for kind,speed in ((1,96),(2,180),(3,288)):
    m,c=fresh();m[0x679]=1;m[0x688]=kind;m[0x681]=100
    for _ in range(60):call(m,c,'murder_depart_or_tick21')
    assert m[0x680]+256*m[0x681]==256*100+60*speed
print('PASS exact fractional retreat speeds: 0.375 / 0.703125 / 1.125 pixels per tick')

m,c=fresh();call(m,c,'load_stars35');nt=m.writes
assert len(nt)==1024 and sum(0x90<=v<=0x99 for v in nt)==90
assert not any(nt[:96]) and not any(nt[27*32:])
assert set(nt)-{0}==set(range(0x90,0x9A))
for tile in range(0x90,0x9A):
    data=ROM[32784+tile*16:32784+tile*16+16]
    assert sum((data[y]|data[y+8]).bit_count() for y in range(8))==1
print('PASS ten one-pixel star tiles, 90 stars, clear HUD/counter, zero attributes')

# Initial boot and replay both reset progressive thresholds. Replay installs
# the same field (not the result screen's blank background).
m,c=fresh();c.pc=S['reset']
for _ in range(200000):
    c.step()
    if c.pc==S['main']:break
else:raise AssertionError('boot timeout')
assert number(m,0x3A)==10000 and number(m,0xA4)==10000
put(m,0xA4,90000);put(m,0x3A,450000);m.writes=[]
c.pc=S['results_replay23'];c.sp=255
for _ in range(200000):
    c.step()
    if c.pc==S['results_on23']:break
else:raise AssertionError('replay timeout')
assert number(m,0x3A)==10000 and number(m,0xA4)==10000
assert m.writes[:1024]==nt
print('PASS boot/replay reset life progression; replay retains starfield')

# Established adaptive suite includes periodic NMIs, cycle budget checks,
# collision accounting, all modes, counter and sound/control regression.
suite=(P/'test_v34.py').read_text().replace('symbols_v34.json','symbols_v35.json').replace('asteroids_nes_v34_adaptive_fps.nes','asteroids_nes_v35_starfield.nes')
suite=suite.replace("load('v34',", "load('v35',")
exec(compile(suite,str(P/'test_v34.py'),'exec'),{'__file__':str(P/'test_v34.py')})
