from pathlib import Path
P=Path(__file__).parent
regression=(P/'test_v15.py').read_text().replace('symbols_v15.json','symbols_v17.json').replace('asteroids_nes_v15_wave_transition.nes','asteroids_nes_v17_ufos.nes')
exec(compile(regression,str(P/'test_v15.py'),'exec'))

def setup():
    clear()
    m[6]=1
    m[0x40]=0
    m[0x3f]=4
    m[0x2f]=165
    m[0x600:0x660]=[0]*96
    call('ufo_init')
    m[0x308]=1
def ticks(n):
    for _ in range(n): call('ufo_tick')
setup()
ticks(599)
assert m[0x640]==0 and m[0x648:0x64a]==[1,0]
ticks(1)
assert m[0x640]==1 and m[0x41]==1
assert m[0x64a]|m[0x64b]<<8==576
ticks(89)
assert m[0x650]==0
ticks(1)
assert m[0x650]==96
heading=m[0x659]
ticks(90)
assert m[0x650]==6 and m[0x659]==heading, 'live shot replaced'
ticks(6)
assert m[0x650]==0
print('PASS initial 600-frame spawn, 90-frame firing, single shot, expiry')
# Both exits release wave gating and restart cooldown.
for direction,x in [(0,244),(1,0)]:
    setup()
    m[0x640]=2;m[0x41]=1;m[0x643]=direction;m[0x641]=x
    m[0x645]=60;m[0x646]=90
    ticks(1)
    assert m[0x640]==m[0x41]==0 and m[0x648:0x64a]==m[0x64a:0x64c]
print('PASS both horizontal exits')
# No spawning on an empty field or during wave transition.
setup();clear();m[0x648]=m[0x649]=0
ticks(700)
assert m[0x640]==0
m[0x308]=1;m[0x40]=100
ticks(700)
assert m[0x640]==0
setup();m[0x640]=1;m[0x41]=1;clear()
call('wave_tick');assert m[0x40]==0
print('PASS empty-field and transition suppression, active-enemy wave gate')
# Repeated spawns reduce delay to 120, never below. First wave is always big.
setup()
for i in range(100):
    call('ufo_spawn')
    assert m[0x640]==1
    assert m[0x64a]|m[0x64b]<<8==max(120,600-24*(i+1))
    call('ufo_exit')
m[0x3f]=12
sizes=set()
for i in range(100):
    call('ufo_spawn');sizes.add(m[0x640]);call('ufo_exit')
assert sizes=={1,2}
print('PASS cooldown floor and both late-wave UFO sizes')
# Aimed shots: cardinal headings and all quadrants, using ship center offsets
# which cancel the centered 4x4 shot's two-pixel padding.
setup();m[0x640]=2;m[0x641]=98;m[0x642]=98
for x,y,expected in [(100,40,0),(160,100,12),(100,160,24),(40,100,36),(160,40,6),(160,160,18),(40,160,30),(40,40,42)]:
    m[0x11]=x;m[0x13]=y
    call('ufo_fire');assert m[0x659]==expected,(x,y,m[0x659])
print('PASS aimed shot directions')
# Four overlapping player shots must destroy exactly one UFO and score once.
for kind,points in [(1,200),(2,1000)]:
    setup();clear()
    m[0x640]=kind;m[0x41]=1;m[0x641]=m[0x642]=100
    m[0x30:0x3a]=[0]*10
    m[0x3a:0x3e]=[0x20,0x4e,0,3]
    for b in range(0x600,0x640,16):
        m[b:b+16]=[47,0,104,0,104,0,0,0,0,0,12,0,0,0,0,0]
    call('ufo_collisions')
    assert m[0x640]==m[0x41]==0 and m[0x647]==15
    assert sum(m[0x30+i]<<(8*i) for i in range(3))==points
    assert sum(m[b+9] for b in range(0x600,0x640,16))==1
    call('ufo_collisions')
    assert sum(m[0x30+i]<<(8*i) for i in range(3))==points
    call('render')
    assert m[0x215]==0x1b
    ticks(15);assert m[0x647]==0
print('PASS single-consumption scoring and 15-frame UFO explosion')
# Crowded rendering retains protected UFO, shot and player entries; records safe.
for kind,tiles in [(1,[0x20,0x21,0x22,0x23]),(2,[0x24])]:
    setup()
    for i,a in enumerate(records):
        m[a+8]=2;m[a+1]=i*4;m[a+3]=100
    m[0x640]=kind;m[0x41]=1;m[0x641]=100;m[0x642]=100
    call('ufo_fire')
    snapshot=m[0x300:0x800]
    for _ in range(48):
        call('render')
        assert m[0x300:0x800]==snapshot
        assert [m[0x215+i*4] for i in range(len(tiles))]==tiles
        assert m[0x225]==0x25 and m[0x226]==0
print('PASS UFO/shot protected OAM in 48-medium stress scene')
# Decode actual CHR to verify supplied native artwork and palette slot.
rom=(P/'asteroids_nes_v17_ufos.nes').read_bytes()
def tile(n):
    b=rom[32784+n*16:32784+(n+1)*16]
    return [''.join(str(((b[y]>>(7-x))&1)|(((b[y+8]>>(7-x))&1)<<1)) for x in range(8)) for y in range(8)]
assert tile(0x124)==['00111100','00133100','00111100','02222220','22222222','33333333','03333330','00333300']
assert tile(0x125)==['00000000','00000000','00233200','00322300','00322300','00233200','00000000','00000000']
assert m[S['palette']+16:S['palette']+20]==[15,48,36,22]
print('PASS native artwork decoding and shared palette')
# Exercise NMI/main with live UFO spawning, movement, enemy shots, firing and
# asteroid collisions together. Stop before the wave can drain unexpectedly.
setup()
m[0x3f]=12
call('set_game_rocks')
c.pc=S['main'];m[0]=1
seen=set();enemy_shots=0
for i in range(1800):
    frame(0x81 if i%120<60 else 0x82)
    seen.add(m[0x640])
    enemy_shots+=bool(m[0x650])
    assert m[0x640] in (0,1,2)
    assert m[0x41]==bool(m[0x640])
    assert m[0x654]<240 and m[0x13]<240
    assert m[0x3d]>=3, 'invincible player lost a life'
assert (1 in seen or 2 in seen) and enemy_shots>0
print('PASS 1800 integrated gameplay frames with live UFOs, enemy shots and P1 firing')
