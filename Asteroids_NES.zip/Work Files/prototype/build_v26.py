"""V26: prioritized Pulse 2 event sequences and UFO death noise."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v25b.py').read_text(),str(P/'build_v25b.py'),'exec'))
def change26(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new,1)

# $87 effect, $88 next table index, $89 frames left, $8A last high timer,
# $8B request scratch. No NMI use; start preserves A/X/Y and processor flags.
change26('JSR sfx_tick25\n','JSR sfx_tick25\nJSR pulse2_tick26\n')
change26('STA $86\nSTA $4015\nSTA $4001\nRTS',
         'STA $86\nSTA $87\nSTA $88\nSTA $89\nSTA $8A\nSTA $8B\nSTA $4015\nSTA $4001\nSTA $4005\nRTS')
change26('STX $4001\n','STX $4001\nSTX $4005\n')
change26('ufo_spawn_done:\nRTS','ufo_spawn_done:\nLDA $0640\nCLC\nADC #$02\nJSR pulse2_start26\nRTS')
for label in ('ufo_fire','ufo_fire2'):
    change26(label+':\n',label+':\nLDA #$01\nJSR pulse2_start26\n')
change26('murder_spawn_return:\nRTS','LDA #$05\nJSR pulse2_start26\nmurder_spawn_return:\nRTS')
change26('pickup_collect_award:\n','pickup_collect_award:\nLDA #$02\nJSR pulse2_start26\n')
change26('score_extra_life:\nINC $3D','score_extra_life:\nLDA #$06\nJSR pulse2_start26\nINC $3D')
change26('LDA $0640\nSTA $53','LDA $0640\nJSR ufo_noise26\nLDA $0640\nSTA $53')
change26('ufo_collisions:\nLDA $06\nBEQ ufo_collision_done\nLDA $0640\nBEQ ufo_collision_done',
         'ufo_collisions:\nLDA $06\nBNE ufo_collision_game26\nRTS\nufo_collision_game26:\nLDA $0640\nBNE ufo_collision_live26\nRTS\nufo_collision_live26:')
# A body hitting a rock produces both events; the subsequent asteroid sound
# wins on the shared noise channel, matching the existing latest-event rule.
change26('LDX $067B\nLDA #$00\nSTA $0640,X','LDX $067B\nCPX #$00\nBNE enemy_no_ufo_sound26\nLDA $0640\nJSR ufo_noise26\nenemy_no_ufo_sound26:\nLDA #$00\nSTA $0640,X')
routine='''ufo_noise26:
CMP #$01
BEQ ufo_noise_large26
LDA #$0C
JMP sfx_noise_start25
ufo_noise_large26:
LDA #$0D
JMP sfx_noise_start25
pulse2_start26:
STA $8B
PHP
PHA
TXA
PHA
TYA
PHA
LDX $8B
LDY $87
LDA pulse2_priority26,X
CMP pulse2_priority26,Y
BCC pulse2_rejected26
STX $87
LDA pulse2_length26,X
STA $89
LDA pulse2_offset26,X
STA $88
LDA #$FF
STA $8A
LDA #$08
STA $4005
LDA $86
ORA #$02
STA $86
STA $4015
JSR pulse2_output26
pulse2_rejected26:
PLA
TAY
PLA
TAX
PLA
PLP
RTS
pulse2_tick26:
LDA $89
BEQ pulse2_done26
DEC $89
BNE pulse2_output26
LDA #$00
STA $87
LDA #$B0
STA $4004
LDA $86
AND #$FD
STA $86
STA $4015
pulse2_done26:
RTS
pulse2_output26:
LDX $88
LDA pulse2_volume26,X
ORA #$B0
STA $4004
LDA pulse2_low26,X
STA $4006
LDA pulse2_high26,X
CMP $8A
BEQ pulse2_same_high26
STA $8A
STA $4007
pulse2_same_high26:
INC $88
RTS
'''
change26('shield_tick:\n',routine+'shield_tick:\n')
# Equal-tempered pitch glides, computed once at build time (NTSC clock).
def timer(midi):return round(1789773/(16*440*2**((midi-69)/12))-1)
def glide(a,b,n):return [timer(a+(b-a)*i/(n-1)) for i in range(n)]
seqs=[[], [timer(57)]*4+[timer(45)]*4,
      glide(63,75,12),
      (glide(60,76,6)+glide(76,60,6))*4,
      (glide(69,84,6)+glide(84,69,6))*4,
      ([timer(67)]*5+[timer(74)]*5)*6,
      ([timer(91)]*5+[timer(91)]*5)*5]
seqs[1]*=3
offsets=[];flat=[];vol=[]
for i,seq in enumerate(seqs):
    offsets.append(len(flat));flat.extend(seq)
    vol.extend([0 if i==6 and j%10>=5 else 15 for j in range(len(seq))])
assert len(flat)==242 and max(flat)<=2047
tables={'pulse2_priority26':[0,1,2,3,3,4,5],
        'pulse2_length26':list(map(len,seqs)), 'pulse2_offset26':offsets,
        'pulse2_low26':[x&255 for x in flat], 'pulse2_high26':[x>>8 for x in flat],
        'pulse2_volume26':vol}
change26("data.update({'shot_timer25'",'data.update('+repr(tables)+")\ndata.update({'shot_timer25'")
for old,new in [('asteroids_nes_v25b_wave_audio.nes','asteroids_nes_v26_event_sfx.nes'),('symbols_v25b.json','symbols_v26.json'),('prototype_v25b.asm','prototype_v26.asm')]:change26(old,new)
exec(compile(source,str(P/'build_v15.py'),'exec'))
