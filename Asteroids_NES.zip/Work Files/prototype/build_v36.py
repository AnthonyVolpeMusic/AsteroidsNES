"""V36: hidden scheduler counter and practical dual-direction brake."""
from pathlib import Path
P=Path(__file__).parent
exec(compile((P/'build_v35.py').read_text(),str(P/'build_v35.py'),'exec'))
marker='asm=Assembler(MPU()); labels={};pc=0x8000'
assert source.count(marker)==1
source=source.replace(marker,"exec(compile((P/'patch_v36.py').read_text(),str(P/'patch_v36.py'),'exec'))\n"+marker)
source=source.replace("output=P/'asteroids_nes_v35_starfield.nes'", "output=P/'asteroids_nes_v36_controls_cleanup.nes'")
source=source.replace('symbols_v35.json','symbols_v36.json').replace('prototype_v35.asm','prototype_v36.asm')
exec(compile(source,str(P/'build_v15.py'),'exec'))
