"""Assembled-6502 tests for V18 pickup timing, collisions and rendering."""
from pathlib import Path
import math
P=Path(__file__).parent
regression=(P/'test_v15.py').read_text().replace('symbols_v15.json','symbols_v18.json').replace('asteroids_nes_v15_wave_transition.nes','asteroids_nes_v18_pickups.nes')
exec(compile(regression,str(P/'test_v15.py'),'exec'))
pickups=list(range(0x700,0x800,16))
def reset():
    clear()
    m[6]=1
    m[0x600:0x700]=[0]*256
    m[0x30:0x3a]=[0]*10
    m[0x3a:0x3e]=[0x20,0x4e,0,3]
    m[0x11]=128;m[0x13]=120;m[0x2f]=165;m[0x40]=0
    call('pickups_init')
def pset(a,kind,x,y,life=420):
    m[a:a+16]=[0,x,0,y,0,0,0,0,kind,life&255,life>>8,10,0,0,0,0]
def score():return sum(m[0x30+i]<<(8*i) for i in range(3))
def active():return {a:m[a+8] for a in pickups if m[a+8]}
def signed(a):
    n=m[a]|m[a+1]<<8
    return n-65536 if n&32768 else n

reset()
expected=[1,2,1,3,1,2,1,4,5]*2
for kill in range(36):
    clear()
    addr=0x300+(kill%48)*16
    kind=1+kill%3
    m[addr:addr+16]=[0,60,0,70,0,0,0,0,kind,12,0,0,0,0,0,0]
    m[0x600:0x640]=[0]*64
    m[0x600:0x610]=[47,0,64,0,74,0,0,0,0,0,12,0,0,0,0,0]
    old=score()
    call('collisions')
    assert score()-old=={1:25,2:50,3:100}[kind]
    assert m[0x609]==1
    if kill%2==0:
        assert not active()
    else:
        assert active()=={0x700:expected[kill//2]},(kill,active())
        assert m[0x701]==60 and m[0x703]==70
        assert abs(math.hypot(signed(0x704),signed(0x706))-38.4)<1
        m[0x708]=0
assert m[0x671]==0
print('PASS every-second kill across all sizes/pages; exact nine-drop order and drift')

reset();pset(0x700,1,60,60)
for age in range(420):
    assert m[0x709]+256*m[0x70a]==420-age
    assert m[0x70c]==(age//10)%2
    call('render')
    visible=any(m[a]==59 and m[a+1] in (0x26,0x27) for a in range(0x22c,0x300,4))
    if age<300: assert visible,(age,'early blink')
    else: assert visible == (((420-age) & 8) == 0)
    call('pickups_tick')
assert not active()
# Explicit blink states at equal animation phase, no collision dependence.
for life,visible in [(121,True),(120,False),(112,True),(104,False),(96,True),(1,True)]:
    pset(0x700,1,60,60,life)
    call('render')
    shown=any(m[a]==59 and m[a+1]==0x26 for a in range(0x22c,0x300,4))
    assert shown==visible,(life,shown)
print('PASS 420-update lifetime, 10-update animation, final-120-update blinking')

# 24x24 ship zone against 8x8 pickup: top-left delta -15..15 overlaps;
# +/-16 only touches at an edge. Both axes wrap.
for sx,sy in [(100,100),(0,0),(255,239)]:
    for dx,dy,want in [(0,0,True),(-15,0,True),(15,15,True),(-16,0,False),(16,0,False),(0,-15,True),(0,15,True),(0,16,False),(0,-16,False)]:
        reset();m[0x11]=sx;m[0x13]=sy
        pset(0x700,1,(sx+dx)%256,(sy+dy)%240)
        call('pickups_collect')
        assert (score()==250)==want,(sx,sy,dx,dy,score())
        assert bool(m[0x708])!=want
        call('pickups_collect');assert score()==(250 if want else 0)
print('PASS pickup-only collection box, wrap edges and exactly-once collection')

reset()
for i,kind in enumerate([1,2,3,4]): pset(0x700+i*16,kind,128,120)
call('pickups_collect');assert score()==2500 and not active()
for i in range(4):
    pset(0x700,5,128,120);call('pickups_collect')
    assert m[0x672]==min(i+1,2)
assert score()==2500
# Test both regular and rainbow launch paths with inherited ship velocity.
for level in (0,1,2):
    m[0x672]=level
    for h in range(48):
        m[3]=h;m[5]=0;m[1]=0x80
        m[0x14:0x18]=[64,0,128,255]
        m[0x600:0x640]=[0]*64
        call('shoot')
        for axis,off,ship in [('x',0x605,64),('y',0x607,-128)]:
            base=m[S['b'+axis+'lo']+h]|m[S['b'+axis+'hi']+h]<<8
            add=m[S['boost_'+axis+'lo']+h]|m[S['boost_'+axis+'hi']+h]<<8
            actual=m[off]|m[off+1]<<8
            assert actual==(base+level*add+ship)&65535
    m[0x600:0x640]=[0]*64;m[7]=5;m[3]=0
    call('special_rainbow')
    for b in range(0x600,0x640,16):
        h=m[b+10]
        base=m[S['bxlo']+h]|m[S['bxhi']+h]<<8
        add=m[S['boost_xlo']+h]|m[S['boost_xhi']+h]<<8
        assert (m[b+5]|m[b+6]<<8)==(base+add*level+64)&65535
print('PASS pickup points, capped +25/+50 percent speed, all headings and rainbow')

reset()
for i,a in enumerate(pickups):pset(a,1,180+i*4,100,400-i)
for i,a in enumerate(records):m[a+8]=2;m[a+1]=i*3;m[a+3]=100
stable=m[0x300:0x800];seen=set();m[0x42]=0
for _ in range(64):
    call('render')
    assert m[0x300:0x800]==stable
    ptr=0x22c
    while ptr<0x300 and m[ptr]!=248:
        tile=m[ptr+1]
        if tile==0x26:
            seen.add(m[ptr+3]);assert m[ptr+2]==1;ptr+=4
        else:
            assert tile==0x17 and ptr+16<=0x300
            assert [m[ptr+j*4+1] for j in range(4)]==[0x17,0x18,0x19,0x1a]
            ptr+=16
assert seen=={180+i*4 for i in range(16)}
# On overflow replace smallest remaining lifetime; never touch a rock.
m[0x670]=1;m[0x45]=0;m[0x46]=3
rock_snapshot=m[0x300:0x600]
call('pickup_drop')
assert m[0x7f9]==164 and m[0x7fa]==1 and m[0x300:0x600]==rock_snapshot
print('PASS shared 64-record rotation, protected memory and oldest-pickup replacement')

reset();pset(0x700,1,60,60);m[0x670]=9;m[0x671]=7;m[0x672]=2;m[0x3f]=4
call('wave_tick');assert m[0x40]==240, 'pickups must not block wave completion'
call('next_wave')
assert m[0x670]==m[0x671]==0 and m[0x672]==2 and m[0x708]==1
assert m[0x3f]==5
print('PASS wave counter resets, surviving pickups/upgrades, no enemy gate pollution')

# Real main-loop/NMI integration with pickups, UFOs and four P1 shots.
reset();m[0x3f]=12;call('set_game_rocks');call('ufo_init')
m[0x648]=1;m[0x649]=0
c.pc=S['main'];m[0]=1
for i in range(900):
    frame(0x89 if i%120<60 else 0x82)
    assert 0<=m[0x671]<9 and m[0x672]<=2
    assert all(m[a+8] in range(6) and m[a+3]<240 for a in pickups)
    assert m[0x3d]>=3
print('PASS 900 integrated NMI/main updates; ship remains invincible')
