"""V24b pulse gating tests."""
from pathlib import Path

P = Path(__file__).parent
base = (P / 'test_v24a.py').read_text().replace(
    "symbols_v24a.json", "symbols_v24b.json"
).replace(
    "asteroids_nes_v24a_medium_progress.nes", "asteroids_nes_v24b_pulse_gated.nes"
)
exec(compile(base, str(P / 'test_v24a.py'), 'exec'))

def reset_records():
    for addr in records:
        m[addr:addr + 16] = [0] * 16
    for offset in range(0, 0x60, 0x10):
        m[0x680 + offset:0x690 + offset] = [0] * 16

# A regular asteroid restarts the live pulse.
clear(); reset_records(); m[0x7f] = 8; m[0x67f] = 0; m[0x308] = 1; writes.clear()
call('asteroid_pulse_gate24b')
assert m[0x67f] == 48 and (0x4015, 4) in writes

# A lone Murderoid also keeps the pulse alive, regardless of regular progress.
clear(); reset_records(); m[0x7f] = 8; m[0x67f] = 0; m[0x688] = 1; writes.clear()
call('asteroid_pulse_gate24b')
assert m[0x67f] == 48 and (0x4015, 4) in writes

# An empty playfield clears the countdown and disables only triangle.
clear(); reset_records(); m[0x7f] = 8; m[0x67f] = 19; m[0x4015] = 0x0F; writes.clear()
call('asteroid_pulse_gate24b')
assert m[0x67f] == 0 and m[0x4015] == 0x0B and writes[-1] == (0x4015, 0x0B)
print('PASS pulse runs for regular asteroids/Murderoids and mutes cleanly on wave clear')
