; $7E = regular medium asteroids destroyed; $7F = 2 × starting large asteroids.
; Threshold math uses integer cross multiplication: destroyed/total × 100.
asteroid_pulse24:
LDA $7F
BEQ asteroid_pulse_off24
LDA $7E
CMP $7F
BCS pulse_complete24
ASL A
ASL A
STA $7D
LDA $7F
ASL A
CLC
ADC $7F
STA $7B
LDA $7D
CMP $7B
BCS pulse_75_24
LDA $7E
ASL A
CMP $7F
BCS pulse_50_24
LDA $7E
ASL A
ASL A
CMP $7F
BCS pulse_25_24
LDA #$30
JMP pulse_interval24
pulse_25_24:
LDA #$24
JMP pulse_interval24
pulse_50_24:
LDA #$19
JMP pulse_interval24
pulse_75_24:
LDA #$10
JMP pulse_interval24
pulse_complete24:
LDA #$09
pulse_interval24:
STA $7D
LDA $067F
BEQ pulse_fire24
DEC $067F
RTS
pulse_fire24:
LDA $7D
STA $067F
LDA $7C
EOR #$01
STA $7C
TAX
LDA #$18
STA $4008
LDA pulse_timer24,X
STA $400A
LDA pulse_high24,X
STA $400B
LDA #$04
STA $4015
RTS
