"""ROM execution tests; register semantics, not synthesized/listened audio."""
from pathlib import Path
P=Path(__file__).parent
old=(P/'test_v25b.py').read_text().replace('v25b','v26').replace('wave_audio','event_sfx')
exec(compile(old,str(P/'test_v25b.py'),'exec'))
def fresh26():
    load('v26','asteroids_nes_v26_event_sfx.nes')
    m[0x3a]=0x20;m[0x3b]=0x4e
def timer(n):return round(1789773/(16*440*2**((n-69)/12))-1)
def sample():return (m[0x4006]+256*(m[0x4007]&7),m[0x4004]&15)
lengths={1:24,2:12,3:48,4:48,5:60,6:50}
for effect,duration in lengths.items():
    fresh26()
    call('sfx_shot_start25');call('sfx_noise_start25',14);call('asteroid_pulse24')
    c.x=37;c.y=91
    call('pulse2_start26',effect)
    assert (c.a,c.x,c.y)==(effect,37,91)
    assert m.enabled==15 and all(m.length)
    samples=[sample()]
    for _ in range(duration-1):
        call('pulse2_tick26');samples.append(sample())
        assert m[0x87]==effect and m.enabled==15
    call('pulse2_tick26')
    assert not m[0x87] and not m[0x89] and m.enabled==13
    assert all(m.length[i] for i in (0,2,3)) and not m.ignored
    if effect==1:assert samples==([(timer(57),15)]*4+[(timer(45),15)]*4)*3
    if effect==2:
        assert samples[0]==(timer(63),15) and samples[-1]==(timer(75),15)
        assert all(a[0]>b[0] for a,b in zip(samples,samples[1:]))
    if effect in (3,4):
        lo,hi=(60,76) if effect==3 else (69,84)
        for i in range(0,48,12):
            assert samples[i]==samples[i+11]==(timer(lo),15)
            assert samples[i+5]==samples[i+6]==(timer(hi),15)
    if effect==5:assert samples==([(timer(67),15)]*5+[(timer(74),15)]*5)*6
    if effect==6:assert samples==([(timer(91),15)]*5+[(timer(91),0)]*5)*5
print('PASS all six Pulse 2 sequences: exact durations, notes, glide endpoints, repeats and silence')
priorities=[0,1,2,3,3,4,5]
for active in lengths:
    for requested in lengths:
        fresh26();call('pulse2_start26',active);call('pulse2_tick26')
        before=m[0x87:0x8b]
        call('pulse2_start26',requested)
        if priorities[requested]>=priorities[active]:
            assert m[0x87]==requested and m[0x89]==lengths[requested]
        else:assert m[0x87:0x8b]==before
print('PASS all 36 interruption/rejection/restart combinations')
for kind,period in ((1,13),(2,12)):
    fresh26();m[0x640]=kind;m[0x641]=m[0x642]=100
    m[0x600:0x610]=[47,0,104,0,104,0,0,0,0,0,12,0,0,0,0,0]
    call('ufo_collisions')
    assert m[0x640]==0 and m[0x85]==period and m[0x84]==30 and m.length[3]
    for _ in range(30):call('sfx_tick25')
    assert not m.length[3] and m[0x400c]&15==0
for label in ('ufo_fire','ufo_fire2'):
    fresh26();m[0x640]=1;call(label);assert m[0x87]==1
for kind in (1,2):
    fresh26();m[0x640]=kind;call('ufo_spawn_done');assert m[0x87]==kind+2
fresh26();m[0x3f]=6;m[0x308]=1
call('murder_spawn_check');assert m[0x87]==5 and m[0x688]==1
fresh26();m[0x708]=1;m[0x70d]=1;m[0x701]=100;m[0x703]=100
m[0x11]=m[0x13]=104
call('pickups_collect');assert m[0x87]==2 and m[0x708]==0
fresh26();m[0x3d]=3;call('score_extra_life');assert m[0x3d]==4 and m[0x87]==6
call('audio_reset25a');assert not any(m[0x82:0x8c]) and m.enabled==0
print('PASS UFO death collision/fades, both fire slots, both arrival sizes, Murderoid spawn, collection, life and reset hooks')
# CPU cost of sequencer only, including subroutine return; no full-frame claim.
fresh26();call('pulse2_start26',3)
cost=[]
for _ in range(48):
    before=c.processorCycles;call('pulse2_tick26');cost.append(c.processorCycles-before)
print('Pulse 2 active tick cycles:',min(cost),'to',max(cost))
