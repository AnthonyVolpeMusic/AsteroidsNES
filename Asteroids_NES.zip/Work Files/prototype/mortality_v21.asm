; Persistent state: 677 alive=0/dead=1/gameover=2, 678 delay, 679 evacuation.
; Scratch 70/71/72 source X/Y/width; 73/74/75 target; 77 scan count.
; 67B enemy source index 0=UFO, 10=shot1, 20=shot2.
overlap21:
LDA $70
SEC
SBC $73
CMP $75
BCC overlap_y21
STA $76
LDA #$00
SEC
SBC $72
CMP $76
BCS overlap_no21
overlap_y21:
LDA $71
SEC
SBC $74
BCS overlap_y_delta21
CLC
ADC #$F0
overlap_y_delta21:
CMP $75
BCC overlap_yes21
STA $76
LDA #$F0
SEC
SBC $72
CMP $76
BCS overlap_no21
overlap_yes21:
SEC
RTS
overlap_no21:
CLC
RTS
scan_regular21:
LDA #$00
STA $43
LDA #$03
STA $44
LDA #$30
STA $77
JMP scan_hazard21
scan_murder21:
LDA #$80
STA $43
LDA #$06
STA $44
LDA #$06
STA $77
scan_hazard21:
LDY #$08
LDA ($43),Y
BEQ scan_next21
TAX
; Cheap conservative X rejection before fetching the full target rectangle.
LDY #$01
LDA ($43),Y
SEC
SBC $70
CLC
ADC #$0F
CMP #$1F
BCS scan_next21
LDA hazard_width21,X
STA $75
LDY #$0A
LDA ($43),Y
BNE scan_next21
LDY #$01
LDA ($43),Y
STA $73
LDY #$03
LDA ($43),Y
STA $74
JSR overlap21
BCS scan_found21
scan_next21:
LDA $43
CLC
ADC #$10
STA $43
BCC scan_pointer21
INC $44
scan_pointer21:
DEC $77
BNE scan_hazard21
CLC
scan_found21:
RTS
player_hits21:
LDA $0677
ORA $08
BEQ player_check21
RTS
player_check21:
LDA $11
STA $70
LDA $13
STA $71
LDA #$08
STA $72
JSR scan_regular21
BCS player_kill21
JSR scan_murder21
BCC player_ufo21
LDA #$01
STA $0679
JMP player_kill21
player_ufo21:
LDA $0640
BEQ player_shots21
CMP #$01
BEQ player_big_ufo21
LDA #$08
BNE player_ufo_width21
player_big_ufo21:
LDA #$0C
player_ufo_width21:
STA $75
LDA $0641
STA $73
LDA $0642
STA $74
JSR overlap21
BCS player_kill21
player_shots21:
LDX #$00
player_shot_loop21:
LDA $0650,X
BEQ player_shot_next21
LDA $0652,X
STA $73
LDA $0654,X
STA $74
LDA #$04
STA $75
JSR overlap21
BCC player_shot_next21
LDA #$00
STA $0650,X
JMP player_kill21
player_shot_next21:
TXA
CLC
ADC #$10
TAX
CPX #$20
BNE player_shot_loop21
RTS
player_kill21:
LDA $0677
BNE player_kill_done21
JSR death_burst_start22
LDA #$01
STA $0677
LDA #$78
STA $0678
LDA #$00
STA $08
STA $40
LDX #$3F
death_clear_shots21:
STA $0600,X
DEX
BPL death_clear_shots21
LDA $3D
BEQ death_gameover21
DEC $3D
BNE player_kill_done21
death_gameover21:
LDA #$02
STA $0677
LDA #$2C
STA $067A
LDA #$01
STA $067E
STA $067C
player_kill_done21:
RTS
death_tick21:
LDA $0677
CMP #$01
BNE death_return21
LDA $0678
BEQ death_check_depart21
DEC $0678
BNE death_return21
death_check_depart21:
LDA $0679
BEQ death_respawn21
JSR murder_count
BNE death_return21
death_respawn21:
LDA #$00
STA $0677
STA $0679
STA $03
STA $04
STA $05
LDX #$07
death_clear_velocity21:
STA $10,X
DEX
BPL death_clear_velocity21
LDX #$3F
death_clear_shots_again21:
STA $0600,X
DEX
BPL death_clear_shots_again21
LDA #$80
STA $11
LDA #$78
STA $13
LDA #$05
STA $07
LDA #$B4
STA $08
death_return21:
RTS
murder_depart_or_tick21:
LDA $0679
BNE murder_depart21
JMP murder_tick
murder_depart21:
LDX #$00
murder_depart_loop21:
LDA $0688,X
BEQ murder_depart_next21
; Exit right at two pixels/update; no homing or wrapping during evacuation.
LDA $0681,X
CLC
ADC #$02
STA $0681,X
BCC murder_depart_next21
LDA #$00
STA $0688,X
murder_depart_next21:
TXA
CLC
ADC #$10
TAX
CPX #$60
BNE murder_depart_loop21
RTS
enemy_rocks21:
LDA #$00
STA $067B
enemy_source21:
LDX $067B
BNE enemy_shot_source21
LDA $0640
BNE enemy_body_source21
JMP enemy_next21
enemy_body_source21:
CMP #$01
BEQ enemy_big21
LDA #$08
BNE enemy_body_width21
enemy_big21:
LDA #$0C
enemy_body_width21:
STA $72
LDA $0641
STA $70
LDA $0642
STA $71
LDA #$0C
LDX $0643
BEQ enemy_heading21
LDA #$24
enemy_heading21:
STA $27
JMP enemy_scan21
enemy_shot_source21:
LDA $0640,X
BNE enemy_shot_live21
JMP enemy_next21
enemy_shot_live21:
LDA $0642,X
STA $70
LDA $0644,X
STA $71
LDA $0649,X
STA $27
LDA #$04
STA $72
enemy_scan21:
JSR scan_regular21
BCC enemy_next21
; Consume the source before invoking any fragment creation.
LDX $067B
LDA #$00
STA $0640,X
CPX #$00
BNE enemy_target21
STA $41
LDA #$0F
STA $0647
JSR ufo_reload
enemy_target21:
LDA $43
STA $45
LDA $44
STA $46
LDY #$08
LDA ($43),Y
CMP #$01
BEQ enemy_large21
CMP #$02
BEQ enemy_medium21
LDA #$00
STA ($43),Y
JMP enemy_next21
enemy_large21:
JSR spawn_mediums_generic
JMP enemy_next21
enemy_medium21:
JSR spawn_smalls_generic
enemy_next21:
LDA $067B
CLC
ADC #$10
STA $067B
CMP #$30
BEQ enemy_done21
JMP enemy_source21
enemy_done21:
RTS
