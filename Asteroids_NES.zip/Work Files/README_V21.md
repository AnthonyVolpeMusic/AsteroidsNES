# Asteroids V21 — mortal Player One

Build: `python prototype/build_v21.py` (Python 3, Pillow, py65).
ROM: `prototype/asteroids_nes_v21_mortal.nes`.

Player One now collides with regular asteroids, Murderoids, UFO bodies and
both UFO shots. Existing shields prevent death. A death subtracts exactly
one life and immediately clears all four player projectile slots.

With lives remaining, respawn occurs after 120 game updates: centered,
facing up, zero velocity, cleared player projectiles, SUPER refilled to five,
and a free 180-update shield using the existing four-palette animation.
Pickup parity, sequence position, shot-speed level and magnet tier survive
death. Existing per-wave pickup-sequence resets remain unchanged.

If a Murderoid kills the ship, all surviving Murderoids depart right at
two pixels per update without homing or wrapping. Right-edge metasprite
tiles are clipped. Respawn waits for both the delay and their departure.
No score or pickups are awarded for evacuation. Murderoid spawning and
wave transitions pause during death; regular asteroids and UFOs continue.
Pickups pause during the death interval, preserving captured items.

UFO bodies and both UFO shots collide with regular asteroids. Each source
is consumed before splitting a target. These kills use the proven fragment
creation routines but award no points, pickups or player small-kill counts.
Fresh fragments retain their collision grace. Player shots are processed
first if player and enemy attacks overlap on the same update.

At zero lives gameplay freezes, with the HUD showing LIVES:0. There is no
respawn or dedicated Game Over screen yet; use the emulator's Reset to
start another game.

## Validation

`python prototype/test_v21.py` executes the assembled 6502 ROM and checks
all hazard sizes, shields, exactly-once deaths, the actual NMI/main-loop
respawn sequence, death-persistent upgrades/counters, six-object evacuation,
edge clipping, enemy splits with no rewards, and Game Over. It also replays
V20 pickup/magnet/score checks with the new death-persistence expectation.
Two thousand rectangle checks compare wrap-aware collision results against
independent geometry.

`python prototype/test_full_wave.py 21 30 4`
and `python prototype/test_full_wave.py 21 30 12` account for every regular
asteroid birth/destruction, producing 2,100 and 6,300 points respectively
in all 60 runs. These controlled waves use player shots only; UFO-caused
destruction intentionally lowers the player's available score.

A representative frame with 48 small asteroids, a UFO and its two shots
takes 28,081 emulated CPU cycles including a 514-cycle DMA allowance,
below the approximately 29,780-cycle NTSC frame budget. This is not an
exhaustive worst-case timing guarantee; densely clustered objects and
additional player shots/pickups can cost more. Timing is in game updates
(60 updates per second at full NTSC speed). OpenEMU visual playtesting
remains the next check; py65 does not emulate the NES PPU.

## Implementation

New builder: prototype/build_v21.py; routines: prototype/mortality_v21.asm.
State uses $0677 (alive/dead/gameover), $0678 (respawn delay), $0679
(evacuation), $067B (enemy dispatcher source). Collision scratch is $70–$78.
Existing object pools, CHR artwork, controls and OAM priorities are retained.
Direct page scans reject distant X positions before full rectangle checks.
