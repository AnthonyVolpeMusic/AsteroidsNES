# V24 triangle asteroid pulse

Build with `python prototype/build_v24.py`. Run
`prototype/asteroids_nes_v24_triangle_pulse.nes`. Test with
`python prototype/test_v24.py`.

V24 uses only the NES triangle channel. While regular asteroids remain, it
alternates C2 then C♯2. Each note is a short triangle pulse, not a continuous
tone. The interval is recalculated at every pulse from active regular-asteroid
records: 13+ = 48 updates, 9–12 = 36, 5–8 = 24, 2–4 = 15, 1 = 9. UFOs,
Murderoids, pickups and player projectiles do not affect this tempo.

The pulse runs during the ordinary death delay and the moving five-second Game
Over sequence while regular asteroids remain. It is silenced on the title/menu,
the final score/rank screen, and any interval with zero regular asteroids.
Only triangle registers $4008/$400A/$400B and its $4015 enable bit are used,
leaving both pulse channels and noise free for later effects.

Tests execute the assembled 6502 code and verify C2/C♯2 alternation, every
tempo boundary, silent inter-pulse updates, shutdown behavior, live-game start,
menu silence, and V23 rank/replay/menu regressions. Emulator listening is the
required final judgment of the exact timbre and tempo.
