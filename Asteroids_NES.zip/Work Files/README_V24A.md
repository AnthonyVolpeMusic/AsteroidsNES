# V24a medium-progress triangle pulse

Build: `python prototype/build_v24a.py`.
ROM: `prototype/asteroids_nes_v24a_medium_progress.nes`.
Test: `python prototype/test_v24a.py`.

V24a replaces the V24 live-regular-asteroid tempo rule. Each wave records two
values: total regular medium asteroids expected (twice its starting large count)
and regular medium asteroids destroyed. The pulse starts at C2/C#2 every 48
updates and advances based on medium completion: 0–24% = 48, 25–49% = 36,
50–74% = 25, 75–99% = 16, and 100% = 9. Values reset on every new wave.

The shared regular-medium splitting routine increments progress, so Player One,
UFO-body and UFO-projectile medium kills all count once. Murderoids are not
regular asteroids and do not affect the tempo. The V23 results screen/replay
tests remain passing. Emulator listening is the final judge of pacing.
