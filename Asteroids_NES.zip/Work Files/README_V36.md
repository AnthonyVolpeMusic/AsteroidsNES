# V36 — controls cleanup

- Removes the bottom object counter from the screen. Its internal weighted tally
  remains in place because V34's adaptive presentation uses it to choose 60 or
  30 FPS at the player-tested thresholds.
- Retires the B+Up rainbow shot. B+Up and B+Down both cost one SUPER and apply
  the same instantaneous brake, including the existing brake sound.
- Down alone still flips the ship by 180 degrees. Pressing B+Down afterwards
  preserves that new heading and stops the ship.

Build: `python3 prototype/build_v36.py`

Verify: `python3 prototype/test_v36.py` and
`python3 prototype/test_full_wave.py 36 20 4`.
