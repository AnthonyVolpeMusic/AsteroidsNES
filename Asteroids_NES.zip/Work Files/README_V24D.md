# V24d cached pulse interval

Build: python3 prototype/build_v24d.py
Test: python3 prototype/test_v24d.py

Reserves zero-page $81 for the pulse interval. Each new wave initializes it to
48. The shared regular-medium destruction path updates it after incrementing
$7E, covering player and enemy kills. The existing 48/36/25/16/9 thresholds
are unchanged. No interval calculation occurs during note playback.

The pending countdown is preserved on a medium kill, so the new interval is
loaded only when the next note plays. Death/clear and respawn/new-wave gates
from V24c are retained, as are asteroid caps and gameplay rules.

Tests execute assembled 6502 instructions: every completion boundary for
4 through 12 starting large asteroids, new-wave reset, pending countdown,
player/UFO medium kills and two-child splitting, death/respawn/clear gates.
Measured service cost excluding caller JSR: 34 cycles on countdown updates,
83 cycles on note updates. Real-emulator late-level slowdown remains a
playtest question; this build does not claim to resolve every busy-frame case.
