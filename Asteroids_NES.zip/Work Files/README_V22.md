# Asteroids V22 — player explosion and live Game Over

Build with `python prototype/build_v22.py`. The ROM is
`prototype/asteroids_nes_v22_gameover.nes`.

Every Player One death now creates four 8×8 explosion fragments at the ship's
last position. Each receives a randomly selected 48-direction velocity and
flies outward. All pieces use the existing five explosion drawings, held for
five game updates each: 25 updates (about 0.42 seconds) in total. They use the
first four OAM slots, ahead of bullets, UFOs and rotating asteroid sprites.

The V21 collision check is retained and verified: Player One dies from either
UFO body as well as its two shots, unless shielded.

On the final life, the same explosion occurs and `GAME OVER` is written at the
center of the playfield. Asteroids, Murderoids, pickups, UFOs and UFO shots
continue their normal updates for exactly 300 updates (five seconds at NTSC
speed). Player controls, player projectiles, player collision and respawning
remain disabled. The screen then holds the finished Game Over state until the
future dedicated Game Over screen replaces it.

`prototype/test_v22.py` executes the assembled 6502 ROM and validates the
full V21 mortality, pickups, magnets and score suite, four moving explosion
sprites, five-update frame cadence, Game Over glyph data, the actual 300-update
live Game Over sequence, and its subsequent hold. `test_full_wave.py 22 30 4`
and `test_full_wave.py 22 30 12` verify 30 full waves at 2,100 and 6,300
points respectively. A 48-rock/UFO/two-shot representative frame remains
within the NTSC frame budget in the CPU harness. OpenEMU or RetroArch visual
playtesting is still required for PPU presentation.
